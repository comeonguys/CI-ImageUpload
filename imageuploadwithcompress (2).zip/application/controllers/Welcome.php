<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    

    public function index()
	{
		$this->load->view('welcome_message');
	}
        
        public function register()
        {
           /* $uname = $this->input->post('uname',TRUE);
            $password = $this->input->post('password',TRUE);
            $password = $this->input->post('confirmpassword',TRUE);
            $address = $this->input->post('address',TRUE);
            $city = $this->input->post('city',TRUE);
            $zipcode = $this->input->post('zipcode',TRUE);
            $email = $this->input->post('email',TRUE);
            $sex= $this->input->post('sex',TRUE);
            
            /*  Validation */
            
            /*
             * alpha - Returns FALSE if the form element contains anything other than alphabetical characters
             * 
             * integer - Returns FALSE if the form element contains anything other than an integer.
             */
            $this->form_validation->set_rules('uname', 'uname', 'trim|required|min_length[5]|max_length[12]|alpha');
            $this->form_validation->set_rules('password', 'Password','trim|required|min_length[5]|max_length[12]');
            $this->form_validation->set_rules('confirmpassword', 'Password Confirmation', 'trim|required|min_length[5]|max_length[12]|matches[password]');
            $this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[5]|max_length[12]');
            $this->form_validation->set_rules('city', 'City', 'trim|required');
            $this->form_validation->set_rules('zipcode', 'Zipcode', 'trim|required|integer');
            $this->form_validation->set_rules('sex', 'sex','trim|required|in_list[Male,Female]');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('language[]','Language','trim|required|alpha');
            if ($this->form_validation->run() == TRUE)
            {
                $config = array('upload_path' =>'uploads/','upload_url' => site_url('uploads/'),'allowed_types' => "gif|jpg|png|jpeg");
                $this->load->library('upload', $config);
                if($this->upload->do_upload())
                {
                    $image_data = $this->upload->data();
                    $configer =  array(
                        'image_library'   => 'gd2',
                        'source_image'    =>  $image_data['full_path'],
                        'maintain_ratio'  =>  TRUE,
                        'width'=>  250,
                        'height'=>  250,);
                    $this->image_lib->clear();
                    $this->image_lib->initialize($configer);
                    $this->image_lib->resize();
                    //$data['imgresult']='<div class="text-success">Successfully Register</div>';
                    $this->load->view('welcome_message');
                }
                else
                {
                    $data['imgresult']='<div class="text-danger">Only Upload GIF, JPG, JPEG and PNG</div>';
                    $this->load->view('welcome_message',$data);
                }
           
            }
            else
            {
                $data['imgresult']='<div class="text-danger">Check Your Data</div>';
                $this->load->view('welcome_message',$data);
            }
       
        }
        
   
}
