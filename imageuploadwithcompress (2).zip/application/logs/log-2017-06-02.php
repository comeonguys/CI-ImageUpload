<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-06-02 06:37:03 --> Config Class Initialized
INFO - 2017-06-02 06:37:03 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:37:03 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:37:03 --> Utf8 Class Initialized
INFO - 2017-06-02 06:37:03 --> URI Class Initialized
DEBUG - 2017-06-02 06:37:03 --> No URI present. Default controller set.
INFO - 2017-06-02 06:37:03 --> Router Class Initialized
INFO - 2017-06-02 06:37:03 --> Output Class Initialized
INFO - 2017-06-02 06:37:03 --> Security Class Initialized
DEBUG - 2017-06-02 06:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:37:03 --> CSRF cookie sent
INFO - 2017-06-02 06:37:03 --> Input Class Initialized
INFO - 2017-06-02 06:37:03 --> Language Class Initialized
INFO - 2017-06-02 06:37:03 --> Loader Class Initialized
INFO - 2017-06-02 06:37:03 --> Helper loaded: url_helper
INFO - 2017-06-02 06:37:03 --> Helper loaded: file_helper
INFO - 2017-06-02 06:37:03 --> Helper loaded: form_helper
INFO - 2017-06-02 06:37:03 --> Form Validation Class Initialized
INFO - 2017-06-02 06:37:03 --> Image Lib Class Initialized
INFO - 2017-06-02 06:37:03 --> Controller Class Initialized
INFO - 2017-06-02 06:37:04 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:37:04 --> Final output sent to browser
DEBUG - 2017-06-02 06:37:04 --> Total execution time: 1.0715
INFO - 2017-06-02 06:46:03 --> Config Class Initialized
INFO - 2017-06-02 06:46:03 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:46:03 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:46:03 --> Utf8 Class Initialized
INFO - 2017-06-02 06:46:03 --> URI Class Initialized
DEBUG - 2017-06-02 06:46:03 --> No URI present. Default controller set.
INFO - 2017-06-02 06:46:03 --> Router Class Initialized
INFO - 2017-06-02 06:46:03 --> Output Class Initialized
INFO - 2017-06-02 06:46:03 --> Security Class Initialized
DEBUG - 2017-06-02 06:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:46:03 --> CSRF cookie sent
INFO - 2017-06-02 06:46:03 --> Input Class Initialized
INFO - 2017-06-02 06:46:03 --> Language Class Initialized
INFO - 2017-06-02 06:46:03 --> Loader Class Initialized
INFO - 2017-06-02 06:46:03 --> Helper loaded: url_helper
INFO - 2017-06-02 06:46:03 --> Helper loaded: file_helper
INFO - 2017-06-02 06:46:03 --> Helper loaded: form_helper
INFO - 2017-06-02 06:46:03 --> Form Validation Class Initialized
INFO - 2017-06-02 06:46:03 --> Image Lib Class Initialized
INFO - 2017-06-02 06:46:03 --> Controller Class Initialized
INFO - 2017-06-02 06:46:03 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:46:03 --> Final output sent to browser
DEBUG - 2017-06-02 06:46:03 --> Total execution time: 0.5879
INFO - 2017-06-02 06:46:40 --> Config Class Initialized
INFO - 2017-06-02 06:46:40 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:46:40 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:46:40 --> Utf8 Class Initialized
INFO - 2017-06-02 06:46:40 --> URI Class Initialized
INFO - 2017-06-02 06:46:40 --> Router Class Initialized
INFO - 2017-06-02 06:46:40 --> Output Class Initialized
INFO - 2017-06-02 06:46:40 --> Security Class Initialized
DEBUG - 2017-06-02 06:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:46:40 --> CSRF cookie sent
INFO - 2017-06-02 06:46:40 --> CSRF token verified
INFO - 2017-06-02 06:46:40 --> Input Class Initialized
INFO - 2017-06-02 06:46:40 --> Language Class Initialized
INFO - 2017-06-02 06:46:40 --> Loader Class Initialized
INFO - 2017-06-02 06:46:40 --> Helper loaded: url_helper
INFO - 2017-06-02 06:46:40 --> Helper loaded: file_helper
INFO - 2017-06-02 06:46:40 --> Helper loaded: form_helper
INFO - 2017-06-02 06:46:40 --> Form Validation Class Initialized
INFO - 2017-06-02 06:46:40 --> Image Lib Class Initialized
INFO - 2017-06-02 06:46:40 --> Controller Class Initialized
INFO - 2017-06-02 06:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 06:46:40 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:46:40 --> Final output sent to browser
DEBUG - 2017-06-02 06:46:40 --> Total execution time: 0.2723
INFO - 2017-06-02 06:46:58 --> Config Class Initialized
INFO - 2017-06-02 06:46:58 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:46:58 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:46:58 --> Utf8 Class Initialized
INFO - 2017-06-02 06:46:58 --> URI Class Initialized
INFO - 2017-06-02 06:46:58 --> Router Class Initialized
INFO - 2017-06-02 06:46:58 --> Output Class Initialized
INFO - 2017-06-02 06:46:58 --> Security Class Initialized
DEBUG - 2017-06-02 06:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:46:58 --> CSRF cookie sent
INFO - 2017-06-02 06:46:58 --> CSRF token verified
INFO - 2017-06-02 06:46:58 --> Input Class Initialized
INFO - 2017-06-02 06:46:58 --> Language Class Initialized
INFO - 2017-06-02 06:46:58 --> Loader Class Initialized
INFO - 2017-06-02 06:46:58 --> Helper loaded: url_helper
INFO - 2017-06-02 06:46:58 --> Helper loaded: file_helper
INFO - 2017-06-02 06:46:58 --> Helper loaded: form_helper
INFO - 2017-06-02 06:46:58 --> Form Validation Class Initialized
INFO - 2017-06-02 06:46:58 --> Image Lib Class Initialized
INFO - 2017-06-02 06:46:58 --> Controller Class Initialized
INFO - 2017-06-02 06:46:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 06:46:58 --> Upload Class Initialized
INFO - 2017-06-02 06:46:58 --> Language file loaded: language/english/upload_lang.php
INFO - 2017-06-02 06:46:58 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
INFO - 2017-06-02 06:47:31 --> Config Class Initialized
INFO - 2017-06-02 06:47:31 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:47:31 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:47:31 --> Utf8 Class Initialized
INFO - 2017-06-02 06:47:31 --> URI Class Initialized
INFO - 2017-06-02 06:47:31 --> Router Class Initialized
INFO - 2017-06-02 06:47:31 --> Output Class Initialized
INFO - 2017-06-02 06:47:31 --> Security Class Initialized
DEBUG - 2017-06-02 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:47:31 --> CSRF cookie sent
INFO - 2017-06-02 06:47:31 --> Input Class Initialized
INFO - 2017-06-02 06:47:31 --> Language Class Initialized
INFO - 2017-06-02 06:47:31 --> Loader Class Initialized
INFO - 2017-06-02 06:47:31 --> Helper loaded: url_helper
INFO - 2017-06-02 06:47:31 --> Helper loaded: file_helper
INFO - 2017-06-02 06:47:31 --> Helper loaded: form_helper
INFO - 2017-06-02 06:47:31 --> Form Validation Class Initialized
INFO - 2017-06-02 06:47:32 --> Image Lib Class Initialized
INFO - 2017-06-02 06:47:32 --> Controller Class Initialized
INFO - 2017-06-02 06:47:32 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:47:32 --> Final output sent to browser
DEBUG - 2017-06-02 06:47:32 --> Total execution time: 0.1532
INFO - 2017-06-02 06:47:35 --> Config Class Initialized
INFO - 2017-06-02 06:47:35 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:47:35 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:47:35 --> Utf8 Class Initialized
INFO - 2017-06-02 06:47:35 --> URI Class Initialized
DEBUG - 2017-06-02 06:47:35 --> No URI present. Default controller set.
INFO - 2017-06-02 06:47:35 --> Router Class Initialized
INFO - 2017-06-02 06:47:35 --> Output Class Initialized
INFO - 2017-06-02 06:47:35 --> Security Class Initialized
DEBUG - 2017-06-02 06:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:47:35 --> CSRF cookie sent
INFO - 2017-06-02 06:47:35 --> Input Class Initialized
INFO - 2017-06-02 06:47:35 --> Language Class Initialized
INFO - 2017-06-02 06:47:35 --> Loader Class Initialized
INFO - 2017-06-02 06:47:35 --> Helper loaded: url_helper
INFO - 2017-06-02 06:47:35 --> Helper loaded: file_helper
INFO - 2017-06-02 06:47:35 --> Helper loaded: form_helper
INFO - 2017-06-02 06:47:35 --> Form Validation Class Initialized
INFO - 2017-06-02 06:47:35 --> Image Lib Class Initialized
INFO - 2017-06-02 06:47:35 --> Controller Class Initialized
INFO - 2017-06-02 06:47:35 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:47:35 --> Final output sent to browser
DEBUG - 2017-06-02 06:47:35 --> Total execution time: 0.1452
INFO - 2017-06-02 06:48:14 --> Config Class Initialized
INFO - 2017-06-02 06:48:14 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:48:14 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:48:14 --> Utf8 Class Initialized
INFO - 2017-06-02 06:48:14 --> URI Class Initialized
INFO - 2017-06-02 06:48:14 --> Router Class Initialized
INFO - 2017-06-02 06:48:14 --> Output Class Initialized
INFO - 2017-06-02 06:48:14 --> Security Class Initialized
DEBUG - 2017-06-02 06:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:48:14 --> CSRF cookie sent
INFO - 2017-06-02 06:48:14 --> CSRF token verified
INFO - 2017-06-02 06:48:14 --> Input Class Initialized
INFO - 2017-06-02 06:48:14 --> Language Class Initialized
INFO - 2017-06-02 06:48:14 --> Loader Class Initialized
INFO - 2017-06-02 06:48:14 --> Helper loaded: url_helper
INFO - 2017-06-02 06:48:14 --> Helper loaded: file_helper
INFO - 2017-06-02 06:48:14 --> Helper loaded: form_helper
INFO - 2017-06-02 06:48:14 --> Form Validation Class Initialized
INFO - 2017-06-02 06:48:14 --> Image Lib Class Initialized
INFO - 2017-06-02 06:48:14 --> Controller Class Initialized
INFO - 2017-06-02 06:48:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 06:48:14 --> Upload Class Initialized
INFO - 2017-06-02 06:48:15 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:48:15 --> Final output sent to browser
DEBUG - 2017-06-02 06:48:15 --> Total execution time: 0.3097
INFO - 2017-06-02 06:54:36 --> Config Class Initialized
INFO - 2017-06-02 06:54:36 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:54:36 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:54:36 --> Utf8 Class Initialized
INFO - 2017-06-02 06:54:36 --> URI Class Initialized
DEBUG - 2017-06-02 06:54:36 --> No URI present. Default controller set.
INFO - 2017-06-02 06:54:36 --> Router Class Initialized
INFO - 2017-06-02 06:54:36 --> Output Class Initialized
INFO - 2017-06-02 06:54:36 --> Security Class Initialized
DEBUG - 2017-06-02 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:54:36 --> CSRF cookie sent
INFO - 2017-06-02 06:54:36 --> Input Class Initialized
INFO - 2017-06-02 06:54:36 --> Language Class Initialized
INFO - 2017-06-02 06:54:36 --> Loader Class Initialized
INFO - 2017-06-02 06:54:36 --> Helper loaded: url_helper
INFO - 2017-06-02 06:54:36 --> Helper loaded: file_helper
INFO - 2017-06-02 06:54:36 --> Helper loaded: form_helper
INFO - 2017-06-02 06:54:36 --> Form Validation Class Initialized
INFO - 2017-06-02 06:54:36 --> Image Lib Class Initialized
INFO - 2017-06-02 06:54:36 --> Controller Class Initialized
INFO - 2017-06-02 06:54:36 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:54:36 --> Final output sent to browser
DEBUG - 2017-06-02 06:54:36 --> Total execution time: 0.1738
INFO - 2017-06-02 06:55:08 --> Config Class Initialized
INFO - 2017-06-02 06:55:08 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:55:08 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:55:08 --> Utf8 Class Initialized
INFO - 2017-06-02 06:55:08 --> URI Class Initialized
INFO - 2017-06-02 06:55:08 --> Router Class Initialized
INFO - 2017-06-02 06:55:08 --> Output Class Initialized
INFO - 2017-06-02 06:55:08 --> Security Class Initialized
DEBUG - 2017-06-02 06:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:55:08 --> CSRF cookie sent
INFO - 2017-06-02 06:55:08 --> CSRF token verified
INFO - 2017-06-02 06:55:08 --> Input Class Initialized
INFO - 2017-06-02 06:55:08 --> Language Class Initialized
INFO - 2017-06-02 06:55:08 --> Loader Class Initialized
INFO - 2017-06-02 06:55:08 --> Helper loaded: url_helper
INFO - 2017-06-02 06:55:08 --> Helper loaded: file_helper
INFO - 2017-06-02 06:55:08 --> Helper loaded: form_helper
INFO - 2017-06-02 06:55:08 --> Form Validation Class Initialized
INFO - 2017-06-02 06:55:08 --> Image Lib Class Initialized
INFO - 2017-06-02 06:55:08 --> Controller Class Initialized
INFO - 2017-06-02 06:55:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 06:55:08 --> Upload Class Initialized
INFO - 2017-06-02 06:55:08 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:55:08 --> Final output sent to browser
DEBUG - 2017-06-02 06:55:08 --> Total execution time: 0.2508
INFO - 2017-06-02 06:56:10 --> Config Class Initialized
INFO - 2017-06-02 06:56:10 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:56:10 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:56:10 --> Utf8 Class Initialized
INFO - 2017-06-02 06:56:10 --> URI Class Initialized
INFO - 2017-06-02 06:56:10 --> Router Class Initialized
INFO - 2017-06-02 06:56:10 --> Output Class Initialized
INFO - 2017-06-02 06:56:10 --> Security Class Initialized
DEBUG - 2017-06-02 06:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:56:10 --> CSRF cookie sent
INFO - 2017-06-02 06:56:10 --> Input Class Initialized
INFO - 2017-06-02 06:56:10 --> Language Class Initialized
INFO - 2017-06-02 06:56:10 --> Loader Class Initialized
INFO - 2017-06-02 06:56:10 --> Helper loaded: url_helper
INFO - 2017-06-02 06:56:10 --> Helper loaded: file_helper
INFO - 2017-06-02 06:56:10 --> Helper loaded: form_helper
INFO - 2017-06-02 06:56:10 --> Form Validation Class Initialized
INFO - 2017-06-02 06:56:10 --> Image Lib Class Initialized
INFO - 2017-06-02 06:56:10 --> Controller Class Initialized
INFO - 2017-06-02 06:56:10 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:56:10 --> Final output sent to browser
DEBUG - 2017-06-02 06:56:10 --> Total execution time: 0.1526
INFO - 2017-06-02 06:56:49 --> Config Class Initialized
INFO - 2017-06-02 06:56:49 --> Hooks Class Initialized
DEBUG - 2017-06-02 06:56:49 --> UTF-8 Support Enabled
INFO - 2017-06-02 06:56:49 --> Utf8 Class Initialized
INFO - 2017-06-02 06:56:49 --> URI Class Initialized
INFO - 2017-06-02 06:56:49 --> Router Class Initialized
INFO - 2017-06-02 06:56:49 --> Output Class Initialized
INFO - 2017-06-02 06:56:49 --> Security Class Initialized
DEBUG - 2017-06-02 06:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 06:56:49 --> CSRF cookie sent
INFO - 2017-06-02 06:56:49 --> CSRF token verified
INFO - 2017-06-02 06:56:49 --> Input Class Initialized
INFO - 2017-06-02 06:56:49 --> Language Class Initialized
INFO - 2017-06-02 06:56:49 --> Loader Class Initialized
INFO - 2017-06-02 06:56:49 --> Helper loaded: url_helper
INFO - 2017-06-02 06:56:49 --> Helper loaded: file_helper
INFO - 2017-06-02 06:56:49 --> Helper loaded: form_helper
INFO - 2017-06-02 06:56:49 --> Form Validation Class Initialized
INFO - 2017-06-02 06:56:49 --> Image Lib Class Initialized
INFO - 2017-06-02 06:56:49 --> Controller Class Initialized
INFO - 2017-06-02 06:56:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 06:56:49 --> Upload Class Initialized
INFO - 2017-06-02 06:56:49 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 06:56:49 --> Final output sent to browser
DEBUG - 2017-06-02 06:56:49 --> Total execution time: 0.2231
INFO - 2017-06-02 07:00:38 --> Config Class Initialized
INFO - 2017-06-02 07:00:38 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:00:38 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:00:38 --> Utf8 Class Initialized
INFO - 2017-06-02 07:00:38 --> URI Class Initialized
DEBUG - 2017-06-02 07:00:38 --> No URI present. Default controller set.
INFO - 2017-06-02 07:00:38 --> Router Class Initialized
INFO - 2017-06-02 07:00:38 --> Output Class Initialized
INFO - 2017-06-02 07:00:38 --> Security Class Initialized
DEBUG - 2017-06-02 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:00:38 --> CSRF cookie sent
INFO - 2017-06-02 07:00:38 --> Input Class Initialized
INFO - 2017-06-02 07:00:38 --> Language Class Initialized
INFO - 2017-06-02 07:00:38 --> Loader Class Initialized
INFO - 2017-06-02 07:00:38 --> Helper loaded: url_helper
INFO - 2017-06-02 07:00:38 --> Helper loaded: file_helper
INFO - 2017-06-02 07:00:38 --> Helper loaded: form_helper
INFO - 2017-06-02 07:00:38 --> Form Validation Class Initialized
INFO - 2017-06-02 07:00:38 --> Image Lib Class Initialized
INFO - 2017-06-02 07:00:38 --> Controller Class Initialized
INFO - 2017-06-02 07:00:38 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:00:38 --> Final output sent to browser
DEBUG - 2017-06-02 07:00:38 --> Total execution time: 0.1554
INFO - 2017-06-02 07:01:13 --> Config Class Initialized
INFO - 2017-06-02 07:01:13 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:01:13 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:01:13 --> Utf8 Class Initialized
INFO - 2017-06-02 07:01:13 --> URI Class Initialized
INFO - 2017-06-02 07:01:13 --> Router Class Initialized
INFO - 2017-06-02 07:01:13 --> Output Class Initialized
INFO - 2017-06-02 07:01:13 --> Security Class Initialized
DEBUG - 2017-06-02 07:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:01:13 --> CSRF cookie sent
INFO - 2017-06-02 07:01:13 --> CSRF token verified
INFO - 2017-06-02 07:01:13 --> Input Class Initialized
INFO - 2017-06-02 07:01:13 --> Language Class Initialized
INFO - 2017-06-02 07:01:13 --> Loader Class Initialized
INFO - 2017-06-02 07:01:13 --> Helper loaded: url_helper
INFO - 2017-06-02 07:01:13 --> Helper loaded: file_helper
INFO - 2017-06-02 07:01:13 --> Helper loaded: form_helper
INFO - 2017-06-02 07:01:13 --> Form Validation Class Initialized
INFO - 2017-06-02 07:01:13 --> Image Lib Class Initialized
INFO - 2017-06-02 07:01:13 --> Controller Class Initialized
INFO - 2017-06-02 07:01:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:01:13 --> Upload Class Initialized
INFO - 2017-06-02 07:01:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:01:13 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:01:13 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:01:13 --> Final output sent to browser
DEBUG - 2017-06-02 07:01:13 --> Total execution time: 0.2024
INFO - 2017-06-02 07:02:21 --> Config Class Initialized
INFO - 2017-06-02 07:02:21 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:02:21 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:02:21 --> Utf8 Class Initialized
INFO - 2017-06-02 07:02:21 --> URI Class Initialized
DEBUG - 2017-06-02 07:02:21 --> No URI present. Default controller set.
INFO - 2017-06-02 07:02:21 --> Router Class Initialized
INFO - 2017-06-02 07:02:21 --> Output Class Initialized
INFO - 2017-06-02 07:02:21 --> Security Class Initialized
DEBUG - 2017-06-02 07:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:02:21 --> CSRF cookie sent
INFO - 2017-06-02 07:02:21 --> Input Class Initialized
INFO - 2017-06-02 07:02:21 --> Language Class Initialized
INFO - 2017-06-02 07:02:21 --> Loader Class Initialized
INFO - 2017-06-02 07:02:21 --> Helper loaded: url_helper
INFO - 2017-06-02 07:02:21 --> Helper loaded: file_helper
INFO - 2017-06-02 07:02:21 --> Helper loaded: form_helper
INFO - 2017-06-02 07:02:21 --> Form Validation Class Initialized
INFO - 2017-06-02 07:02:21 --> Image Lib Class Initialized
INFO - 2017-06-02 07:02:21 --> Controller Class Initialized
INFO - 2017-06-02 07:02:21 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:02:21 --> Final output sent to browser
DEBUG - 2017-06-02 07:02:21 --> Total execution time: 0.1604
INFO - 2017-06-02 07:02:58 --> Config Class Initialized
INFO - 2017-06-02 07:02:58 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:02:58 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:02:58 --> Utf8 Class Initialized
INFO - 2017-06-02 07:02:58 --> URI Class Initialized
INFO - 2017-06-02 07:02:58 --> Router Class Initialized
INFO - 2017-06-02 07:02:58 --> Output Class Initialized
INFO - 2017-06-02 07:02:58 --> Security Class Initialized
DEBUG - 2017-06-02 07:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:02:58 --> CSRF cookie sent
INFO - 2017-06-02 07:02:58 --> CSRF token verified
INFO - 2017-06-02 07:02:58 --> Input Class Initialized
INFO - 2017-06-02 07:02:58 --> Language Class Initialized
INFO - 2017-06-02 07:02:58 --> Loader Class Initialized
INFO - 2017-06-02 07:02:58 --> Helper loaded: url_helper
INFO - 2017-06-02 07:02:58 --> Helper loaded: file_helper
INFO - 2017-06-02 07:02:58 --> Helper loaded: form_helper
INFO - 2017-06-02 07:02:58 --> Form Validation Class Initialized
INFO - 2017-06-02 07:02:58 --> Image Lib Class Initialized
INFO - 2017-06-02 07:02:58 --> Controller Class Initialized
INFO - 2017-06-02 07:02:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:02:58 --> Upload Class Initialized
INFO - 2017-06-02 07:02:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:02:58 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:02:58 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:02:58 --> Final output sent to browser
DEBUG - 2017-06-02 07:02:58 --> Total execution time: 0.2063
INFO - 2017-06-02 07:03:58 --> Config Class Initialized
INFO - 2017-06-02 07:03:58 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:03:58 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:03:58 --> Utf8 Class Initialized
INFO - 2017-06-02 07:03:58 --> URI Class Initialized
DEBUG - 2017-06-02 07:03:58 --> No URI present. Default controller set.
INFO - 2017-06-02 07:03:58 --> Router Class Initialized
INFO - 2017-06-02 07:03:58 --> Output Class Initialized
INFO - 2017-06-02 07:03:58 --> Security Class Initialized
DEBUG - 2017-06-02 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:03:58 --> CSRF cookie sent
INFO - 2017-06-02 07:03:58 --> Input Class Initialized
INFO - 2017-06-02 07:03:58 --> Language Class Initialized
INFO - 2017-06-02 07:03:58 --> Loader Class Initialized
INFO - 2017-06-02 07:03:58 --> Helper loaded: url_helper
INFO - 2017-06-02 07:03:58 --> Helper loaded: file_helper
INFO - 2017-06-02 07:03:58 --> Helper loaded: form_helper
INFO - 2017-06-02 07:03:58 --> Form Validation Class Initialized
INFO - 2017-06-02 07:03:58 --> Image Lib Class Initialized
INFO - 2017-06-02 07:03:58 --> Controller Class Initialized
INFO - 2017-06-02 07:03:58 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:03:58 --> Final output sent to browser
DEBUG - 2017-06-02 07:03:58 --> Total execution time: 0.1549
INFO - 2017-06-02 07:04:42 --> Config Class Initialized
INFO - 2017-06-02 07:04:42 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:04:42 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:04:42 --> Utf8 Class Initialized
INFO - 2017-06-02 07:04:42 --> URI Class Initialized
INFO - 2017-06-02 07:04:42 --> Router Class Initialized
INFO - 2017-06-02 07:04:42 --> Output Class Initialized
INFO - 2017-06-02 07:04:42 --> Security Class Initialized
DEBUG - 2017-06-02 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:04:42 --> CSRF cookie sent
INFO - 2017-06-02 07:04:42 --> CSRF token verified
INFO - 2017-06-02 07:04:42 --> Input Class Initialized
INFO - 2017-06-02 07:04:42 --> Language Class Initialized
INFO - 2017-06-02 07:04:42 --> Loader Class Initialized
INFO - 2017-06-02 07:04:42 --> Helper loaded: url_helper
INFO - 2017-06-02 07:04:42 --> Helper loaded: file_helper
INFO - 2017-06-02 07:04:42 --> Helper loaded: form_helper
INFO - 2017-06-02 07:04:42 --> Form Validation Class Initialized
INFO - 2017-06-02 07:04:42 --> Image Lib Class Initialized
INFO - 2017-06-02 07:04:42 --> Controller Class Initialized
INFO - 2017-06-02 07:04:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:04:42 --> Upload Class Initialized
INFO - 2017-06-02 07:04:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:04:42 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:04:42 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:04:42 --> Final output sent to browser
DEBUG - 2017-06-02 07:04:42 --> Total execution time: 0.1885
INFO - 2017-06-02 07:07:07 --> Config Class Initialized
INFO - 2017-06-02 07:07:07 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:07:07 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:07:07 --> Utf8 Class Initialized
INFO - 2017-06-02 07:07:07 --> URI Class Initialized
DEBUG - 2017-06-02 07:07:07 --> No URI present. Default controller set.
INFO - 2017-06-02 07:07:07 --> Router Class Initialized
INFO - 2017-06-02 07:07:07 --> Output Class Initialized
INFO - 2017-06-02 07:07:07 --> Security Class Initialized
DEBUG - 2017-06-02 07:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:07:07 --> CSRF cookie sent
INFO - 2017-06-02 07:07:07 --> Input Class Initialized
INFO - 2017-06-02 07:07:07 --> Language Class Initialized
INFO - 2017-06-02 07:07:07 --> Loader Class Initialized
INFO - 2017-06-02 07:07:07 --> Helper loaded: url_helper
INFO - 2017-06-02 07:07:07 --> Helper loaded: file_helper
INFO - 2017-06-02 07:07:07 --> Helper loaded: form_helper
INFO - 2017-06-02 07:07:07 --> Form Validation Class Initialized
INFO - 2017-06-02 07:07:07 --> Image Lib Class Initialized
INFO - 2017-06-02 07:07:07 --> Controller Class Initialized
INFO - 2017-06-02 07:07:07 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:07:07 --> Final output sent to browser
DEBUG - 2017-06-02 07:07:07 --> Total execution time: 0.1601
INFO - 2017-06-02 07:07:46 --> Config Class Initialized
INFO - 2017-06-02 07:07:46 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:07:46 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:07:46 --> Utf8 Class Initialized
INFO - 2017-06-02 07:07:46 --> URI Class Initialized
INFO - 2017-06-02 07:07:46 --> Router Class Initialized
INFO - 2017-06-02 07:07:46 --> Output Class Initialized
INFO - 2017-06-02 07:07:46 --> Security Class Initialized
DEBUG - 2017-06-02 07:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:07:46 --> CSRF cookie sent
INFO - 2017-06-02 07:07:46 --> CSRF token verified
INFO - 2017-06-02 07:07:46 --> Input Class Initialized
INFO - 2017-06-02 07:07:46 --> Language Class Initialized
INFO - 2017-06-02 07:07:46 --> Loader Class Initialized
INFO - 2017-06-02 07:07:46 --> Helper loaded: url_helper
INFO - 2017-06-02 07:07:46 --> Helper loaded: file_helper
INFO - 2017-06-02 07:07:46 --> Helper loaded: form_helper
INFO - 2017-06-02 07:07:46 --> Form Validation Class Initialized
INFO - 2017-06-02 07:07:46 --> Image Lib Class Initialized
INFO - 2017-06-02 07:07:46 --> Controller Class Initialized
INFO - 2017-06-02 07:07:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:07:46 --> Upload Class Initialized
INFO - 2017-06-02 07:07:46 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:07:46 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:07:46 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:07:46 --> Final output sent to browser
DEBUG - 2017-06-02 07:07:46 --> Total execution time: 0.1902
INFO - 2017-06-02 07:09:08 --> Config Class Initialized
INFO - 2017-06-02 07:09:08 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:09:08 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:09:08 --> Utf8 Class Initialized
INFO - 2017-06-02 07:09:08 --> URI Class Initialized
DEBUG - 2017-06-02 07:09:09 --> No URI present. Default controller set.
INFO - 2017-06-02 07:09:09 --> Router Class Initialized
INFO - 2017-06-02 07:09:09 --> Output Class Initialized
INFO - 2017-06-02 07:09:09 --> Security Class Initialized
DEBUG - 2017-06-02 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:09:09 --> CSRF cookie sent
INFO - 2017-06-02 07:09:09 --> Input Class Initialized
INFO - 2017-06-02 07:09:09 --> Language Class Initialized
INFO - 2017-06-02 07:09:09 --> Loader Class Initialized
INFO - 2017-06-02 07:09:09 --> Helper loaded: url_helper
INFO - 2017-06-02 07:09:09 --> Helper loaded: file_helper
INFO - 2017-06-02 07:09:09 --> Helper loaded: form_helper
INFO - 2017-06-02 07:09:09 --> Form Validation Class Initialized
INFO - 2017-06-02 07:09:09 --> Image Lib Class Initialized
INFO - 2017-06-02 07:09:09 --> Controller Class Initialized
INFO - 2017-06-02 07:09:09 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:09:09 --> Final output sent to browser
DEBUG - 2017-06-02 07:09:09 --> Total execution time: 0.1652
INFO - 2017-06-02 07:09:42 --> Config Class Initialized
INFO - 2017-06-02 07:09:42 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:09:42 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:09:42 --> Utf8 Class Initialized
INFO - 2017-06-02 07:09:42 --> URI Class Initialized
INFO - 2017-06-02 07:09:42 --> Router Class Initialized
INFO - 2017-06-02 07:09:42 --> Output Class Initialized
INFO - 2017-06-02 07:09:42 --> Security Class Initialized
DEBUG - 2017-06-02 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:09:42 --> CSRF cookie sent
INFO - 2017-06-02 07:09:42 --> CSRF token verified
INFO - 2017-06-02 07:09:42 --> Input Class Initialized
INFO - 2017-06-02 07:09:42 --> Language Class Initialized
INFO - 2017-06-02 07:09:42 --> Loader Class Initialized
INFO - 2017-06-02 07:09:42 --> Helper loaded: url_helper
INFO - 2017-06-02 07:09:42 --> Helper loaded: file_helper
INFO - 2017-06-02 07:09:42 --> Helper loaded: form_helper
INFO - 2017-06-02 07:09:42 --> Form Validation Class Initialized
INFO - 2017-06-02 07:09:42 --> Image Lib Class Initialized
INFO - 2017-06-02 07:09:42 --> Controller Class Initialized
INFO - 2017-06-02 07:09:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:09:42 --> Upload Class Initialized
INFO - 2017-06-02 07:09:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:09:42 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:09:42 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:09:42 --> Final output sent to browser
DEBUG - 2017-06-02 07:09:42 --> Total execution time: 0.1895
INFO - 2017-06-02 07:10:03 --> Config Class Initialized
INFO - 2017-06-02 07:10:03 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:10:03 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:10:03 --> Utf8 Class Initialized
INFO - 2017-06-02 07:10:03 --> URI Class Initialized
DEBUG - 2017-06-02 07:10:03 --> No URI present. Default controller set.
INFO - 2017-06-02 07:10:03 --> Router Class Initialized
INFO - 2017-06-02 07:10:03 --> Output Class Initialized
INFO - 2017-06-02 07:10:03 --> Security Class Initialized
DEBUG - 2017-06-02 07:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:10:03 --> CSRF cookie sent
INFO - 2017-06-02 07:10:03 --> Input Class Initialized
INFO - 2017-06-02 07:10:03 --> Language Class Initialized
INFO - 2017-06-02 07:10:03 --> Loader Class Initialized
INFO - 2017-06-02 07:10:03 --> Helper loaded: url_helper
INFO - 2017-06-02 07:10:03 --> Helper loaded: file_helper
INFO - 2017-06-02 07:10:03 --> Helper loaded: form_helper
INFO - 2017-06-02 07:10:03 --> Form Validation Class Initialized
INFO - 2017-06-02 07:10:03 --> Image Lib Class Initialized
INFO - 2017-06-02 07:10:03 --> Controller Class Initialized
INFO - 2017-06-02 07:10:03 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:10:03 --> Final output sent to browser
DEBUG - 2017-06-02 07:10:04 --> Total execution time: 0.1645
INFO - 2017-06-02 07:10:33 --> Config Class Initialized
INFO - 2017-06-02 07:10:33 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:10:33 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:10:33 --> Utf8 Class Initialized
INFO - 2017-06-02 07:10:33 --> URI Class Initialized
INFO - 2017-06-02 07:10:33 --> Router Class Initialized
INFO - 2017-06-02 07:10:33 --> Output Class Initialized
INFO - 2017-06-02 07:10:33 --> Security Class Initialized
DEBUG - 2017-06-02 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:10:33 --> CSRF cookie sent
INFO - 2017-06-02 07:10:33 --> CSRF token verified
INFO - 2017-06-02 07:10:33 --> Input Class Initialized
INFO - 2017-06-02 07:10:33 --> Language Class Initialized
INFO - 2017-06-02 07:10:33 --> Loader Class Initialized
INFO - 2017-06-02 07:10:33 --> Helper loaded: url_helper
INFO - 2017-06-02 07:10:33 --> Helper loaded: file_helper
INFO - 2017-06-02 07:10:33 --> Helper loaded: form_helper
INFO - 2017-06-02 07:10:33 --> Form Validation Class Initialized
INFO - 2017-06-02 07:10:33 --> Image Lib Class Initialized
INFO - 2017-06-02 07:10:33 --> Controller Class Initialized
INFO - 2017-06-02 07:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:10:33 --> Upload Class Initialized
INFO - 2017-06-02 07:10:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-06-02 07:10:33 --> The upload path does not appear to be valid.
INFO - 2017-06-02 07:10:33 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:10:33 --> Final output sent to browser
DEBUG - 2017-06-02 07:10:33 --> Total execution time: 0.2593
INFO - 2017-06-02 07:11:08 --> Config Class Initialized
INFO - 2017-06-02 07:11:08 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:11:08 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:11:08 --> Utf8 Class Initialized
INFO - 2017-06-02 07:11:08 --> URI Class Initialized
DEBUG - 2017-06-02 07:11:08 --> No URI present. Default controller set.
INFO - 2017-06-02 07:11:08 --> Router Class Initialized
INFO - 2017-06-02 07:11:08 --> Output Class Initialized
INFO - 2017-06-02 07:11:08 --> Security Class Initialized
DEBUG - 2017-06-02 07:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:11:08 --> CSRF cookie sent
INFO - 2017-06-02 07:11:08 --> Input Class Initialized
INFO - 2017-06-02 07:11:08 --> Language Class Initialized
INFO - 2017-06-02 07:11:08 --> Loader Class Initialized
INFO - 2017-06-02 07:11:08 --> Helper loaded: url_helper
INFO - 2017-06-02 07:11:08 --> Helper loaded: file_helper
INFO - 2017-06-02 07:11:08 --> Helper loaded: form_helper
INFO - 2017-06-02 07:11:08 --> Form Validation Class Initialized
INFO - 2017-06-02 07:11:08 --> Image Lib Class Initialized
INFO - 2017-06-02 07:11:08 --> Controller Class Initialized
INFO - 2017-06-02 07:11:08 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:11:08 --> Final output sent to browser
DEBUG - 2017-06-02 07:11:08 --> Total execution time: 0.1617
INFO - 2017-06-02 07:11:40 --> Config Class Initialized
INFO - 2017-06-02 07:11:40 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:11:40 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:11:40 --> Utf8 Class Initialized
INFO - 2017-06-02 07:11:40 --> URI Class Initialized
INFO - 2017-06-02 07:11:40 --> Router Class Initialized
INFO - 2017-06-02 07:11:40 --> Output Class Initialized
INFO - 2017-06-02 07:11:40 --> Security Class Initialized
DEBUG - 2017-06-02 07:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:11:40 --> CSRF cookie sent
INFO - 2017-06-02 07:11:40 --> CSRF token verified
INFO - 2017-06-02 07:11:40 --> Input Class Initialized
INFO - 2017-06-02 07:11:40 --> Language Class Initialized
INFO - 2017-06-02 07:11:40 --> Loader Class Initialized
INFO - 2017-06-02 07:11:40 --> Helper loaded: url_helper
INFO - 2017-06-02 07:11:40 --> Helper loaded: file_helper
INFO - 2017-06-02 07:11:40 --> Helper loaded: form_helper
INFO - 2017-06-02 07:11:40 --> Form Validation Class Initialized
INFO - 2017-06-02 07:11:40 --> Image Lib Class Initialized
INFO - 2017-06-02 07:11:40 --> Controller Class Initialized
INFO - 2017-06-02 07:11:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:11:40 --> Upload Class Initialized
INFO - 2017-06-02 07:11:40 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:11:40 --> Final output sent to browser
DEBUG - 2017-06-02 07:11:40 --> Total execution time: 0.2257
INFO - 2017-06-02 07:11:57 --> Config Class Initialized
INFO - 2017-06-02 07:11:57 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:11:57 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:11:57 --> Utf8 Class Initialized
INFO - 2017-06-02 07:11:57 --> URI Class Initialized
INFO - 2017-06-02 07:11:57 --> Router Class Initialized
INFO - 2017-06-02 07:11:57 --> Output Class Initialized
INFO - 2017-06-02 07:11:57 --> Security Class Initialized
DEBUG - 2017-06-02 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:11:57 --> CSRF cookie sent
INFO - 2017-06-02 07:11:57 --> CSRF token verified
INFO - 2017-06-02 07:11:57 --> Input Class Initialized
INFO - 2017-06-02 07:11:57 --> Language Class Initialized
INFO - 2017-06-02 07:11:57 --> Loader Class Initialized
INFO - 2017-06-02 07:11:57 --> Helper loaded: url_helper
INFO - 2017-06-02 07:11:57 --> Helper loaded: file_helper
INFO - 2017-06-02 07:11:58 --> Helper loaded: form_helper
INFO - 2017-06-02 07:11:58 --> Form Validation Class Initialized
INFO - 2017-06-02 07:11:58 --> Image Lib Class Initialized
INFO - 2017-06-02 07:11:58 --> Controller Class Initialized
INFO - 2017-06-02 07:11:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:11:58 --> Upload Class Initialized
INFO - 2017-06-02 07:11:58 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:11:58 --> Final output sent to browser
DEBUG - 2017-06-02 07:11:58 --> Total execution time: 0.2161
INFO - 2017-06-02 07:12:22 --> Config Class Initialized
INFO - 2017-06-02 07:12:22 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:12:22 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:12:22 --> Utf8 Class Initialized
INFO - 2017-06-02 07:12:22 --> URI Class Initialized
DEBUG - 2017-06-02 07:12:22 --> No URI present. Default controller set.
INFO - 2017-06-02 07:12:22 --> Router Class Initialized
INFO - 2017-06-02 07:12:22 --> Output Class Initialized
INFO - 2017-06-02 07:12:22 --> Security Class Initialized
DEBUG - 2017-06-02 07:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:12:22 --> CSRF cookie sent
INFO - 2017-06-02 07:12:22 --> Input Class Initialized
INFO - 2017-06-02 07:12:22 --> Language Class Initialized
INFO - 2017-06-02 07:12:22 --> Loader Class Initialized
INFO - 2017-06-02 07:12:22 --> Helper loaded: url_helper
INFO - 2017-06-02 07:12:22 --> Helper loaded: file_helper
INFO - 2017-06-02 07:12:22 --> Helper loaded: form_helper
INFO - 2017-06-02 07:12:22 --> Form Validation Class Initialized
INFO - 2017-06-02 07:12:22 --> Image Lib Class Initialized
INFO - 2017-06-02 07:12:22 --> Controller Class Initialized
INFO - 2017-06-02 07:12:22 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:12:22 --> Final output sent to browser
DEBUG - 2017-06-02 07:12:22 --> Total execution time: 0.1760
INFO - 2017-06-02 07:13:06 --> Config Class Initialized
INFO - 2017-06-02 07:13:06 --> Hooks Class Initialized
DEBUG - 2017-06-02 07:13:06 --> UTF-8 Support Enabled
INFO - 2017-06-02 07:13:06 --> Utf8 Class Initialized
INFO - 2017-06-02 07:13:06 --> URI Class Initialized
INFO - 2017-06-02 07:13:06 --> Router Class Initialized
INFO - 2017-06-02 07:13:06 --> Output Class Initialized
INFO - 2017-06-02 07:13:06 --> Security Class Initialized
DEBUG - 2017-06-02 07:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-02 07:13:06 --> CSRF cookie sent
INFO - 2017-06-02 07:13:06 --> CSRF token verified
INFO - 2017-06-02 07:13:06 --> Input Class Initialized
INFO - 2017-06-02 07:13:06 --> Language Class Initialized
INFO - 2017-06-02 07:13:06 --> Loader Class Initialized
INFO - 2017-06-02 07:13:06 --> Helper loaded: url_helper
INFO - 2017-06-02 07:13:06 --> Helper loaded: file_helper
INFO - 2017-06-02 07:13:06 --> Helper loaded: form_helper
INFO - 2017-06-02 07:13:06 --> Form Validation Class Initialized
INFO - 2017-06-02 07:13:06 --> Image Lib Class Initialized
INFO - 2017-06-02 07:13:06 --> Controller Class Initialized
INFO - 2017-06-02 07:13:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-02 07:13:06 --> Upload Class Initialized
INFO - 2017-06-02 07:13:06 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-02 07:13:06 --> Final output sent to browser
DEBUG - 2017-06-02 07:13:06 --> Total execution time: 0.2927
