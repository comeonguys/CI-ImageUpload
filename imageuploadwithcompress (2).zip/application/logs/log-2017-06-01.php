<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-06-01 11:07:32 --> Config Class Initialized
INFO - 2017-06-01 11:07:32 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:07:32 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:07:32 --> Utf8 Class Initialized
INFO - 2017-06-01 11:07:32 --> URI Class Initialized
DEBUG - 2017-06-01 11:07:32 --> No URI present. Default controller set.
INFO - 2017-06-01 11:07:32 --> Router Class Initialized
INFO - 2017-06-01 11:07:32 --> Output Class Initialized
INFO - 2017-06-01 11:07:32 --> Security Class Initialized
DEBUG - 2017-06-01 11:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:07:32 --> CSRF cookie sent
INFO - 2017-06-01 11:07:32 --> Input Class Initialized
INFO - 2017-06-01 11:07:32 --> Language Class Initialized
INFO - 2017-06-01 11:07:32 --> Loader Class Initialized
INFO - 2017-06-01 11:07:32 --> Helper loaded: url_helper
INFO - 2017-06-01 11:07:32 --> Helper loaded: file_helper
INFO - 2017-06-01 11:07:32 --> Helper loaded: form_helper
INFO - 2017-06-01 11:07:32 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:07:32 --> Form Validation Class Initialized
INFO - 2017-06-01 11:07:32 --> Controller Class Initialized
INFO - 2017-06-01 11:07:32 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:07:32 --> Final output sent to browser
DEBUG - 2017-06-01 11:07:32 --> Total execution time: 0.2986
INFO - 2017-06-01 11:07:34 --> Config Class Initialized
INFO - 2017-06-01 11:07:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:07:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:07:34 --> Utf8 Class Initialized
INFO - 2017-06-01 11:07:34 --> URI Class Initialized
INFO - 2017-06-01 11:07:34 --> Router Class Initialized
INFO - 2017-06-01 11:07:34 --> Output Class Initialized
INFO - 2017-06-01 11:07:34 --> Security Class Initialized
DEBUG - 2017-06-01 11:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:07:34 --> CSRF cookie sent
INFO - 2017-06-01 11:07:34 --> CSRF token verified
INFO - 2017-06-01 11:07:34 --> Input Class Initialized
INFO - 2017-06-01 11:07:34 --> Language Class Initialized
INFO - 2017-06-01 11:07:34 --> Loader Class Initialized
INFO - 2017-06-01 11:07:34 --> Helper loaded: url_helper
INFO - 2017-06-01 11:07:34 --> Helper loaded: file_helper
INFO - 2017-06-01 11:07:34 --> Helper loaded: form_helper
INFO - 2017-06-01 11:07:34 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:07:34 --> Form Validation Class Initialized
INFO - 2017-06-01 11:07:34 --> Controller Class Initialized
INFO - 2017-06-01 11:07:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:07:34 --> Final output sent to browser
DEBUG - 2017-06-01 11:07:34 --> Total execution time: 0.3262
INFO - 2017-06-01 11:07:42 --> Config Class Initialized
INFO - 2017-06-01 11:07:42 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:07:42 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:07:42 --> Utf8 Class Initialized
INFO - 2017-06-01 11:07:42 --> URI Class Initialized
DEBUG - 2017-06-01 11:07:42 --> No URI present. Default controller set.
INFO - 2017-06-01 11:07:42 --> Router Class Initialized
INFO - 2017-06-01 11:07:42 --> Output Class Initialized
INFO - 2017-06-01 11:07:42 --> Security Class Initialized
DEBUG - 2017-06-01 11:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:07:42 --> CSRF cookie sent
INFO - 2017-06-01 11:07:42 --> Input Class Initialized
INFO - 2017-06-01 11:07:42 --> Language Class Initialized
INFO - 2017-06-01 11:07:42 --> Loader Class Initialized
INFO - 2017-06-01 11:07:42 --> Helper loaded: url_helper
INFO - 2017-06-01 11:07:42 --> Helper loaded: file_helper
INFO - 2017-06-01 11:07:42 --> Helper loaded: form_helper
INFO - 2017-06-01 11:07:42 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:07:42 --> Form Validation Class Initialized
INFO - 2017-06-01 11:07:42 --> Controller Class Initialized
INFO - 2017-06-01 11:07:42 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:07:42 --> Final output sent to browser
DEBUG - 2017-06-01 11:07:42 --> Total execution time: 0.3712
INFO - 2017-06-01 11:08:02 --> Config Class Initialized
INFO - 2017-06-01 11:08:02 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:02 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:02 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:02 --> URI Class Initialized
DEBUG - 2017-06-01 11:08:02 --> No URI present. Default controller set.
INFO - 2017-06-01 11:08:02 --> Router Class Initialized
INFO - 2017-06-01 11:08:02 --> Output Class Initialized
INFO - 2017-06-01 11:08:02 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:02 --> CSRF cookie sent
INFO - 2017-06-01 11:08:03 --> Input Class Initialized
INFO - 2017-06-01 11:08:03 --> Language Class Initialized
INFO - 2017-06-01 11:08:03 --> Loader Class Initialized
INFO - 2017-06-01 11:08:03 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:03 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:03 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:03 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:03 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:03 --> Controller Class Initialized
INFO - 2017-06-01 11:08:03 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:08:03 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:03 --> Total execution time: 0.3224
INFO - 2017-06-01 11:08:04 --> Config Class Initialized
INFO - 2017-06-01 11:08:04 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:04 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:04 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:04 --> URI Class Initialized
INFO - 2017-06-01 11:08:04 --> Router Class Initialized
INFO - 2017-06-01 11:08:04 --> Output Class Initialized
INFO - 2017-06-01 11:08:04 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:04 --> CSRF cookie sent
INFO - 2017-06-01 11:08:04 --> CSRF token verified
INFO - 2017-06-01 11:08:04 --> Input Class Initialized
INFO - 2017-06-01 11:08:04 --> Language Class Initialized
INFO - 2017-06-01 11:08:04 --> Loader Class Initialized
INFO - 2017-06-01 11:08:04 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:04 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:04 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:04 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:04 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:04 --> Controller Class Initialized
INFO - 2017-06-01 11:08:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:08:04 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:04 --> Total execution time: 0.2149
INFO - 2017-06-01 11:08:07 --> Config Class Initialized
INFO - 2017-06-01 11:08:07 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:07 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:07 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:07 --> URI Class Initialized
DEBUG - 2017-06-01 11:08:07 --> No URI present. Default controller set.
INFO - 2017-06-01 11:08:07 --> Router Class Initialized
INFO - 2017-06-01 11:08:07 --> Output Class Initialized
INFO - 2017-06-01 11:08:07 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:07 --> CSRF cookie sent
INFO - 2017-06-01 11:08:07 --> Input Class Initialized
INFO - 2017-06-01 11:08:07 --> Language Class Initialized
INFO - 2017-06-01 11:08:07 --> Loader Class Initialized
INFO - 2017-06-01 11:08:07 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:07 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:07 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:07 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:07 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:07 --> Controller Class Initialized
INFO - 2017-06-01 11:08:07 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:08:07 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:07 --> Total execution time: 0.2298
INFO - 2017-06-01 11:08:09 --> Config Class Initialized
INFO - 2017-06-01 11:08:09 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:09 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:09 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:09 --> URI Class Initialized
INFO - 2017-06-01 11:08:09 --> Router Class Initialized
INFO - 2017-06-01 11:08:09 --> Output Class Initialized
INFO - 2017-06-01 11:08:09 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:09 --> CSRF cookie sent
INFO - 2017-06-01 11:08:09 --> Input Class Initialized
INFO - 2017-06-01 11:08:09 --> Language Class Initialized
INFO - 2017-06-01 11:08:09 --> Loader Class Initialized
INFO - 2017-06-01 11:08:09 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:09 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:09 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:09 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:09 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:09 --> Controller Class Initialized
INFO - 2017-06-01 11:08:09 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:09 --> Total execution time: 0.1723
INFO - 2017-06-01 11:08:09 --> Config Class Initialized
INFO - 2017-06-01 11:08:09 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:09 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:09 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:09 --> URI Class Initialized
INFO - 2017-06-01 11:08:09 --> Router Class Initialized
INFO - 2017-06-01 11:08:09 --> Output Class Initialized
INFO - 2017-06-01 11:08:09 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:09 --> CSRF cookie sent
INFO - 2017-06-01 11:08:09 --> Input Class Initialized
INFO - 2017-06-01 11:08:09 --> Language Class Initialized
INFO - 2017-06-01 11:08:09 --> Loader Class Initialized
INFO - 2017-06-01 11:08:09 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:09 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:09 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:09 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:09 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:09 --> Controller Class Initialized
INFO - 2017-06-01 11:08:09 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:09 --> Total execution time: 0.2938
INFO - 2017-06-01 11:08:13 --> Config Class Initialized
INFO - 2017-06-01 11:08:14 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:08:14 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:08:14 --> Utf8 Class Initialized
INFO - 2017-06-01 11:08:14 --> URI Class Initialized
DEBUG - 2017-06-01 11:08:14 --> No URI present. Default controller set.
INFO - 2017-06-01 11:08:14 --> Router Class Initialized
INFO - 2017-06-01 11:08:14 --> Output Class Initialized
INFO - 2017-06-01 11:08:14 --> Security Class Initialized
DEBUG - 2017-06-01 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:08:14 --> CSRF cookie sent
INFO - 2017-06-01 11:08:14 --> Input Class Initialized
INFO - 2017-06-01 11:08:14 --> Language Class Initialized
INFO - 2017-06-01 11:08:14 --> Loader Class Initialized
INFO - 2017-06-01 11:08:14 --> Helper loaded: url_helper
INFO - 2017-06-01 11:08:14 --> Helper loaded: file_helper
INFO - 2017-06-01 11:08:14 --> Helper loaded: form_helper
INFO - 2017-06-01 11:08:14 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:08:14 --> Form Validation Class Initialized
INFO - 2017-06-01 11:08:14 --> Controller Class Initialized
INFO - 2017-06-01 11:08:14 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:08:14 --> Final output sent to browser
DEBUG - 2017-06-01 11:08:14 --> Total execution time: 0.3807
INFO - 2017-06-01 11:09:48 --> Config Class Initialized
INFO - 2017-06-01 11:09:48 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:09:48 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:09:48 --> Utf8 Class Initialized
INFO - 2017-06-01 11:09:48 --> URI Class Initialized
DEBUG - 2017-06-01 11:09:48 --> No URI present. Default controller set.
INFO - 2017-06-01 11:09:48 --> Router Class Initialized
INFO - 2017-06-01 11:09:48 --> Output Class Initialized
INFO - 2017-06-01 11:09:48 --> Security Class Initialized
DEBUG - 2017-06-01 11:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:09:48 --> CSRF cookie sent
INFO - 2017-06-01 11:09:48 --> Input Class Initialized
INFO - 2017-06-01 11:09:48 --> Language Class Initialized
INFO - 2017-06-01 11:09:48 --> Loader Class Initialized
INFO - 2017-06-01 11:09:48 --> Helper loaded: url_helper
INFO - 2017-06-01 11:09:48 --> Helper loaded: file_helper
INFO - 2017-06-01 11:09:48 --> Helper loaded: form_helper
INFO - 2017-06-01 11:09:48 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:09:48 --> Form Validation Class Initialized
INFO - 2017-06-01 11:09:48 --> Controller Class Initialized
INFO - 2017-06-01 11:09:48 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:09:48 --> Final output sent to browser
DEBUG - 2017-06-01 11:09:48 --> Total execution time: 0.5909
INFO - 2017-06-01 11:09:51 --> Config Class Initialized
INFO - 2017-06-01 11:09:51 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:09:51 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:09:51 --> Utf8 Class Initialized
INFO - 2017-06-01 11:09:51 --> URI Class Initialized
INFO - 2017-06-01 11:09:51 --> Router Class Initialized
INFO - 2017-06-01 11:09:51 --> Output Class Initialized
INFO - 2017-06-01 11:09:51 --> Security Class Initialized
DEBUG - 2017-06-01 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:09:51 --> CSRF cookie sent
INFO - 2017-06-01 11:09:51 --> CSRF token verified
INFO - 2017-06-01 11:09:51 --> Input Class Initialized
INFO - 2017-06-01 11:09:51 --> Language Class Initialized
INFO - 2017-06-01 11:09:51 --> Loader Class Initialized
INFO - 2017-06-01 11:09:51 --> Helper loaded: url_helper
INFO - 2017-06-01 11:09:51 --> Helper loaded: file_helper
INFO - 2017-06-01 11:09:51 --> Helper loaded: form_helper
INFO - 2017-06-01 11:09:51 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:09:51 --> Form Validation Class Initialized
INFO - 2017-06-01 11:09:51 --> Controller Class Initialized
INFO - 2017-06-01 11:09:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:09:51 --> Final output sent to browser
DEBUG - 2017-06-01 11:09:51 --> Total execution time: 0.2109
INFO - 2017-06-01 11:09:56 --> Config Class Initialized
INFO - 2017-06-01 11:09:56 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:09:56 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:09:56 --> Utf8 Class Initialized
INFO - 2017-06-01 11:09:56 --> URI Class Initialized
DEBUG - 2017-06-01 11:09:56 --> No URI present. Default controller set.
INFO - 2017-06-01 11:09:56 --> Router Class Initialized
INFO - 2017-06-01 11:09:56 --> Output Class Initialized
INFO - 2017-06-01 11:09:56 --> Security Class Initialized
DEBUG - 2017-06-01 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:09:56 --> CSRF cookie sent
INFO - 2017-06-01 11:09:56 --> Input Class Initialized
INFO - 2017-06-01 11:09:56 --> Language Class Initialized
INFO - 2017-06-01 11:09:56 --> Loader Class Initialized
INFO - 2017-06-01 11:09:56 --> Helper loaded: url_helper
INFO - 2017-06-01 11:09:56 --> Helper loaded: file_helper
INFO - 2017-06-01 11:09:56 --> Helper loaded: form_helper
INFO - 2017-06-01 11:09:56 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:09:56 --> Form Validation Class Initialized
INFO - 2017-06-01 11:09:56 --> Controller Class Initialized
INFO - 2017-06-01 11:09:56 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:09:56 --> Final output sent to browser
DEBUG - 2017-06-01 11:09:56 --> Total execution time: 0.1785
INFO - 2017-06-01 11:32:19 --> Config Class Initialized
INFO - 2017-06-01 11:32:19 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:32:19 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:32:19 --> Utf8 Class Initialized
INFO - 2017-06-01 11:32:19 --> URI Class Initialized
DEBUG - 2017-06-01 11:32:19 --> No URI present. Default controller set.
INFO - 2017-06-01 11:32:19 --> Router Class Initialized
INFO - 2017-06-01 11:32:19 --> Output Class Initialized
INFO - 2017-06-01 11:32:19 --> Security Class Initialized
DEBUG - 2017-06-01 11:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:32:19 --> CSRF cookie sent
INFO - 2017-06-01 11:32:19 --> Input Class Initialized
INFO - 2017-06-01 11:32:19 --> Language Class Initialized
INFO - 2017-06-01 11:32:19 --> Loader Class Initialized
INFO - 2017-06-01 11:32:19 --> Helper loaded: url_helper
INFO - 2017-06-01 11:32:19 --> Helper loaded: file_helper
INFO - 2017-06-01 11:32:19 --> Helper loaded: form_helper
INFO - 2017-06-01 11:32:19 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:32:20 --> Form Validation Class Initialized
INFO - 2017-06-01 11:32:20 --> Controller Class Initialized
INFO - 2017-06-01 11:32:20 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:32:20 --> Final output sent to browser
DEBUG - 2017-06-01 11:32:20 --> Total execution time: 1.0937
INFO - 2017-06-01 11:32:32 --> Config Class Initialized
INFO - 2017-06-01 11:32:32 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:32:32 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:32:32 --> Utf8 Class Initialized
INFO - 2017-06-01 11:32:32 --> URI Class Initialized
INFO - 2017-06-01 11:32:32 --> Router Class Initialized
INFO - 2017-06-01 11:32:32 --> Output Class Initialized
INFO - 2017-06-01 11:32:32 --> Security Class Initialized
DEBUG - 2017-06-01 11:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:32:32 --> CSRF cookie sent
INFO - 2017-06-01 11:32:32 --> CSRF token verified
INFO - 2017-06-01 11:32:32 --> Input Class Initialized
INFO - 2017-06-01 11:32:32 --> Language Class Initialized
INFO - 2017-06-01 11:32:32 --> Loader Class Initialized
INFO - 2017-06-01 11:32:32 --> Helper loaded: url_helper
INFO - 2017-06-01 11:32:32 --> Helper loaded: file_helper
INFO - 2017-06-01 11:32:32 --> Helper loaded: form_helper
INFO - 2017-06-01 11:32:32 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:32:32 --> Form Validation Class Initialized
INFO - 2017-06-01 11:32:32 --> Controller Class Initialized
INFO - 2017-06-01 11:32:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:32:32 --> Final output sent to browser
DEBUG - 2017-06-01 11:32:32 --> Total execution time: 0.3498
INFO - 2017-06-01 11:46:22 --> Config Class Initialized
INFO - 2017-06-01 11:46:22 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:46:22 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:46:22 --> Utf8 Class Initialized
INFO - 2017-06-01 11:46:23 --> URI Class Initialized
DEBUG - 2017-06-01 11:46:23 --> No URI present. Default controller set.
INFO - 2017-06-01 11:46:23 --> Router Class Initialized
INFO - 2017-06-01 11:46:23 --> Output Class Initialized
INFO - 2017-06-01 11:46:23 --> Security Class Initialized
DEBUG - 2017-06-01 11:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:46:23 --> CSRF cookie sent
INFO - 2017-06-01 11:46:23 --> Input Class Initialized
INFO - 2017-06-01 11:46:23 --> Language Class Initialized
INFO - 2017-06-01 11:46:23 --> Loader Class Initialized
INFO - 2017-06-01 11:46:23 --> Helper loaded: url_helper
INFO - 2017-06-01 11:46:23 --> Helper loaded: file_helper
INFO - 2017-06-01 11:46:23 --> Helper loaded: form_helper
INFO - 2017-06-01 11:46:23 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:46:24 --> Form Validation Class Initialized
INFO - 2017-06-01 11:46:24 --> Controller Class Initialized
INFO - 2017-06-01 11:46:24 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:46:24 --> Final output sent to browser
DEBUG - 2017-06-01 11:46:24 --> Total execution time: 2.0187
INFO - 2017-06-01 11:46:28 --> Config Class Initialized
INFO - 2017-06-01 11:46:28 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:46:28 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:46:28 --> Utf8 Class Initialized
INFO - 2017-06-01 11:46:28 --> URI Class Initialized
INFO - 2017-06-01 11:46:28 --> Router Class Initialized
INFO - 2017-06-01 11:46:28 --> Output Class Initialized
INFO - 2017-06-01 11:46:28 --> Security Class Initialized
DEBUG - 2017-06-01 11:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:46:28 --> CSRF cookie sent
INFO - 2017-06-01 11:46:28 --> CSRF token verified
INFO - 2017-06-01 11:46:28 --> Input Class Initialized
INFO - 2017-06-01 11:46:28 --> Language Class Initialized
INFO - 2017-06-01 11:46:28 --> Loader Class Initialized
INFO - 2017-06-01 11:46:28 --> Helper loaded: url_helper
INFO - 2017-06-01 11:46:28 --> Helper loaded: file_helper
INFO - 2017-06-01 11:46:28 --> Helper loaded: form_helper
INFO - 2017-06-01 11:46:28 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:46:28 --> Form Validation Class Initialized
INFO - 2017-06-01 11:46:28 --> Controller Class Initialized
INFO - 2017-06-01 11:46:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:46:28 --> Final output sent to browser
DEBUG - 2017-06-01 11:46:28 --> Total execution time: 0.4002
INFO - 2017-06-01 11:46:33 --> Config Class Initialized
INFO - 2017-06-01 11:46:33 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:46:33 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:46:33 --> Utf8 Class Initialized
INFO - 2017-06-01 11:46:33 --> URI Class Initialized
DEBUG - 2017-06-01 11:46:33 --> No URI present. Default controller set.
INFO - 2017-06-01 11:46:33 --> Router Class Initialized
INFO - 2017-06-01 11:46:33 --> Output Class Initialized
INFO - 2017-06-01 11:46:33 --> Security Class Initialized
DEBUG - 2017-06-01 11:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:46:33 --> CSRF cookie sent
INFO - 2017-06-01 11:46:33 --> Input Class Initialized
INFO - 2017-06-01 11:46:33 --> Language Class Initialized
INFO - 2017-06-01 11:46:33 --> Loader Class Initialized
INFO - 2017-06-01 11:46:33 --> Helper loaded: url_helper
INFO - 2017-06-01 11:46:33 --> Helper loaded: file_helper
INFO - 2017-06-01 11:46:33 --> Helper loaded: form_helper
INFO - 2017-06-01 11:46:33 --> Database Driver Class Initialized
DEBUG - 2017-06-01 11:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-06-01 11:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-01 11:46:33 --> Form Validation Class Initialized
INFO - 2017-06-01 11:46:33 --> Controller Class Initialized
INFO - 2017-06-01 11:46:33 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:46:33 --> Final output sent to browser
DEBUG - 2017-06-01 11:46:33 --> Total execution time: 0.2566
INFO - 2017-06-01 11:48:34 --> Config Class Initialized
INFO - 2017-06-01 11:48:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:48:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:48:34 --> Utf8 Class Initialized
INFO - 2017-06-01 11:48:34 --> URI Class Initialized
DEBUG - 2017-06-01 11:48:35 --> No URI present. Default controller set.
INFO - 2017-06-01 11:48:35 --> Router Class Initialized
INFO - 2017-06-01 11:48:35 --> Output Class Initialized
INFO - 2017-06-01 11:48:35 --> Security Class Initialized
DEBUG - 2017-06-01 11:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:48:35 --> CSRF cookie sent
INFO - 2017-06-01 11:48:35 --> Input Class Initialized
INFO - 2017-06-01 11:48:35 --> Language Class Initialized
INFO - 2017-06-01 11:48:35 --> Loader Class Initialized
INFO - 2017-06-01 11:48:35 --> Helper loaded: url_helper
INFO - 2017-06-01 11:48:35 --> Helper loaded: file_helper
INFO - 2017-06-01 11:48:35 --> Helper loaded: form_helper
INFO - 2017-06-01 11:48:35 --> Form Validation Class Initialized
INFO - 2017-06-01 11:48:35 --> Controller Class Initialized
INFO - 2017-06-01 11:48:35 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:48:35 --> Final output sent to browser
DEBUG - 2017-06-01 11:48:35 --> Total execution time: 0.1518
INFO - 2017-06-01 11:48:36 --> Config Class Initialized
INFO - 2017-06-01 11:48:36 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:48:36 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:48:36 --> Utf8 Class Initialized
INFO - 2017-06-01 11:48:36 --> URI Class Initialized
INFO - 2017-06-01 11:48:36 --> Router Class Initialized
INFO - 2017-06-01 11:48:36 --> Output Class Initialized
INFO - 2017-06-01 11:48:36 --> Security Class Initialized
DEBUG - 2017-06-01 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:48:36 --> CSRF cookie sent
INFO - 2017-06-01 11:48:36 --> CSRF token verified
INFO - 2017-06-01 11:48:36 --> Input Class Initialized
INFO - 2017-06-01 11:48:36 --> Language Class Initialized
INFO - 2017-06-01 11:48:36 --> Loader Class Initialized
INFO - 2017-06-01 11:48:36 --> Helper loaded: url_helper
INFO - 2017-06-01 11:48:36 --> Helper loaded: file_helper
INFO - 2017-06-01 11:48:36 --> Helper loaded: form_helper
INFO - 2017-06-01 11:48:36 --> Form Validation Class Initialized
INFO - 2017-06-01 11:48:36 --> Controller Class Initialized
INFO - 2017-06-01 11:48:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 11:48:36 --> Final output sent to browser
DEBUG - 2017-06-01 11:48:36 --> Total execution time: 0.2564
INFO - 2017-06-01 11:49:06 --> Config Class Initialized
INFO - 2017-06-01 11:49:06 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:06 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:06 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:06 --> URI Class Initialized
DEBUG - 2017-06-01 11:49:06 --> No URI present. Default controller set.
INFO - 2017-06-01 11:49:06 --> Router Class Initialized
INFO - 2017-06-01 11:49:06 --> Output Class Initialized
INFO - 2017-06-01 11:49:06 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:06 --> CSRF cookie sent
INFO - 2017-06-01 11:49:06 --> Input Class Initialized
INFO - 2017-06-01 11:49:06 --> Language Class Initialized
INFO - 2017-06-01 11:49:06 --> Loader Class Initialized
INFO - 2017-06-01 11:49:06 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:06 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:06 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:06 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:06 --> Controller Class Initialized
INFO - 2017-06-01 11:49:07 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:49:07 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:07 --> Total execution time: 0.1529
INFO - 2017-06-01 11:49:08 --> Config Class Initialized
INFO - 2017-06-01 11:49:08 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:08 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:08 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:08 --> URI Class Initialized
INFO - 2017-06-01 11:49:08 --> Router Class Initialized
INFO - 2017-06-01 11:49:08 --> Output Class Initialized
INFO - 2017-06-01 11:49:08 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:08 --> CSRF cookie sent
INFO - 2017-06-01 11:49:08 --> CSRF token verified
INFO - 2017-06-01 11:49:08 --> Input Class Initialized
INFO - 2017-06-01 11:49:08 --> Language Class Initialized
INFO - 2017-06-01 11:49:08 --> Loader Class Initialized
INFO - 2017-06-01 11:49:08 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:08 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:08 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:08 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:08 --> Controller Class Initialized
INFO - 2017-06-01 11:49:08 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:08 --> Total execution time: 0.1913
INFO - 2017-06-01 11:49:26 --> Config Class Initialized
INFO - 2017-06-01 11:49:26 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:26 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:26 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:26 --> URI Class Initialized
DEBUG - 2017-06-01 11:49:26 --> No URI present. Default controller set.
INFO - 2017-06-01 11:49:26 --> Router Class Initialized
INFO - 2017-06-01 11:49:26 --> Output Class Initialized
INFO - 2017-06-01 11:49:26 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:26 --> CSRF cookie sent
INFO - 2017-06-01 11:49:26 --> Input Class Initialized
INFO - 2017-06-01 11:49:26 --> Language Class Initialized
INFO - 2017-06-01 11:49:26 --> Loader Class Initialized
INFO - 2017-06-01 11:49:26 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:26 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:26 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:26 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:26 --> Controller Class Initialized
INFO - 2017-06-01 11:49:26 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:49:26 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:26 --> Total execution time: 0.1482
INFO - 2017-06-01 11:49:30 --> Config Class Initialized
INFO - 2017-06-01 11:49:30 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:30 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:30 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:30 --> URI Class Initialized
INFO - 2017-06-01 11:49:30 --> Router Class Initialized
INFO - 2017-06-01 11:49:30 --> Output Class Initialized
INFO - 2017-06-01 11:49:30 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:30 --> CSRF cookie sent
INFO - 2017-06-01 11:49:30 --> CSRF token verified
INFO - 2017-06-01 11:49:30 --> Input Class Initialized
INFO - 2017-06-01 11:49:30 --> Language Class Initialized
INFO - 2017-06-01 11:49:30 --> Loader Class Initialized
INFO - 2017-06-01 11:49:30 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:30 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:30 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:30 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:30 --> Controller Class Initialized
INFO - 2017-06-01 11:49:30 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:30 --> Total execution time: 0.1646
INFO - 2017-06-01 11:49:42 --> Config Class Initialized
INFO - 2017-06-01 11:49:42 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:42 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:42 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:42 --> URI Class Initialized
DEBUG - 2017-06-01 11:49:42 --> No URI present. Default controller set.
INFO - 2017-06-01 11:49:42 --> Router Class Initialized
INFO - 2017-06-01 11:49:42 --> Output Class Initialized
INFO - 2017-06-01 11:49:42 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:42 --> CSRF cookie sent
INFO - 2017-06-01 11:49:42 --> Input Class Initialized
INFO - 2017-06-01 11:49:42 --> Language Class Initialized
INFO - 2017-06-01 11:49:42 --> Loader Class Initialized
INFO - 2017-06-01 11:49:42 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:42 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:42 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:42 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:42 --> Controller Class Initialized
INFO - 2017-06-01 11:49:42 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:49:42 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:42 --> Total execution time: 0.1518
INFO - 2017-06-01 11:49:47 --> Config Class Initialized
INFO - 2017-06-01 11:49:47 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:49:47 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:49:47 --> Utf8 Class Initialized
INFO - 2017-06-01 11:49:47 --> URI Class Initialized
INFO - 2017-06-01 11:49:47 --> Router Class Initialized
INFO - 2017-06-01 11:49:47 --> Output Class Initialized
INFO - 2017-06-01 11:49:47 --> Security Class Initialized
DEBUG - 2017-06-01 11:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:49:47 --> CSRF cookie sent
INFO - 2017-06-01 11:49:47 --> CSRF token verified
INFO - 2017-06-01 11:49:47 --> Input Class Initialized
INFO - 2017-06-01 11:49:47 --> Language Class Initialized
INFO - 2017-06-01 11:49:47 --> Loader Class Initialized
INFO - 2017-06-01 11:49:47 --> Helper loaded: url_helper
INFO - 2017-06-01 11:49:47 --> Helper loaded: file_helper
INFO - 2017-06-01 11:49:47 --> Helper loaded: form_helper
INFO - 2017-06-01 11:49:47 --> Form Validation Class Initialized
INFO - 2017-06-01 11:49:47 --> Controller Class Initialized
INFO - 2017-06-01 11:49:47 --> Final output sent to browser
DEBUG - 2017-06-01 11:49:47 --> Total execution time: 0.1503
INFO - 2017-06-01 11:50:15 --> Config Class Initialized
INFO - 2017-06-01 11:50:15 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:50:15 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:50:15 --> Utf8 Class Initialized
INFO - 2017-06-01 11:50:15 --> URI Class Initialized
INFO - 2017-06-01 11:50:15 --> Router Class Initialized
INFO - 2017-06-01 11:50:15 --> Output Class Initialized
INFO - 2017-06-01 11:50:15 --> Security Class Initialized
DEBUG - 2017-06-01 11:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:50:15 --> CSRF cookie sent
INFO - 2017-06-01 11:59:44 --> Config Class Initialized
INFO - 2017-06-01 11:59:44 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:59:44 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:59:44 --> Utf8 Class Initialized
INFO - 2017-06-01 11:59:44 --> URI Class Initialized
DEBUG - 2017-06-01 11:59:44 --> No URI present. Default controller set.
INFO - 2017-06-01 11:59:44 --> Router Class Initialized
INFO - 2017-06-01 11:59:44 --> Output Class Initialized
INFO - 2017-06-01 11:59:44 --> Security Class Initialized
DEBUG - 2017-06-01 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:59:44 --> CSRF cookie sent
INFO - 2017-06-01 11:59:44 --> Input Class Initialized
INFO - 2017-06-01 11:59:44 --> Language Class Initialized
INFO - 2017-06-01 11:59:44 --> Loader Class Initialized
INFO - 2017-06-01 11:59:44 --> Helper loaded: url_helper
INFO - 2017-06-01 11:59:44 --> Helper loaded: file_helper
INFO - 2017-06-01 11:59:44 --> Helper loaded: form_helper
INFO - 2017-06-01 11:59:44 --> Form Validation Class Initialized
INFO - 2017-06-01 11:59:44 --> Controller Class Initialized
INFO - 2017-06-01 11:59:44 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 11:59:44 --> Final output sent to browser
DEBUG - 2017-06-01 11:59:44 --> Total execution time: 0.2318
INFO - 2017-06-01 11:59:46 --> Config Class Initialized
INFO - 2017-06-01 11:59:46 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:59:46 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:59:46 --> Utf8 Class Initialized
INFO - 2017-06-01 11:59:46 --> URI Class Initialized
INFO - 2017-06-01 11:59:46 --> Router Class Initialized
INFO - 2017-06-01 11:59:46 --> Output Class Initialized
INFO - 2017-06-01 11:59:46 --> Security Class Initialized
DEBUG - 2017-06-01 11:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:59:46 --> CSRF cookie sent
INFO - 2017-06-01 11:59:46 --> CSRF token verified
INFO - 2017-06-01 11:59:46 --> Input Class Initialized
INFO - 2017-06-01 11:59:46 --> Language Class Initialized
INFO - 2017-06-01 11:59:46 --> Loader Class Initialized
INFO - 2017-06-01 11:59:46 --> Helper loaded: url_helper
INFO - 2017-06-01 11:59:46 --> Helper loaded: file_helper
INFO - 2017-06-01 11:59:46 --> Helper loaded: form_helper
INFO - 2017-06-01 11:59:46 --> Form Validation Class Initialized
INFO - 2017-06-01 11:59:46 --> Controller Class Initialized
INFO - 2017-06-01 11:59:46 --> Final output sent to browser
DEBUG - 2017-06-01 11:59:46 --> Total execution time: 0.1668
INFO - 2017-06-01 11:59:52 --> Config Class Initialized
INFO - 2017-06-01 11:59:52 --> Hooks Class Initialized
DEBUG - 2017-06-01 11:59:52 --> UTF-8 Support Enabled
INFO - 2017-06-01 11:59:52 --> Utf8 Class Initialized
INFO - 2017-06-01 11:59:52 --> URI Class Initialized
INFO - 2017-06-01 11:59:52 --> Router Class Initialized
INFO - 2017-06-01 11:59:52 --> Output Class Initialized
INFO - 2017-06-01 11:59:52 --> Security Class Initialized
DEBUG - 2017-06-01 11:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 11:59:52 --> CSRF cookie sent
INFO - 2017-06-01 12:00:32 --> Config Class Initialized
INFO - 2017-06-01 12:00:32 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:00:32 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:00:32 --> Utf8 Class Initialized
INFO - 2017-06-01 12:00:32 --> URI Class Initialized
DEBUG - 2017-06-01 12:00:32 --> No URI present. Default controller set.
INFO - 2017-06-01 12:00:32 --> Router Class Initialized
INFO - 2017-06-01 12:00:32 --> Output Class Initialized
INFO - 2017-06-01 12:00:32 --> Security Class Initialized
DEBUG - 2017-06-01 12:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:00:32 --> CSRF cookie sent
INFO - 2017-06-01 12:00:32 --> Input Class Initialized
INFO - 2017-06-01 12:00:32 --> Language Class Initialized
INFO - 2017-06-01 12:00:32 --> Loader Class Initialized
INFO - 2017-06-01 12:00:32 --> Helper loaded: url_helper
INFO - 2017-06-01 12:00:32 --> Helper loaded: file_helper
INFO - 2017-06-01 12:00:32 --> Helper loaded: form_helper
INFO - 2017-06-01 12:00:32 --> Form Validation Class Initialized
INFO - 2017-06-01 12:00:32 --> Controller Class Initialized
INFO - 2017-06-01 12:00:32 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:00:32 --> Final output sent to browser
DEBUG - 2017-06-01 12:00:32 --> Total execution time: 0.1616
INFO - 2017-06-01 12:00:36 --> Config Class Initialized
INFO - 2017-06-01 12:00:36 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:00:36 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:00:36 --> Utf8 Class Initialized
INFO - 2017-06-01 12:00:37 --> URI Class Initialized
INFO - 2017-06-01 12:00:37 --> Router Class Initialized
INFO - 2017-06-01 12:00:37 --> Output Class Initialized
INFO - 2017-06-01 12:00:37 --> Security Class Initialized
DEBUG - 2017-06-01 12:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:00:37 --> CSRF cookie sent
INFO - 2017-06-01 12:00:37 --> CSRF token verified
INFO - 2017-06-01 12:00:37 --> Input Class Initialized
INFO - 2017-06-01 12:00:37 --> Language Class Initialized
INFO - 2017-06-01 12:00:37 --> Loader Class Initialized
INFO - 2017-06-01 12:00:37 --> Helper loaded: url_helper
INFO - 2017-06-01 12:00:37 --> Helper loaded: file_helper
INFO - 2017-06-01 12:00:37 --> Helper loaded: form_helper
INFO - 2017-06-01 12:00:37 --> Form Validation Class Initialized
INFO - 2017-06-01 12:00:37 --> Controller Class Initialized
INFO - 2017-06-01 12:00:37 --> Final output sent to browser
DEBUG - 2017-06-01 12:00:37 --> Total execution time: 0.1849
INFO - 2017-06-01 12:03:33 --> Config Class Initialized
INFO - 2017-06-01 12:03:33 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:03:33 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:03:33 --> Utf8 Class Initialized
INFO - 2017-06-01 12:03:33 --> URI Class Initialized
DEBUG - 2017-06-01 12:03:33 --> No URI present. Default controller set.
INFO - 2017-06-01 12:03:33 --> Router Class Initialized
INFO - 2017-06-01 12:03:33 --> Output Class Initialized
INFO - 2017-06-01 12:03:33 --> Security Class Initialized
DEBUG - 2017-06-01 12:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:03:33 --> CSRF cookie sent
INFO - 2017-06-01 12:03:33 --> Input Class Initialized
INFO - 2017-06-01 12:03:33 --> Language Class Initialized
INFO - 2017-06-01 12:03:33 --> Loader Class Initialized
INFO - 2017-06-01 12:03:33 --> Helper loaded: url_helper
INFO - 2017-06-01 12:03:33 --> Helper loaded: file_helper
INFO - 2017-06-01 12:03:33 --> Helper loaded: form_helper
INFO - 2017-06-01 12:03:33 --> Form Validation Class Initialized
INFO - 2017-06-01 12:03:33 --> Controller Class Initialized
INFO - 2017-06-01 12:03:33 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:03:33 --> Final output sent to browser
DEBUG - 2017-06-01 12:03:33 --> Total execution time: 0.2014
INFO - 2017-06-01 12:03:34 --> Config Class Initialized
INFO - 2017-06-01 12:03:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:03:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:03:34 --> Utf8 Class Initialized
INFO - 2017-06-01 12:03:34 --> URI Class Initialized
INFO - 2017-06-01 12:03:34 --> Router Class Initialized
INFO - 2017-06-01 12:03:34 --> Output Class Initialized
INFO - 2017-06-01 12:03:34 --> Security Class Initialized
DEBUG - 2017-06-01 12:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:03:34 --> CSRF cookie sent
INFO - 2017-06-01 12:03:34 --> CSRF token verified
INFO - 2017-06-01 12:03:34 --> Input Class Initialized
INFO - 2017-06-01 12:03:34 --> Language Class Initialized
INFO - 2017-06-01 12:03:34 --> Loader Class Initialized
INFO - 2017-06-01 12:03:34 --> Helper loaded: url_helper
INFO - 2017-06-01 12:03:34 --> Helper loaded: file_helper
INFO - 2017-06-01 12:03:34 --> Helper loaded: form_helper
INFO - 2017-06-01 12:03:34 --> Form Validation Class Initialized
INFO - 2017-06-01 12:03:35 --> Controller Class Initialized
INFO - 2017-06-01 12:03:35 --> Final output sent to browser
DEBUG - 2017-06-01 12:03:35 --> Total execution time: 0.2194
INFO - 2017-06-01 12:03:53 --> Config Class Initialized
INFO - 2017-06-01 12:03:53 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:03:53 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:03:53 --> Utf8 Class Initialized
INFO - 2017-06-01 12:03:53 --> URI Class Initialized
DEBUG - 2017-06-01 12:03:53 --> No URI present. Default controller set.
INFO - 2017-06-01 12:03:53 --> Router Class Initialized
INFO - 2017-06-01 12:03:53 --> Output Class Initialized
INFO - 2017-06-01 12:03:53 --> Security Class Initialized
DEBUG - 2017-06-01 12:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:03:53 --> CSRF cookie sent
INFO - 2017-06-01 12:03:53 --> Input Class Initialized
INFO - 2017-06-01 12:03:53 --> Language Class Initialized
INFO - 2017-06-01 12:03:53 --> Loader Class Initialized
INFO - 2017-06-01 12:03:53 --> Helper loaded: url_helper
INFO - 2017-06-01 12:03:53 --> Helper loaded: file_helper
INFO - 2017-06-01 12:03:53 --> Helper loaded: form_helper
INFO - 2017-06-01 12:03:53 --> Form Validation Class Initialized
INFO - 2017-06-01 12:03:53 --> Controller Class Initialized
INFO - 2017-06-01 12:03:53 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:03:53 --> Final output sent to browser
DEBUG - 2017-06-01 12:03:53 --> Total execution time: 0.1738
INFO - 2017-06-01 12:03:54 --> Config Class Initialized
INFO - 2017-06-01 12:03:54 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:03:55 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:03:55 --> Utf8 Class Initialized
INFO - 2017-06-01 12:03:55 --> URI Class Initialized
INFO - 2017-06-01 12:03:55 --> Router Class Initialized
INFO - 2017-06-01 12:03:55 --> Output Class Initialized
INFO - 2017-06-01 12:03:55 --> Security Class Initialized
DEBUG - 2017-06-01 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:03:55 --> CSRF cookie sent
INFO - 2017-06-01 12:03:55 --> CSRF token verified
INFO - 2017-06-01 12:03:55 --> Input Class Initialized
INFO - 2017-06-01 12:03:55 --> Language Class Initialized
INFO - 2017-06-01 12:03:55 --> Loader Class Initialized
INFO - 2017-06-01 12:03:55 --> Helper loaded: url_helper
INFO - 2017-06-01 12:03:55 --> Helper loaded: file_helper
INFO - 2017-06-01 12:03:55 --> Helper loaded: form_helper
INFO - 2017-06-01 12:03:55 --> Form Validation Class Initialized
INFO - 2017-06-01 12:03:55 --> Controller Class Initialized
INFO - 2017-06-01 12:03:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:03:55 --> Final output sent to browser
DEBUG - 2017-06-01 12:03:55 --> Total execution time: 0.2230
INFO - 2017-06-01 12:05:16 --> Config Class Initialized
INFO - 2017-06-01 12:05:16 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:05:16 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:05:16 --> Utf8 Class Initialized
INFO - 2017-06-01 12:05:16 --> URI Class Initialized
DEBUG - 2017-06-01 12:05:16 --> No URI present. Default controller set.
INFO - 2017-06-01 12:05:16 --> Router Class Initialized
INFO - 2017-06-01 12:05:16 --> Output Class Initialized
INFO - 2017-06-01 12:05:16 --> Security Class Initialized
DEBUG - 2017-06-01 12:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:05:16 --> CSRF cookie sent
INFO - 2017-06-01 12:05:16 --> Input Class Initialized
INFO - 2017-06-01 12:05:16 --> Language Class Initialized
INFO - 2017-06-01 12:05:16 --> Loader Class Initialized
INFO - 2017-06-01 12:05:16 --> Helper loaded: url_helper
INFO - 2017-06-01 12:05:16 --> Helper loaded: file_helper
INFO - 2017-06-01 12:05:16 --> Helper loaded: form_helper
INFO - 2017-06-01 12:05:16 --> Form Validation Class Initialized
INFO - 2017-06-01 12:05:16 --> Controller Class Initialized
INFO - 2017-06-01 12:05:16 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:05:16 --> Final output sent to browser
DEBUG - 2017-06-01 12:05:16 --> Total execution time: 0.1667
INFO - 2017-06-01 12:05:18 --> Config Class Initialized
INFO - 2017-06-01 12:05:18 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:05:18 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:05:18 --> Utf8 Class Initialized
INFO - 2017-06-01 12:05:18 --> URI Class Initialized
INFO - 2017-06-01 12:05:18 --> Router Class Initialized
INFO - 2017-06-01 12:05:18 --> Output Class Initialized
INFO - 2017-06-01 12:05:18 --> Security Class Initialized
DEBUG - 2017-06-01 12:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:05:18 --> CSRF cookie sent
INFO - 2017-06-01 12:05:18 --> CSRF token verified
INFO - 2017-06-01 12:05:18 --> Input Class Initialized
INFO - 2017-06-01 12:05:18 --> Language Class Initialized
INFO - 2017-06-01 12:05:18 --> Loader Class Initialized
INFO - 2017-06-01 12:05:18 --> Helper loaded: url_helper
INFO - 2017-06-01 12:05:18 --> Helper loaded: file_helper
INFO - 2017-06-01 12:05:18 --> Helper loaded: form_helper
INFO - 2017-06-01 12:05:18 --> Form Validation Class Initialized
INFO - 2017-06-01 12:05:18 --> Controller Class Initialized
INFO - 2017-06-01 12:05:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:05:18 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:05:18 --> Final output sent to browser
DEBUG - 2017-06-01 12:05:18 --> Total execution time: 0.2328
INFO - 2017-06-01 12:07:26 --> Config Class Initialized
INFO - 2017-06-01 12:07:26 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:07:26 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:07:26 --> Utf8 Class Initialized
INFO - 2017-06-01 12:07:26 --> URI Class Initialized
INFO - 2017-06-01 12:07:26 --> Router Class Initialized
INFO - 2017-06-01 12:07:26 --> Output Class Initialized
INFO - 2017-06-01 12:07:26 --> Security Class Initialized
DEBUG - 2017-06-01 12:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:07:26 --> CSRF cookie sent
INFO - 2017-06-01 12:07:26 --> CSRF token verified
INFO - 2017-06-01 12:07:26 --> Input Class Initialized
INFO - 2017-06-01 12:07:26 --> Language Class Initialized
INFO - 2017-06-01 12:07:26 --> Loader Class Initialized
INFO - 2017-06-01 12:07:26 --> Helper loaded: url_helper
INFO - 2017-06-01 12:07:26 --> Helper loaded: file_helper
INFO - 2017-06-01 12:07:26 --> Helper loaded: form_helper
INFO - 2017-06-01 12:07:26 --> Form Validation Class Initialized
INFO - 2017-06-01 12:07:26 --> Controller Class Initialized
INFO - 2017-06-01 12:07:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:07:26 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:07:26 --> Final output sent to browser
DEBUG - 2017-06-01 12:07:26 --> Total execution time: 0.1927
INFO - 2017-06-01 12:07:34 --> Config Class Initialized
INFO - 2017-06-01 12:07:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:07:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:07:34 --> Utf8 Class Initialized
INFO - 2017-06-01 12:07:34 --> URI Class Initialized
INFO - 2017-06-01 12:07:34 --> Router Class Initialized
INFO - 2017-06-01 12:07:34 --> Output Class Initialized
INFO - 2017-06-01 12:07:34 --> Security Class Initialized
DEBUG - 2017-06-01 12:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:07:34 --> CSRF cookie sent
INFO - 2017-06-01 12:07:34 --> CSRF token verified
INFO - 2017-06-01 12:07:34 --> Input Class Initialized
INFO - 2017-06-01 12:07:34 --> Language Class Initialized
INFO - 2017-06-01 12:07:34 --> Loader Class Initialized
INFO - 2017-06-01 12:07:34 --> Helper loaded: url_helper
INFO - 2017-06-01 12:07:34 --> Helper loaded: file_helper
INFO - 2017-06-01 12:07:34 --> Helper loaded: form_helper
INFO - 2017-06-01 12:07:34 --> Form Validation Class Initialized
INFO - 2017-06-01 12:07:34 --> Controller Class Initialized
INFO - 2017-06-01 12:07:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:07:34 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:07:34 --> Final output sent to browser
DEBUG - 2017-06-01 12:07:34 --> Total execution time: 0.2025
INFO - 2017-06-01 12:07:42 --> Config Class Initialized
INFO - 2017-06-01 12:07:42 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:07:42 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:07:43 --> Utf8 Class Initialized
INFO - 2017-06-01 12:07:43 --> URI Class Initialized
INFO - 2017-06-01 12:07:43 --> Router Class Initialized
INFO - 2017-06-01 12:07:43 --> Output Class Initialized
INFO - 2017-06-01 12:07:43 --> Security Class Initialized
DEBUG - 2017-06-01 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:07:43 --> CSRF cookie sent
INFO - 2017-06-01 12:07:43 --> CSRF token verified
INFO - 2017-06-01 12:07:43 --> Input Class Initialized
INFO - 2017-06-01 12:07:43 --> Language Class Initialized
INFO - 2017-06-01 12:07:43 --> Loader Class Initialized
INFO - 2017-06-01 12:07:43 --> Helper loaded: url_helper
INFO - 2017-06-01 12:07:43 --> Helper loaded: file_helper
INFO - 2017-06-01 12:07:43 --> Helper loaded: form_helper
INFO - 2017-06-01 12:07:43 --> Form Validation Class Initialized
INFO - 2017-06-01 12:07:43 --> Controller Class Initialized
INFO - 2017-06-01 12:07:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:07:43 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:07:43 --> Final output sent to browser
DEBUG - 2017-06-01 12:07:43 --> Total execution time: 0.1905
INFO - 2017-06-01 12:07:50 --> Config Class Initialized
INFO - 2017-06-01 12:07:50 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:07:50 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:07:50 --> Utf8 Class Initialized
INFO - 2017-06-01 12:07:50 --> URI Class Initialized
INFO - 2017-06-01 12:07:50 --> Router Class Initialized
INFO - 2017-06-01 12:07:50 --> Output Class Initialized
INFO - 2017-06-01 12:07:50 --> Security Class Initialized
DEBUG - 2017-06-01 12:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:07:50 --> CSRF cookie sent
INFO - 2017-06-01 12:07:50 --> CSRF token verified
INFO - 2017-06-01 12:07:50 --> Input Class Initialized
INFO - 2017-06-01 12:07:50 --> Language Class Initialized
INFO - 2017-06-01 12:07:50 --> Loader Class Initialized
INFO - 2017-06-01 12:07:50 --> Helper loaded: url_helper
INFO - 2017-06-01 12:07:50 --> Helper loaded: file_helper
INFO - 2017-06-01 12:07:50 --> Helper loaded: form_helper
INFO - 2017-06-01 12:07:50 --> Form Validation Class Initialized
INFO - 2017-06-01 12:07:50 --> Controller Class Initialized
INFO - 2017-06-01 12:07:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:07:50 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:07:50 --> Final output sent to browser
DEBUG - 2017-06-01 12:07:50 --> Total execution time: 0.1964
INFO - 2017-06-01 12:07:56 --> Config Class Initialized
INFO - 2017-06-01 12:07:56 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:07:56 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:07:56 --> Utf8 Class Initialized
INFO - 2017-06-01 12:07:56 --> URI Class Initialized
INFO - 2017-06-01 12:07:56 --> Router Class Initialized
INFO - 2017-06-01 12:07:56 --> Output Class Initialized
INFO - 2017-06-01 12:07:56 --> Security Class Initialized
DEBUG - 2017-06-01 12:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:07:56 --> CSRF cookie sent
INFO - 2017-06-01 12:07:56 --> CSRF token verified
INFO - 2017-06-01 12:07:56 --> Input Class Initialized
INFO - 2017-06-01 12:07:56 --> Language Class Initialized
INFO - 2017-06-01 12:07:56 --> Loader Class Initialized
INFO - 2017-06-01 12:07:56 --> Helper loaded: url_helper
INFO - 2017-06-01 12:07:56 --> Helper loaded: file_helper
INFO - 2017-06-01 12:07:56 --> Helper loaded: form_helper
INFO - 2017-06-01 12:07:56 --> Form Validation Class Initialized
INFO - 2017-06-01 12:07:56 --> Controller Class Initialized
INFO - 2017-06-01 12:07:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:07:56 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:07:56 --> Final output sent to browser
DEBUG - 2017-06-01 12:07:56 --> Total execution time: 0.2231
INFO - 2017-06-01 12:08:00 --> Config Class Initialized
INFO - 2017-06-01 12:08:00 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:00 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:00 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:00 --> URI Class Initialized
INFO - 2017-06-01 12:08:00 --> Router Class Initialized
INFO - 2017-06-01 12:08:00 --> Output Class Initialized
INFO - 2017-06-01 12:08:00 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:00 --> CSRF cookie sent
INFO - 2017-06-01 12:08:00 --> CSRF token verified
INFO - 2017-06-01 12:08:00 --> Input Class Initialized
INFO - 2017-06-01 12:08:00 --> Language Class Initialized
INFO - 2017-06-01 12:08:00 --> Loader Class Initialized
INFO - 2017-06-01 12:08:00 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:00 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:00 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:00 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:00 --> Controller Class Initialized
INFO - 2017-06-01 12:08:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:00 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:00 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:00 --> Total execution time: 0.1945
INFO - 2017-06-01 12:08:05 --> Config Class Initialized
INFO - 2017-06-01 12:08:05 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:05 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:05 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:05 --> URI Class Initialized
INFO - 2017-06-01 12:08:05 --> Router Class Initialized
INFO - 2017-06-01 12:08:05 --> Output Class Initialized
INFO - 2017-06-01 12:08:05 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:05 --> CSRF cookie sent
INFO - 2017-06-01 12:08:05 --> CSRF token verified
INFO - 2017-06-01 12:08:05 --> Input Class Initialized
INFO - 2017-06-01 12:08:05 --> Language Class Initialized
INFO - 2017-06-01 12:08:05 --> Loader Class Initialized
INFO - 2017-06-01 12:08:05 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:05 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:05 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:05 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:05 --> Controller Class Initialized
INFO - 2017-06-01 12:08:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:05 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:05 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:05 --> Total execution time: 0.2203
INFO - 2017-06-01 12:08:12 --> Config Class Initialized
INFO - 2017-06-01 12:08:12 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:12 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:12 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:12 --> URI Class Initialized
INFO - 2017-06-01 12:08:12 --> Router Class Initialized
INFO - 2017-06-01 12:08:12 --> Output Class Initialized
INFO - 2017-06-01 12:08:12 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:12 --> CSRF cookie sent
INFO - 2017-06-01 12:08:12 --> CSRF token verified
INFO - 2017-06-01 12:08:12 --> Input Class Initialized
INFO - 2017-06-01 12:08:12 --> Language Class Initialized
INFO - 2017-06-01 12:08:12 --> Loader Class Initialized
INFO - 2017-06-01 12:08:12 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:12 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:12 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:12 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:12 --> Controller Class Initialized
INFO - 2017-06-01 12:08:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:12 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:12 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:12 --> Total execution time: 0.2104
INFO - 2017-06-01 12:08:17 --> Config Class Initialized
INFO - 2017-06-01 12:08:17 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:17 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:17 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:17 --> URI Class Initialized
INFO - 2017-06-01 12:08:17 --> Router Class Initialized
INFO - 2017-06-01 12:08:17 --> Output Class Initialized
INFO - 2017-06-01 12:08:17 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:17 --> CSRF cookie sent
INFO - 2017-06-01 12:08:17 --> CSRF token verified
INFO - 2017-06-01 12:08:17 --> Input Class Initialized
INFO - 2017-06-01 12:08:17 --> Language Class Initialized
INFO - 2017-06-01 12:08:17 --> Loader Class Initialized
INFO - 2017-06-01 12:08:17 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:17 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:17 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:17 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:17 --> Controller Class Initialized
INFO - 2017-06-01 12:08:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:17 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:17 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:17 --> Total execution time: 0.1915
INFO - 2017-06-01 12:08:26 --> Config Class Initialized
INFO - 2017-06-01 12:08:26 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:26 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:26 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:26 --> URI Class Initialized
INFO - 2017-06-01 12:08:26 --> Router Class Initialized
INFO - 2017-06-01 12:08:26 --> Output Class Initialized
INFO - 2017-06-01 12:08:26 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:26 --> CSRF cookie sent
INFO - 2017-06-01 12:08:26 --> CSRF token verified
INFO - 2017-06-01 12:08:26 --> Input Class Initialized
INFO - 2017-06-01 12:08:26 --> Language Class Initialized
INFO - 2017-06-01 12:08:26 --> Loader Class Initialized
INFO - 2017-06-01 12:08:26 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:26 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:26 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:26 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:26 --> Controller Class Initialized
INFO - 2017-06-01 12:08:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:26 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:26 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:26 --> Total execution time: 0.1913
INFO - 2017-06-01 12:08:30 --> Config Class Initialized
INFO - 2017-06-01 12:08:30 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:30 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:30 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:30 --> URI Class Initialized
INFO - 2017-06-01 12:08:30 --> Router Class Initialized
INFO - 2017-06-01 12:08:30 --> Output Class Initialized
INFO - 2017-06-01 12:08:30 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:30 --> CSRF cookie sent
INFO - 2017-06-01 12:08:30 --> CSRF token verified
INFO - 2017-06-01 12:08:30 --> Input Class Initialized
INFO - 2017-06-01 12:08:30 --> Language Class Initialized
INFO - 2017-06-01 12:08:30 --> Loader Class Initialized
INFO - 2017-06-01 12:08:30 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:30 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:30 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:30 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:30 --> Controller Class Initialized
INFO - 2017-06-01 12:08:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:30 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:30 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:30 --> Total execution time: 0.2000
INFO - 2017-06-01 12:08:43 --> Config Class Initialized
INFO - 2017-06-01 12:08:43 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:08:43 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:08:43 --> Utf8 Class Initialized
INFO - 2017-06-01 12:08:43 --> URI Class Initialized
INFO - 2017-06-01 12:08:43 --> Router Class Initialized
INFO - 2017-06-01 12:08:43 --> Output Class Initialized
INFO - 2017-06-01 12:08:43 --> Security Class Initialized
DEBUG - 2017-06-01 12:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:08:43 --> CSRF cookie sent
INFO - 2017-06-01 12:08:43 --> CSRF token verified
INFO - 2017-06-01 12:08:43 --> Input Class Initialized
INFO - 2017-06-01 12:08:43 --> Language Class Initialized
INFO - 2017-06-01 12:08:43 --> Loader Class Initialized
INFO - 2017-06-01 12:08:43 --> Helper loaded: url_helper
INFO - 2017-06-01 12:08:43 --> Helper loaded: file_helper
INFO - 2017-06-01 12:08:43 --> Helper loaded: form_helper
INFO - 2017-06-01 12:08:43 --> Form Validation Class Initialized
INFO - 2017-06-01 12:08:43 --> Controller Class Initialized
INFO - 2017-06-01 12:08:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:08:43 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:08:43 --> Final output sent to browser
DEBUG - 2017-06-01 12:08:43 --> Total execution time: 0.2327
INFO - 2017-06-01 12:09:10 --> Config Class Initialized
INFO - 2017-06-01 12:09:10 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:09:10 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:09:10 --> Utf8 Class Initialized
INFO - 2017-06-01 12:09:10 --> URI Class Initialized
INFO - 2017-06-01 12:09:10 --> Router Class Initialized
INFO - 2017-06-01 12:09:10 --> Output Class Initialized
INFO - 2017-06-01 12:09:10 --> Security Class Initialized
DEBUG - 2017-06-01 12:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:09:10 --> CSRF cookie sent
INFO - 2017-06-01 12:09:10 --> CSRF token verified
INFO - 2017-06-01 12:09:11 --> Input Class Initialized
INFO - 2017-06-01 12:09:11 --> Language Class Initialized
INFO - 2017-06-01 12:09:11 --> Loader Class Initialized
INFO - 2017-06-01 12:09:11 --> Helper loaded: url_helper
INFO - 2017-06-01 12:09:11 --> Helper loaded: file_helper
INFO - 2017-06-01 12:09:11 --> Helper loaded: form_helper
INFO - 2017-06-01 12:09:11 --> Form Validation Class Initialized
INFO - 2017-06-01 12:09:11 --> Controller Class Initialized
INFO - 2017-06-01 12:09:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:09:11 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:09:11 --> Final output sent to browser
DEBUG - 2017-06-01 12:09:11 --> Total execution time: 0.2192
INFO - 2017-06-01 12:09:19 --> Config Class Initialized
INFO - 2017-06-01 12:09:19 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:09:19 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:09:19 --> Utf8 Class Initialized
INFO - 2017-06-01 12:09:19 --> URI Class Initialized
INFO - 2017-06-01 12:09:19 --> Router Class Initialized
INFO - 2017-06-01 12:09:19 --> Output Class Initialized
INFO - 2017-06-01 12:09:19 --> Security Class Initialized
DEBUG - 2017-06-01 12:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:09:19 --> CSRF cookie sent
INFO - 2017-06-01 12:09:19 --> CSRF token verified
INFO - 2017-06-01 12:09:19 --> Input Class Initialized
INFO - 2017-06-01 12:09:19 --> Language Class Initialized
INFO - 2017-06-01 12:09:19 --> Loader Class Initialized
INFO - 2017-06-01 12:09:19 --> Helper loaded: url_helper
INFO - 2017-06-01 12:09:19 --> Helper loaded: file_helper
INFO - 2017-06-01 12:09:19 --> Helper loaded: form_helper
INFO - 2017-06-01 12:09:19 --> Form Validation Class Initialized
INFO - 2017-06-01 12:09:19 --> Controller Class Initialized
INFO - 2017-06-01 12:09:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:09:19 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:09:19 --> Final output sent to browser
DEBUG - 2017-06-01 12:09:19 --> Total execution time: 0.2101
INFO - 2017-06-01 12:09:23 --> Config Class Initialized
INFO - 2017-06-01 12:09:23 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:09:23 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:09:23 --> Utf8 Class Initialized
INFO - 2017-06-01 12:09:23 --> URI Class Initialized
INFO - 2017-06-01 12:09:23 --> Router Class Initialized
INFO - 2017-06-01 12:09:23 --> Output Class Initialized
INFO - 2017-06-01 12:09:23 --> Security Class Initialized
DEBUG - 2017-06-01 12:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:09:23 --> CSRF cookie sent
INFO - 2017-06-01 12:09:23 --> CSRF token verified
INFO - 2017-06-01 12:09:23 --> Input Class Initialized
INFO - 2017-06-01 12:09:23 --> Language Class Initialized
INFO - 2017-06-01 12:09:23 --> Loader Class Initialized
INFO - 2017-06-01 12:09:23 --> Helper loaded: url_helper
INFO - 2017-06-01 12:09:23 --> Helper loaded: file_helper
INFO - 2017-06-01 12:09:23 --> Helper loaded: form_helper
INFO - 2017-06-01 12:09:23 --> Form Validation Class Initialized
INFO - 2017-06-01 12:09:23 --> Controller Class Initialized
INFO - 2017-06-01 12:09:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:09:23 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:09:23 --> Final output sent to browser
DEBUG - 2017-06-01 12:09:23 --> Total execution time: 0.1872
INFO - 2017-06-01 12:09:28 --> Config Class Initialized
INFO - 2017-06-01 12:09:28 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:09:28 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:09:28 --> Utf8 Class Initialized
INFO - 2017-06-01 12:09:28 --> URI Class Initialized
INFO - 2017-06-01 12:09:28 --> Router Class Initialized
INFO - 2017-06-01 12:09:28 --> Output Class Initialized
INFO - 2017-06-01 12:09:28 --> Security Class Initialized
DEBUG - 2017-06-01 12:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:09:28 --> CSRF cookie sent
INFO - 2017-06-01 12:09:28 --> CSRF token verified
INFO - 2017-06-01 12:09:28 --> Input Class Initialized
INFO - 2017-06-01 12:09:28 --> Language Class Initialized
INFO - 2017-06-01 12:09:28 --> Loader Class Initialized
INFO - 2017-06-01 12:09:28 --> Helper loaded: url_helper
INFO - 2017-06-01 12:09:28 --> Helper loaded: file_helper
INFO - 2017-06-01 12:09:28 --> Helper loaded: form_helper
INFO - 2017-06-01 12:09:28 --> Form Validation Class Initialized
INFO - 2017-06-01 12:09:28 --> Controller Class Initialized
INFO - 2017-06-01 12:09:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:09:28 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:09:28 --> Final output sent to browser
DEBUG - 2017-06-01 12:09:28 --> Total execution time: 0.2008
INFO - 2017-06-01 12:09:33 --> Config Class Initialized
INFO - 2017-06-01 12:09:33 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:09:33 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:09:33 --> Utf8 Class Initialized
INFO - 2017-06-01 12:09:33 --> URI Class Initialized
INFO - 2017-06-01 12:09:33 --> Router Class Initialized
INFO - 2017-06-01 12:09:33 --> Output Class Initialized
INFO - 2017-06-01 12:09:33 --> Security Class Initialized
DEBUG - 2017-06-01 12:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:09:33 --> CSRF cookie sent
INFO - 2017-06-01 12:09:33 --> CSRF token verified
INFO - 2017-06-01 12:09:33 --> Input Class Initialized
INFO - 2017-06-01 12:09:33 --> Language Class Initialized
INFO - 2017-06-01 12:09:33 --> Loader Class Initialized
INFO - 2017-06-01 12:09:33 --> Helper loaded: url_helper
INFO - 2017-06-01 12:09:33 --> Helper loaded: file_helper
INFO - 2017-06-01 12:09:33 --> Helper loaded: form_helper
INFO - 2017-06-01 12:09:33 --> Form Validation Class Initialized
INFO - 2017-06-01 12:09:33 --> Controller Class Initialized
INFO - 2017-06-01 12:09:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 12:09:33 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:09:33 --> Final output sent to browser
DEBUG - 2017-06-01 12:09:33 --> Total execution time: 0.1931
INFO - 2017-06-01 12:23:28 --> Config Class Initialized
INFO - 2017-06-01 12:23:28 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:23:28 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:23:28 --> Utf8 Class Initialized
INFO - 2017-06-01 12:23:28 --> URI Class Initialized
INFO - 2017-06-01 12:23:28 --> Router Class Initialized
INFO - 2017-06-01 12:23:28 --> Output Class Initialized
INFO - 2017-06-01 12:23:28 --> Security Class Initialized
DEBUG - 2017-06-01 12:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:23:28 --> CSRF cookie sent
INFO - 2017-06-01 12:23:28 --> Input Class Initialized
INFO - 2017-06-01 12:23:28 --> Language Class Initialized
INFO - 2017-06-01 12:23:28 --> Loader Class Initialized
INFO - 2017-06-01 12:23:28 --> Helper loaded: url_helper
INFO - 2017-06-01 12:23:28 --> Helper loaded: file_helper
INFO - 2017-06-01 12:23:28 --> Helper loaded: form_helper
INFO - 2017-06-01 12:23:28 --> Form Validation Class Initialized
INFO - 2017-06-01 12:23:28 --> Controller Class Initialized
INFO - 2017-06-01 12:23:28 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:23:28 --> Final output sent to browser
DEBUG - 2017-06-01 12:23:28 --> Total execution time: 0.6333
INFO - 2017-06-01 12:24:29 --> Config Class Initialized
INFO - 2017-06-01 12:24:29 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:24:29 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:24:29 --> Utf8 Class Initialized
INFO - 2017-06-01 12:24:29 --> URI Class Initialized
INFO - 2017-06-01 12:24:29 --> Router Class Initialized
INFO - 2017-06-01 12:24:29 --> Output Class Initialized
INFO - 2017-06-01 12:24:29 --> Security Class Initialized
DEBUG - 2017-06-01 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:24:29 --> CSRF cookie sent
INFO - 2017-06-01 12:24:29 --> Input Class Initialized
INFO - 2017-06-01 12:24:29 --> Language Class Initialized
INFO - 2017-06-01 12:24:29 --> Loader Class Initialized
INFO - 2017-06-01 12:24:29 --> Helper loaded: url_helper
INFO - 2017-06-01 12:24:29 --> Helper loaded: file_helper
INFO - 2017-06-01 12:24:29 --> Helper loaded: form_helper
INFO - 2017-06-01 12:24:29 --> Form Validation Class Initialized
INFO - 2017-06-01 12:24:29 --> Controller Class Initialized
INFO - 2017-06-01 12:24:29 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:24:29 --> Final output sent to browser
DEBUG - 2017-06-01 12:24:29 --> Total execution time: 0.1589
INFO - 2017-06-01 12:27:56 --> Config Class Initialized
INFO - 2017-06-01 12:27:56 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:27:56 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:27:56 --> Utf8 Class Initialized
INFO - 2017-06-01 12:27:56 --> URI Class Initialized
INFO - 2017-06-01 12:27:56 --> Router Class Initialized
INFO - 2017-06-01 12:27:56 --> Output Class Initialized
INFO - 2017-06-01 12:27:56 --> Security Class Initialized
DEBUG - 2017-06-01 12:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:27:56 --> CSRF cookie sent
INFO - 2017-06-01 12:27:56 --> Input Class Initialized
INFO - 2017-06-01 12:27:56 --> Language Class Initialized
INFO - 2017-06-01 12:27:56 --> Loader Class Initialized
INFO - 2017-06-01 12:27:56 --> Helper loaded: url_helper
INFO - 2017-06-01 12:27:56 --> Helper loaded: file_helper
INFO - 2017-06-01 12:27:56 --> Helper loaded: form_helper
INFO - 2017-06-01 12:27:56 --> Form Validation Class Initialized
INFO - 2017-06-01 12:27:56 --> Controller Class Initialized
INFO - 2017-06-01 12:27:56 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:27:56 --> Final output sent to browser
DEBUG - 2017-06-01 12:27:56 --> Total execution time: 0.1887
INFO - 2017-06-01 12:28:06 --> Config Class Initialized
INFO - 2017-06-01 12:28:06 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:28:07 --> Utf8 Class Initialized
INFO - 2017-06-01 12:28:07 --> URI Class Initialized
INFO - 2017-06-01 12:28:07 --> Router Class Initialized
INFO - 2017-06-01 12:28:07 --> Output Class Initialized
INFO - 2017-06-01 12:28:07 --> Security Class Initialized
DEBUG - 2017-06-01 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:28:07 --> CSRF cookie sent
INFO - 2017-06-01 12:28:07 --> Input Class Initialized
INFO - 2017-06-01 12:28:07 --> Language Class Initialized
INFO - 2017-06-01 12:28:07 --> Loader Class Initialized
INFO - 2017-06-01 12:28:07 --> Helper loaded: url_helper
INFO - 2017-06-01 12:28:07 --> Helper loaded: file_helper
INFO - 2017-06-01 12:28:07 --> Helper loaded: form_helper
INFO - 2017-06-01 12:28:07 --> Form Validation Class Initialized
INFO - 2017-06-01 12:28:07 --> Controller Class Initialized
INFO - 2017-06-01 12:28:07 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:28:07 --> Final output sent to browser
DEBUG - 2017-06-01 12:28:07 --> Total execution time: 0.1669
INFO - 2017-06-01 12:28:18 --> Config Class Initialized
INFO - 2017-06-01 12:28:18 --> Hooks Class Initialized
DEBUG - 2017-06-01 12:28:18 --> UTF-8 Support Enabled
INFO - 2017-06-01 12:28:18 --> Utf8 Class Initialized
INFO - 2017-06-01 12:28:18 --> URI Class Initialized
INFO - 2017-06-01 12:28:18 --> Router Class Initialized
INFO - 2017-06-01 12:28:18 --> Output Class Initialized
INFO - 2017-06-01 12:28:18 --> Security Class Initialized
DEBUG - 2017-06-01 12:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 12:28:18 --> CSRF cookie sent
INFO - 2017-06-01 12:28:18 --> Input Class Initialized
INFO - 2017-06-01 12:28:18 --> Language Class Initialized
INFO - 2017-06-01 12:28:18 --> Loader Class Initialized
INFO - 2017-06-01 12:28:18 --> Helper loaded: url_helper
INFO - 2017-06-01 12:28:18 --> Helper loaded: file_helper
INFO - 2017-06-01 12:28:18 --> Helper loaded: form_helper
INFO - 2017-06-01 12:28:18 --> Form Validation Class Initialized
INFO - 2017-06-01 12:28:18 --> Controller Class Initialized
INFO - 2017-06-01 12:28:18 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 12:28:18 --> Final output sent to browser
DEBUG - 2017-06-01 12:28:18 --> Total execution time: 0.1723
INFO - 2017-06-01 13:46:11 --> Config Class Initialized
INFO - 2017-06-01 13:46:11 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:46:11 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:46:11 --> Utf8 Class Initialized
INFO - 2017-06-01 13:46:11 --> URI Class Initialized
DEBUG - 2017-06-01 13:46:11 --> No URI present. Default controller set.
INFO - 2017-06-01 13:46:11 --> Router Class Initialized
INFO - 2017-06-01 13:46:11 --> Output Class Initialized
INFO - 2017-06-01 13:46:11 --> Security Class Initialized
DEBUG - 2017-06-01 13:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:46:11 --> CSRF cookie sent
INFO - 2017-06-01 13:46:11 --> Input Class Initialized
INFO - 2017-06-01 13:46:11 --> Language Class Initialized
INFO - 2017-06-01 13:46:11 --> Loader Class Initialized
INFO - 2017-06-01 13:46:12 --> Helper loaded: url_helper
INFO - 2017-06-01 13:46:12 --> Helper loaded: file_helper
INFO - 2017-06-01 13:46:12 --> Helper loaded: form_helper
INFO - 2017-06-01 13:46:12 --> Form Validation Class Initialized
INFO - 2017-06-01 13:46:12 --> Controller Class Initialized
INFO - 2017-06-01 13:46:12 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:46:12 --> Final output sent to browser
DEBUG - 2017-06-01 13:46:12 --> Total execution time: 0.8173
INFO - 2017-06-01 13:46:34 --> Config Class Initialized
INFO - 2017-06-01 13:46:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:46:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:46:34 --> Utf8 Class Initialized
INFO - 2017-06-01 13:46:34 --> URI Class Initialized
DEBUG - 2017-06-01 13:46:34 --> No URI present. Default controller set.
INFO - 2017-06-01 13:46:34 --> Router Class Initialized
INFO - 2017-06-01 13:46:34 --> Output Class Initialized
INFO - 2017-06-01 13:46:34 --> Security Class Initialized
DEBUG - 2017-06-01 13:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:46:34 --> CSRF cookie sent
INFO - 2017-06-01 13:46:34 --> Input Class Initialized
INFO - 2017-06-01 13:46:34 --> Language Class Initialized
INFO - 2017-06-01 13:46:34 --> Loader Class Initialized
INFO - 2017-06-01 13:46:34 --> Helper loaded: url_helper
INFO - 2017-06-01 13:46:34 --> Helper loaded: file_helper
INFO - 2017-06-01 13:46:34 --> Helper loaded: form_helper
INFO - 2017-06-01 13:46:34 --> Form Validation Class Initialized
INFO - 2017-06-01 13:46:34 --> Controller Class Initialized
INFO - 2017-06-01 13:46:34 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:46:34 --> Final output sent to browser
DEBUG - 2017-06-01 13:46:34 --> Total execution time: 0.1898
INFO - 2017-06-01 13:46:41 --> Config Class Initialized
INFO - 2017-06-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:46:41 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:46:41 --> Utf8 Class Initialized
INFO - 2017-06-01 13:46:41 --> URI Class Initialized
INFO - 2017-06-01 13:46:41 --> Router Class Initialized
INFO - 2017-06-01 13:46:41 --> Output Class Initialized
INFO - 2017-06-01 13:46:41 --> Security Class Initialized
DEBUG - 2017-06-01 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:46:41 --> CSRF cookie sent
INFO - 2017-06-01 13:46:41 --> CSRF token verified
INFO - 2017-06-01 13:46:41 --> Input Class Initialized
INFO - 2017-06-01 13:46:41 --> Language Class Initialized
INFO - 2017-06-01 13:46:41 --> Loader Class Initialized
INFO - 2017-06-01 13:46:41 --> Helper loaded: url_helper
INFO - 2017-06-01 13:46:41 --> Helper loaded: file_helper
INFO - 2017-06-01 13:46:41 --> Helper loaded: form_helper
INFO - 2017-06-01 13:46:41 --> Form Validation Class Initialized
INFO - 2017-06-01 13:46:41 --> Controller Class Initialized
INFO - 2017-06-01 13:46:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:46:41 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:46:41 --> Final output sent to browser
DEBUG - 2017-06-01 13:46:41 --> Total execution time: 0.3074
INFO - 2017-06-01 13:47:08 --> Config Class Initialized
INFO - 2017-06-01 13:47:08 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:08 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:08 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:08 --> URI Class Initialized
INFO - 2017-06-01 13:47:08 --> Router Class Initialized
INFO - 2017-06-01 13:47:08 --> Output Class Initialized
INFO - 2017-06-01 13:47:08 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:08 --> CSRF cookie sent
INFO - 2017-06-01 13:47:08 --> Input Class Initialized
INFO - 2017-06-01 13:47:08 --> Language Class Initialized
INFO - 2017-06-01 13:47:08 --> Loader Class Initialized
INFO - 2017-06-01 13:47:08 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:08 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:08 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:08 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:08 --> Controller Class Initialized
INFO - 2017-06-01 13:47:08 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:08 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:08 --> Total execution time: 0.1813
INFO - 2017-06-01 13:47:12 --> Config Class Initialized
INFO - 2017-06-01 13:47:12 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:12 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:12 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:12 --> URI Class Initialized
INFO - 2017-06-01 13:47:12 --> Router Class Initialized
INFO - 2017-06-01 13:47:12 --> Output Class Initialized
INFO - 2017-06-01 13:47:12 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:12 --> CSRF cookie sent
INFO - 2017-06-01 13:47:12 --> CSRF token verified
INFO - 2017-06-01 13:47:12 --> Input Class Initialized
INFO - 2017-06-01 13:47:12 --> Language Class Initialized
INFO - 2017-06-01 13:47:12 --> Loader Class Initialized
INFO - 2017-06-01 13:47:12 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:12 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:12 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:12 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:12 --> Controller Class Initialized
INFO - 2017-06-01 13:47:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:47:12 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:12 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:12 --> Total execution time: 0.2463
INFO - 2017-06-01 13:47:16 --> Config Class Initialized
INFO - 2017-06-01 13:47:16 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:16 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:16 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:16 --> URI Class Initialized
INFO - 2017-06-01 13:47:16 --> Router Class Initialized
INFO - 2017-06-01 13:47:16 --> Output Class Initialized
INFO - 2017-06-01 13:47:16 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:16 --> CSRF cookie sent
INFO - 2017-06-01 13:47:16 --> CSRF token verified
INFO - 2017-06-01 13:47:16 --> Input Class Initialized
INFO - 2017-06-01 13:47:16 --> Language Class Initialized
INFO - 2017-06-01 13:47:16 --> Loader Class Initialized
INFO - 2017-06-01 13:47:17 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:17 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:17 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:17 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:17 --> Controller Class Initialized
INFO - 2017-06-01 13:47:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:47:17 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:17 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:17 --> Total execution time: 0.2119
INFO - 2017-06-01 13:47:20 --> Config Class Initialized
INFO - 2017-06-01 13:47:20 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:20 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:20 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:20 --> URI Class Initialized
INFO - 2017-06-01 13:47:20 --> Router Class Initialized
INFO - 2017-06-01 13:47:20 --> Output Class Initialized
INFO - 2017-06-01 13:47:20 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:20 --> CSRF cookie sent
INFO - 2017-06-01 13:47:20 --> CSRF token verified
INFO - 2017-06-01 13:47:20 --> Input Class Initialized
INFO - 2017-06-01 13:47:20 --> Language Class Initialized
INFO - 2017-06-01 13:47:20 --> Loader Class Initialized
INFO - 2017-06-01 13:47:20 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:20 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:20 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:20 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:20 --> Controller Class Initialized
INFO - 2017-06-01 13:47:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:47:20 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:20 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:20 --> Total execution time: 0.2024
INFO - 2017-06-01 13:47:30 --> Config Class Initialized
INFO - 2017-06-01 13:47:30 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:30 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:30 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:30 --> URI Class Initialized
INFO - 2017-06-01 13:47:30 --> Router Class Initialized
INFO - 2017-06-01 13:47:30 --> Output Class Initialized
INFO - 2017-06-01 13:47:30 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:30 --> CSRF cookie sent
INFO - 2017-06-01 13:47:30 --> Input Class Initialized
INFO - 2017-06-01 13:47:30 --> Language Class Initialized
INFO - 2017-06-01 13:47:30 --> Loader Class Initialized
INFO - 2017-06-01 13:47:30 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:30 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:30 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:30 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:30 --> Controller Class Initialized
INFO - 2017-06-01 13:47:30 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:30 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:30 --> Total execution time: 0.1867
INFO - 2017-06-01 13:47:56 --> Config Class Initialized
INFO - 2017-06-01 13:47:56 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:47:56 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:47:56 --> Utf8 Class Initialized
INFO - 2017-06-01 13:47:56 --> URI Class Initialized
INFO - 2017-06-01 13:47:56 --> Router Class Initialized
INFO - 2017-06-01 13:47:56 --> Output Class Initialized
INFO - 2017-06-01 13:47:56 --> Security Class Initialized
DEBUG - 2017-06-01 13:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:47:56 --> CSRF cookie sent
INFO - 2017-06-01 13:47:56 --> CSRF token verified
INFO - 2017-06-01 13:47:56 --> Input Class Initialized
INFO - 2017-06-01 13:47:56 --> Language Class Initialized
INFO - 2017-06-01 13:47:56 --> Loader Class Initialized
INFO - 2017-06-01 13:47:56 --> Helper loaded: url_helper
INFO - 2017-06-01 13:47:56 --> Helper loaded: file_helper
INFO - 2017-06-01 13:47:56 --> Helper loaded: form_helper
INFO - 2017-06-01 13:47:56 --> Form Validation Class Initialized
INFO - 2017-06-01 13:47:56 --> Controller Class Initialized
INFO - 2017-06-01 13:47:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:47:56 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:47:56 --> Final output sent to browser
DEBUG - 2017-06-01 13:47:56 --> Total execution time: 0.2057
INFO - 2017-06-01 13:48:06 --> Config Class Initialized
INFO - 2017-06-01 13:48:06 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:48:06 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:48:06 --> Utf8 Class Initialized
INFO - 2017-06-01 13:48:06 --> URI Class Initialized
INFO - 2017-06-01 13:48:06 --> Router Class Initialized
INFO - 2017-06-01 13:48:06 --> Output Class Initialized
INFO - 2017-06-01 13:48:06 --> Security Class Initialized
DEBUG - 2017-06-01 13:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:48:06 --> CSRF cookie sent
INFO - 2017-06-01 13:48:06 --> CSRF token verified
INFO - 2017-06-01 13:48:06 --> Input Class Initialized
INFO - 2017-06-01 13:48:06 --> Language Class Initialized
INFO - 2017-06-01 13:48:06 --> Loader Class Initialized
INFO - 2017-06-01 13:48:06 --> Helper loaded: url_helper
INFO - 2017-06-01 13:48:06 --> Helper loaded: file_helper
INFO - 2017-06-01 13:48:06 --> Helper loaded: form_helper
INFO - 2017-06-01 13:48:06 --> Form Validation Class Initialized
INFO - 2017-06-01 13:48:06 --> Controller Class Initialized
INFO - 2017-06-01 13:48:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:48:06 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:48:06 --> Final output sent to browser
DEBUG - 2017-06-01 13:48:06 --> Total execution time: 0.2049
INFO - 2017-06-01 13:48:13 --> Config Class Initialized
INFO - 2017-06-01 13:48:13 --> Hooks Class Initialized
DEBUG - 2017-06-01 13:48:13 --> UTF-8 Support Enabled
INFO - 2017-06-01 13:48:13 --> Utf8 Class Initialized
INFO - 2017-06-01 13:48:13 --> URI Class Initialized
INFO - 2017-06-01 13:48:13 --> Router Class Initialized
INFO - 2017-06-01 13:48:13 --> Output Class Initialized
INFO - 2017-06-01 13:48:13 --> Security Class Initialized
DEBUG - 2017-06-01 13:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 13:48:13 --> CSRF cookie sent
INFO - 2017-06-01 13:48:13 --> CSRF token verified
INFO - 2017-06-01 13:48:13 --> Input Class Initialized
INFO - 2017-06-01 13:48:13 --> Language Class Initialized
INFO - 2017-06-01 13:48:13 --> Loader Class Initialized
INFO - 2017-06-01 13:48:13 --> Helper loaded: url_helper
INFO - 2017-06-01 13:48:13 --> Helper loaded: file_helper
INFO - 2017-06-01 13:48:13 --> Helper loaded: form_helper
INFO - 2017-06-01 13:48:13 --> Form Validation Class Initialized
INFO - 2017-06-01 13:48:13 --> Controller Class Initialized
INFO - 2017-06-01 13:48:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 13:48:13 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 13:48:13 --> Final output sent to browser
DEBUG - 2017-06-01 13:48:13 --> Total execution time: 0.2090
INFO - 2017-06-01 14:08:22 --> Config Class Initialized
INFO - 2017-06-01 14:08:22 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:08:22 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:08:22 --> Utf8 Class Initialized
INFO - 2017-06-01 14:08:22 --> URI Class Initialized
INFO - 2017-06-01 14:08:22 --> Router Class Initialized
INFO - 2017-06-01 14:08:22 --> Output Class Initialized
INFO - 2017-06-01 14:08:22 --> Security Class Initialized
DEBUG - 2017-06-01 14:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:08:22 --> CSRF cookie sent
INFO - 2017-06-01 14:08:22 --> Input Class Initialized
INFO - 2017-06-01 14:08:22 --> Language Class Initialized
INFO - 2017-06-01 14:08:22 --> Loader Class Initialized
INFO - 2017-06-01 14:08:22 --> Helper loaded: url_helper
INFO - 2017-06-01 14:08:22 --> Helper loaded: file_helper
INFO - 2017-06-01 14:08:22 --> Helper loaded: form_helper
INFO - 2017-06-01 14:08:22 --> Form Validation Class Initialized
INFO - 2017-06-01 14:08:23 --> Image Lib Class Initialized
INFO - 2017-06-01 14:08:23 --> Controller Class Initialized
INFO - 2017-06-01 14:08:23 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:08:23 --> Final output sent to browser
DEBUG - 2017-06-01 14:08:23 --> Total execution time: 0.4193
INFO - 2017-06-01 14:08:23 --> Config Class Initialized
INFO - 2017-06-01 14:08:23 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:08:23 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:08:23 --> Utf8 Class Initialized
INFO - 2017-06-01 14:08:23 --> URI Class Initialized
INFO - 2017-06-01 14:08:23 --> Router Class Initialized
INFO - 2017-06-01 14:08:23 --> Output Class Initialized
INFO - 2017-06-01 14:08:23 --> Security Class Initialized
DEBUG - 2017-06-01 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:08:23 --> CSRF cookie sent
INFO - 2017-06-01 14:08:23 --> Input Class Initialized
INFO - 2017-06-01 14:08:23 --> Language Class Initialized
INFO - 2017-06-01 14:08:23 --> Loader Class Initialized
INFO - 2017-06-01 14:08:23 --> Helper loaded: url_helper
INFO - 2017-06-01 14:08:23 --> Helper loaded: file_helper
INFO - 2017-06-01 14:08:23 --> Helper loaded: form_helper
INFO - 2017-06-01 14:08:23 --> Form Validation Class Initialized
INFO - 2017-06-01 14:08:23 --> Image Lib Class Initialized
INFO - 2017-06-01 14:08:23 --> Controller Class Initialized
INFO - 2017-06-01 14:08:23 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:08:23 --> Final output sent to browser
DEBUG - 2017-06-01 14:08:23 --> Total execution time: 0.2663
INFO - 2017-06-01 14:13:44 --> Config Class Initialized
INFO - 2017-06-01 14:13:44 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:13:44 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:13:44 --> Utf8 Class Initialized
INFO - 2017-06-01 14:13:44 --> URI Class Initialized
INFO - 2017-06-01 14:13:44 --> Router Class Initialized
INFO - 2017-06-01 14:13:44 --> Output Class Initialized
INFO - 2017-06-01 14:13:44 --> Security Class Initialized
DEBUG - 2017-06-01 14:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:13:44 --> CSRF cookie sent
INFO - 2017-06-01 14:13:44 --> Input Class Initialized
INFO - 2017-06-01 14:13:44 --> Language Class Initialized
INFO - 2017-06-01 14:13:44 --> Loader Class Initialized
INFO - 2017-06-01 14:13:44 --> Helper loaded: url_helper
INFO - 2017-06-01 14:13:44 --> Helper loaded: file_helper
INFO - 2017-06-01 14:13:44 --> Helper loaded: form_helper
INFO - 2017-06-01 14:13:44 --> Form Validation Class Initialized
INFO - 2017-06-01 14:13:44 --> Image Lib Class Initialized
INFO - 2017-06-01 14:13:44 --> Controller Class Initialized
INFO - 2017-06-01 14:13:44 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:13:44 --> Final output sent to browser
DEBUG - 2017-06-01 14:13:44 --> Total execution time: 0.1821
INFO - 2017-06-01 14:14:15 --> Config Class Initialized
INFO - 2017-06-01 14:14:15 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:14:15 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:14:15 --> Utf8 Class Initialized
INFO - 2017-06-01 14:14:15 --> URI Class Initialized
INFO - 2017-06-01 14:14:15 --> Router Class Initialized
INFO - 2017-06-01 14:14:15 --> Output Class Initialized
INFO - 2017-06-01 14:14:15 --> Security Class Initialized
DEBUG - 2017-06-01 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:14:15 --> CSRF cookie sent
INFO - 2017-06-01 14:14:15 --> Input Class Initialized
INFO - 2017-06-01 14:14:15 --> Language Class Initialized
INFO - 2017-06-01 14:14:15 --> Loader Class Initialized
INFO - 2017-06-01 14:14:15 --> Helper loaded: url_helper
INFO - 2017-06-01 14:14:15 --> Helper loaded: file_helper
INFO - 2017-06-01 14:14:15 --> Helper loaded: form_helper
INFO - 2017-06-01 14:14:15 --> Form Validation Class Initialized
INFO - 2017-06-01 14:14:15 --> Image Lib Class Initialized
INFO - 2017-06-01 14:14:15 --> Controller Class Initialized
INFO - 2017-06-01 14:14:15 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:14:15 --> Final output sent to browser
DEBUG - 2017-06-01 14:14:15 --> Total execution time: 0.2125
INFO - 2017-06-01 14:15:04 --> Config Class Initialized
INFO - 2017-06-01 14:15:04 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:15:04 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:15:04 --> Utf8 Class Initialized
INFO - 2017-06-01 14:15:04 --> URI Class Initialized
INFO - 2017-06-01 14:15:04 --> Router Class Initialized
INFO - 2017-06-01 14:15:04 --> Output Class Initialized
INFO - 2017-06-01 14:15:04 --> Security Class Initialized
DEBUG - 2017-06-01 14:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:15:04 --> CSRF cookie sent
INFO - 2017-06-01 14:15:04 --> Input Class Initialized
INFO - 2017-06-01 14:15:04 --> Language Class Initialized
INFO - 2017-06-01 14:15:04 --> Loader Class Initialized
INFO - 2017-06-01 14:15:04 --> Helper loaded: url_helper
INFO - 2017-06-01 14:15:04 --> Helper loaded: file_helper
INFO - 2017-06-01 14:15:04 --> Helper loaded: form_helper
INFO - 2017-06-01 14:15:04 --> Form Validation Class Initialized
INFO - 2017-06-01 14:15:04 --> Image Lib Class Initialized
INFO - 2017-06-01 14:15:04 --> Controller Class Initialized
INFO - 2017-06-01 14:15:04 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:15:04 --> Final output sent to browser
DEBUG - 2017-06-01 14:15:04 --> Total execution time: 0.2709
INFO - 2017-06-01 14:17:06 --> Config Class Initialized
INFO - 2017-06-01 14:17:06 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:17:06 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:17:06 --> Utf8 Class Initialized
INFO - 2017-06-01 14:17:06 --> URI Class Initialized
INFO - 2017-06-01 14:17:06 --> Router Class Initialized
INFO - 2017-06-01 14:17:06 --> Output Class Initialized
INFO - 2017-06-01 14:17:06 --> Security Class Initialized
DEBUG - 2017-06-01 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:17:06 --> CSRF cookie sent
INFO - 2017-06-01 14:17:06 --> Input Class Initialized
INFO - 2017-06-01 14:17:06 --> Language Class Initialized
INFO - 2017-06-01 14:17:06 --> Loader Class Initialized
INFO - 2017-06-01 14:17:06 --> Helper loaded: url_helper
INFO - 2017-06-01 14:17:06 --> Helper loaded: file_helper
INFO - 2017-06-01 14:17:06 --> Helper loaded: form_helper
INFO - 2017-06-01 14:17:06 --> Form Validation Class Initialized
INFO - 2017-06-01 14:17:06 --> Image Lib Class Initialized
INFO - 2017-06-01 14:17:06 --> Controller Class Initialized
INFO - 2017-06-01 14:17:06 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:17:06 --> Final output sent to browser
DEBUG - 2017-06-01 14:17:06 --> Total execution time: 0.2150
INFO - 2017-06-01 14:17:22 --> Config Class Initialized
INFO - 2017-06-01 14:17:22 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:17:22 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:17:22 --> Utf8 Class Initialized
INFO - 2017-06-01 14:17:22 --> URI Class Initialized
INFO - 2017-06-01 14:17:22 --> Router Class Initialized
INFO - 2017-06-01 14:17:22 --> Output Class Initialized
INFO - 2017-06-01 14:17:22 --> Security Class Initialized
DEBUG - 2017-06-01 14:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:17:22 --> CSRF cookie sent
INFO - 2017-06-01 14:17:22 --> Input Class Initialized
INFO - 2017-06-01 14:17:22 --> Language Class Initialized
INFO - 2017-06-01 14:17:22 --> Loader Class Initialized
INFO - 2017-06-01 14:17:22 --> Helper loaded: url_helper
INFO - 2017-06-01 14:17:22 --> Helper loaded: file_helper
INFO - 2017-06-01 14:17:22 --> Helper loaded: form_helper
INFO - 2017-06-01 14:17:22 --> Form Validation Class Initialized
INFO - 2017-06-01 14:17:22 --> Image Lib Class Initialized
INFO - 2017-06-01 14:17:22 --> Controller Class Initialized
INFO - 2017-06-01 14:17:22 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:17:22 --> Final output sent to browser
DEBUG - 2017-06-01 14:17:22 --> Total execution time: 0.2623
INFO - 2017-06-01 14:17:32 --> Config Class Initialized
INFO - 2017-06-01 14:17:32 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:17:32 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:17:32 --> Utf8 Class Initialized
INFO - 2017-06-01 14:17:32 --> URI Class Initialized
INFO - 2017-06-01 14:17:32 --> Router Class Initialized
INFO - 2017-06-01 14:17:32 --> Output Class Initialized
INFO - 2017-06-01 14:17:32 --> Security Class Initialized
DEBUG - 2017-06-01 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:17:32 --> CSRF cookie sent
INFO - 2017-06-01 14:17:32 --> Input Class Initialized
INFO - 2017-06-01 14:17:32 --> Language Class Initialized
INFO - 2017-06-01 14:17:32 --> Loader Class Initialized
INFO - 2017-06-01 14:17:32 --> Helper loaded: url_helper
INFO - 2017-06-01 14:17:32 --> Helper loaded: file_helper
INFO - 2017-06-01 14:17:32 --> Helper loaded: form_helper
INFO - 2017-06-01 14:17:32 --> Form Validation Class Initialized
INFO - 2017-06-01 14:17:32 --> Image Lib Class Initialized
INFO - 2017-06-01 14:17:32 --> Controller Class Initialized
INFO - 2017-06-01 14:17:32 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:17:32 --> Final output sent to browser
DEBUG - 2017-06-01 14:17:32 --> Total execution time: 0.1804
INFO - 2017-06-01 14:17:59 --> Config Class Initialized
INFO - 2017-06-01 14:17:59 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:17:59 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:17:59 --> Utf8 Class Initialized
INFO - 2017-06-01 14:17:59 --> URI Class Initialized
INFO - 2017-06-01 14:17:59 --> Router Class Initialized
INFO - 2017-06-01 14:17:59 --> Output Class Initialized
INFO - 2017-06-01 14:17:59 --> Security Class Initialized
DEBUG - 2017-06-01 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:17:59 --> CSRF cookie sent
INFO - 2017-06-01 14:17:59 --> Input Class Initialized
INFO - 2017-06-01 14:17:59 --> Language Class Initialized
INFO - 2017-06-01 14:17:59 --> Loader Class Initialized
INFO - 2017-06-01 14:17:59 --> Helper loaded: url_helper
INFO - 2017-06-01 14:17:59 --> Helper loaded: file_helper
INFO - 2017-06-01 14:17:59 --> Helper loaded: form_helper
INFO - 2017-06-01 14:17:59 --> Form Validation Class Initialized
INFO - 2017-06-01 14:17:59 --> Image Lib Class Initialized
INFO - 2017-06-01 14:17:59 --> Controller Class Initialized
INFO - 2017-06-01 14:17:59 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:17:59 --> Final output sent to browser
DEBUG - 2017-06-01 14:17:59 --> Total execution time: 0.2109
INFO - 2017-06-01 14:18:20 --> Config Class Initialized
INFO - 2017-06-01 14:18:20 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:18:20 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:18:20 --> Utf8 Class Initialized
INFO - 2017-06-01 14:18:20 --> URI Class Initialized
INFO - 2017-06-01 14:18:20 --> Router Class Initialized
INFO - 2017-06-01 14:18:20 --> Output Class Initialized
INFO - 2017-06-01 14:18:20 --> Security Class Initialized
DEBUG - 2017-06-01 14:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:18:20 --> CSRF cookie sent
INFO - 2017-06-01 14:18:20 --> Input Class Initialized
INFO - 2017-06-01 14:18:20 --> Language Class Initialized
INFO - 2017-06-01 14:18:20 --> Loader Class Initialized
INFO - 2017-06-01 14:18:20 --> Helper loaded: url_helper
INFO - 2017-06-01 14:18:20 --> Helper loaded: file_helper
INFO - 2017-06-01 14:18:20 --> Helper loaded: form_helper
INFO - 2017-06-01 14:18:20 --> Form Validation Class Initialized
INFO - 2017-06-01 14:18:20 --> Image Lib Class Initialized
INFO - 2017-06-01 14:18:21 --> Controller Class Initialized
INFO - 2017-06-01 14:18:21 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:18:21 --> Final output sent to browser
DEBUG - 2017-06-01 14:18:21 --> Total execution time: 0.2306
INFO - 2017-06-01 14:18:38 --> Config Class Initialized
INFO - 2017-06-01 14:18:38 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:18:39 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:18:39 --> Utf8 Class Initialized
INFO - 2017-06-01 14:18:39 --> URI Class Initialized
INFO - 2017-06-01 14:18:39 --> Router Class Initialized
INFO - 2017-06-01 14:18:39 --> Output Class Initialized
INFO - 2017-06-01 14:18:39 --> Security Class Initialized
DEBUG - 2017-06-01 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:18:39 --> CSRF cookie sent
INFO - 2017-06-01 14:18:39 --> Input Class Initialized
INFO - 2017-06-01 14:18:39 --> Language Class Initialized
INFO - 2017-06-01 14:18:39 --> Loader Class Initialized
INFO - 2017-06-01 14:18:39 --> Helper loaded: url_helper
INFO - 2017-06-01 14:18:39 --> Helper loaded: file_helper
INFO - 2017-06-01 14:18:39 --> Helper loaded: form_helper
INFO - 2017-06-01 14:18:39 --> Form Validation Class Initialized
INFO - 2017-06-01 14:18:39 --> Image Lib Class Initialized
INFO - 2017-06-01 14:18:39 --> Controller Class Initialized
INFO - 2017-06-01 14:18:39 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:18:39 --> Final output sent to browser
DEBUG - 2017-06-01 14:18:39 --> Total execution time: 0.2521
INFO - 2017-06-01 14:19:18 --> Config Class Initialized
INFO - 2017-06-01 14:19:18 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:19:18 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:19:18 --> Utf8 Class Initialized
INFO - 2017-06-01 14:19:18 --> URI Class Initialized
INFO - 2017-06-01 14:19:18 --> Router Class Initialized
INFO - 2017-06-01 14:19:18 --> Output Class Initialized
INFO - 2017-06-01 14:19:18 --> Security Class Initialized
DEBUG - 2017-06-01 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:19:18 --> CSRF cookie sent
INFO - 2017-06-01 14:19:18 --> Input Class Initialized
INFO - 2017-06-01 14:19:18 --> Language Class Initialized
INFO - 2017-06-01 14:19:18 --> Loader Class Initialized
INFO - 2017-06-01 14:19:18 --> Helper loaded: url_helper
INFO - 2017-06-01 14:19:18 --> Helper loaded: file_helper
INFO - 2017-06-01 14:19:18 --> Helper loaded: form_helper
INFO - 2017-06-01 14:19:18 --> Form Validation Class Initialized
INFO - 2017-06-01 14:19:18 --> Image Lib Class Initialized
INFO - 2017-06-01 14:19:18 --> Controller Class Initialized
INFO - 2017-06-01 14:19:18 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:19:18 --> Final output sent to browser
DEBUG - 2017-06-01 14:19:18 --> Total execution time: 0.1890
INFO - 2017-06-01 14:20:49 --> Config Class Initialized
INFO - 2017-06-01 14:20:49 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:20:49 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:20:49 --> Utf8 Class Initialized
INFO - 2017-06-01 14:20:49 --> URI Class Initialized
INFO - 2017-06-01 14:20:49 --> Router Class Initialized
INFO - 2017-06-01 14:20:49 --> Output Class Initialized
INFO - 2017-06-01 14:20:49 --> Security Class Initialized
DEBUG - 2017-06-01 14:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:20:49 --> CSRF cookie sent
INFO - 2017-06-01 14:20:49 --> Input Class Initialized
INFO - 2017-06-01 14:20:49 --> Language Class Initialized
INFO - 2017-06-01 14:20:49 --> Loader Class Initialized
INFO - 2017-06-01 14:20:49 --> Helper loaded: url_helper
INFO - 2017-06-01 14:20:49 --> Helper loaded: file_helper
INFO - 2017-06-01 14:20:49 --> Helper loaded: form_helper
INFO - 2017-06-01 14:20:50 --> Form Validation Class Initialized
INFO - 2017-06-01 14:20:50 --> Image Lib Class Initialized
INFO - 2017-06-01 14:20:50 --> Controller Class Initialized
INFO - 2017-06-01 14:20:50 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:20:50 --> Final output sent to browser
DEBUG - 2017-06-01 14:20:50 --> Total execution time: 0.1886
INFO - 2017-06-01 14:29:34 --> Config Class Initialized
INFO - 2017-06-01 14:29:34 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:29:34 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:29:34 --> Utf8 Class Initialized
INFO - 2017-06-01 14:29:34 --> URI Class Initialized
INFO - 2017-06-01 14:29:34 --> Router Class Initialized
INFO - 2017-06-01 14:29:34 --> Output Class Initialized
INFO - 2017-06-01 14:29:34 --> Security Class Initialized
DEBUG - 2017-06-01 14:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:29:34 --> CSRF cookie sent
INFO - 2017-06-01 14:29:34 --> Input Class Initialized
INFO - 2017-06-01 14:29:34 --> Language Class Initialized
INFO - 2017-06-01 14:29:34 --> Loader Class Initialized
INFO - 2017-06-01 14:29:34 --> Helper loaded: url_helper
INFO - 2017-06-01 14:29:34 --> Helper loaded: file_helper
INFO - 2017-06-01 14:29:34 --> Helper loaded: form_helper
INFO - 2017-06-01 14:29:34 --> Form Validation Class Initialized
INFO - 2017-06-01 14:29:34 --> Image Lib Class Initialized
INFO - 2017-06-01 14:29:34 --> Controller Class Initialized
INFO - 2017-06-01 14:29:34 --> Upload Class Initialized
INFO - 2017-06-01 14:29:34 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-01 14:29:34 --> You did not select a file to upload.
ERROR - 2017-06-01 14:29:34 --> Severity: Notice --> Undefined variable: image_data D:\xampp\htdocs\loginfb\application\controllers\Welcome.php 48
ERROR - 2017-06-01 14:29:34 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/loginfb): failed to open stream: Permission denied D:\xampp\htdocs\loginfb\system\libraries\Image_lib.php 1651
INFO - 2017-06-01 14:29:34 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-06-01 14:29:34 --> The provided image is not valid.
INFO - 2017-06-01 14:29:34 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:29:34 --> Final output sent to browser
DEBUG - 2017-06-01 14:29:34 --> Total execution time: 0.5062
INFO - 2017-06-01 14:30:02 --> Config Class Initialized
INFO - 2017-06-01 14:30:02 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:30:02 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:30:02 --> Utf8 Class Initialized
INFO - 2017-06-01 14:30:02 --> URI Class Initialized
INFO - 2017-06-01 14:30:02 --> Router Class Initialized
INFO - 2017-06-01 14:30:02 --> Output Class Initialized
INFO - 2017-06-01 14:30:02 --> Security Class Initialized
DEBUG - 2017-06-01 14:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:30:02 --> CSRF cookie sent
INFO - 2017-06-01 14:30:02 --> Input Class Initialized
INFO - 2017-06-01 14:30:03 --> Language Class Initialized
INFO - 2017-06-01 14:30:03 --> Loader Class Initialized
INFO - 2017-06-01 14:30:03 --> Helper loaded: url_helper
INFO - 2017-06-01 14:30:03 --> Helper loaded: file_helper
INFO - 2017-06-01 14:30:03 --> Helper loaded: form_helper
INFO - 2017-06-01 14:30:03 --> Form Validation Class Initialized
INFO - 2017-06-01 14:30:03 --> Image Lib Class Initialized
INFO - 2017-06-01 14:30:03 --> Controller Class Initialized
INFO - 2017-06-01 14:30:03 --> Upload Class Initialized
INFO - 2017-06-01 14:30:03 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-01 14:30:03 --> You did not select a file to upload.
ERROR - 2017-06-01 14:30:03 --> Severity: Notice --> Undefined variable: image_data D:\xampp\htdocs\loginfb\application\controllers\Welcome.php 48
ERROR - 2017-06-01 14:30:03 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/loginfb): failed to open stream: Permission denied D:\xampp\htdocs\loginfb\system\libraries\Image_lib.php 1651
INFO - 2017-06-01 14:30:03 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-06-01 14:30:03 --> The provided image is not valid.
INFO - 2017-06-01 14:30:03 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:30:03 --> Final output sent to browser
DEBUG - 2017-06-01 14:30:03 --> Total execution time: 0.2966
INFO - 2017-06-01 14:30:30 --> Config Class Initialized
INFO - 2017-06-01 14:30:30 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:30:30 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:30:30 --> Utf8 Class Initialized
INFO - 2017-06-01 14:30:30 --> URI Class Initialized
INFO - 2017-06-01 14:30:30 --> Router Class Initialized
INFO - 2017-06-01 14:30:30 --> Output Class Initialized
INFO - 2017-06-01 14:30:30 --> Security Class Initialized
DEBUG - 2017-06-01 14:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:30:30 --> CSRF cookie sent
INFO - 2017-06-01 14:30:30 --> Input Class Initialized
INFO - 2017-06-01 14:30:30 --> Language Class Initialized
INFO - 2017-06-01 14:30:30 --> Loader Class Initialized
INFO - 2017-06-01 14:30:30 --> Helper loaded: url_helper
INFO - 2017-06-01 14:30:30 --> Helper loaded: file_helper
INFO - 2017-06-01 14:30:30 --> Helper loaded: form_helper
INFO - 2017-06-01 14:30:30 --> Form Validation Class Initialized
INFO - 2017-06-01 14:30:30 --> Image Lib Class Initialized
INFO - 2017-06-01 14:30:30 --> Controller Class Initialized
INFO - 2017-06-01 14:30:30 --> Upload Class Initialized
INFO - 2017-06-01 14:30:30 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-01 14:30:30 --> You did not select a file to upload.
INFO - 2017-06-01 14:30:30 --> Final output sent to browser
DEBUG - 2017-06-01 14:30:30 --> Total execution time: 0.2220
INFO - 2017-06-01 14:30:35 --> Config Class Initialized
INFO - 2017-06-01 14:30:35 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:30:35 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:30:35 --> Utf8 Class Initialized
INFO - 2017-06-01 14:30:35 --> URI Class Initialized
DEBUG - 2017-06-01 14:30:35 --> No URI present. Default controller set.
INFO - 2017-06-01 14:30:35 --> Router Class Initialized
INFO - 2017-06-01 14:30:35 --> Output Class Initialized
INFO - 2017-06-01 14:30:35 --> Security Class Initialized
DEBUG - 2017-06-01 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:30:35 --> CSRF cookie sent
INFO - 2017-06-01 14:30:35 --> Input Class Initialized
INFO - 2017-06-01 14:30:35 --> Language Class Initialized
INFO - 2017-06-01 14:30:35 --> Loader Class Initialized
INFO - 2017-06-01 14:30:35 --> Helper loaded: url_helper
INFO - 2017-06-01 14:30:35 --> Helper loaded: file_helper
INFO - 2017-06-01 14:30:35 --> Helper loaded: form_helper
INFO - 2017-06-01 14:30:35 --> Form Validation Class Initialized
INFO - 2017-06-01 14:30:35 --> Image Lib Class Initialized
INFO - 2017-06-01 14:30:35 --> Controller Class Initialized
INFO - 2017-06-01 14:30:35 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:30:35 --> Final output sent to browser
DEBUG - 2017-06-01 14:30:35 --> Total execution time: 0.2140
INFO - 2017-06-01 14:30:55 --> Config Class Initialized
INFO - 2017-06-01 14:30:55 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:30:55 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:30:55 --> Utf8 Class Initialized
INFO - 2017-06-01 14:30:55 --> URI Class Initialized
DEBUG - 2017-06-01 14:30:55 --> No URI present. Default controller set.
INFO - 2017-06-01 14:30:55 --> Router Class Initialized
INFO - 2017-06-01 14:30:55 --> Output Class Initialized
INFO - 2017-06-01 14:30:55 --> Security Class Initialized
DEBUG - 2017-06-01 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:30:55 --> CSRF cookie sent
INFO - 2017-06-01 14:30:55 --> Input Class Initialized
INFO - 2017-06-01 14:30:55 --> Language Class Initialized
INFO - 2017-06-01 14:30:55 --> Loader Class Initialized
INFO - 2017-06-01 14:30:55 --> Helper loaded: url_helper
INFO - 2017-06-01 14:30:55 --> Helper loaded: file_helper
INFO - 2017-06-01 14:30:55 --> Helper loaded: form_helper
INFO - 2017-06-01 14:30:55 --> Form Validation Class Initialized
INFO - 2017-06-01 14:30:55 --> Image Lib Class Initialized
INFO - 2017-06-01 14:30:55 --> Controller Class Initialized
INFO - 2017-06-01 14:30:55 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:30:55 --> Final output sent to browser
DEBUG - 2017-06-01 14:30:55 --> Total execution time: 0.2380
INFO - 2017-06-01 14:31:33 --> Config Class Initialized
INFO - 2017-06-01 14:31:33 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:31:33 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:31:33 --> Utf8 Class Initialized
INFO - 2017-06-01 14:31:33 --> URI Class Initialized
INFO - 2017-06-01 14:31:33 --> Router Class Initialized
INFO - 2017-06-01 14:31:33 --> Output Class Initialized
INFO - 2017-06-01 14:31:33 --> Security Class Initialized
DEBUG - 2017-06-01 14:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:31:33 --> CSRF cookie sent
INFO - 2017-06-01 14:31:33 --> CSRF token verified
INFO - 2017-06-01 14:31:33 --> Input Class Initialized
INFO - 2017-06-01 14:31:33 --> Language Class Initialized
INFO - 2017-06-01 14:31:33 --> Loader Class Initialized
INFO - 2017-06-01 14:31:33 --> Helper loaded: url_helper
INFO - 2017-06-01 14:31:33 --> Helper loaded: file_helper
INFO - 2017-06-01 14:31:33 --> Helper loaded: form_helper
INFO - 2017-06-01 14:31:33 --> Form Validation Class Initialized
INFO - 2017-06-01 14:31:33 --> Image Lib Class Initialized
INFO - 2017-06-01 14:31:33 --> Controller Class Initialized
INFO - 2017-06-01 14:31:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:31:33 --> Upload Class Initialized
INFO - 2017-06-01 14:31:33 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:31:34 --> Final output sent to browser
DEBUG - 2017-06-01 14:31:34 --> Total execution time: 0.3310
INFO - 2017-06-01 14:31:57 --> Config Class Initialized
INFO - 2017-06-01 14:31:57 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:31:57 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:31:57 --> Utf8 Class Initialized
INFO - 2017-06-01 14:31:57 --> URI Class Initialized
INFO - 2017-06-01 14:31:57 --> Router Class Initialized
INFO - 2017-06-01 14:31:57 --> Output Class Initialized
INFO - 2017-06-01 14:31:57 --> Security Class Initialized
DEBUG - 2017-06-01 14:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:31:57 --> CSRF cookie sent
INFO - 2017-06-01 14:31:57 --> CSRF token verified
INFO - 2017-06-01 14:31:57 --> Input Class Initialized
INFO - 2017-06-01 14:31:57 --> Language Class Initialized
INFO - 2017-06-01 14:31:57 --> Loader Class Initialized
INFO - 2017-06-01 14:31:57 --> Helper loaded: url_helper
INFO - 2017-06-01 14:31:57 --> Helper loaded: file_helper
INFO - 2017-06-01 14:31:57 --> Helper loaded: form_helper
INFO - 2017-06-01 14:31:57 --> Form Validation Class Initialized
INFO - 2017-06-01 14:31:57 --> Image Lib Class Initialized
INFO - 2017-06-01 14:31:57 --> Controller Class Initialized
INFO - 2017-06-01 14:31:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:31:57 --> Upload Class Initialized
INFO - 2017-06-01 14:31:57 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:31:57 --> Final output sent to browser
DEBUG - 2017-06-01 14:31:57 --> Total execution time: 0.2516
INFO - 2017-06-01 14:32:20 --> Config Class Initialized
INFO - 2017-06-01 14:32:20 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:32:20 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:32:20 --> Utf8 Class Initialized
INFO - 2017-06-01 14:32:20 --> URI Class Initialized
INFO - 2017-06-01 14:32:20 --> Router Class Initialized
INFO - 2017-06-01 14:32:20 --> Output Class Initialized
INFO - 2017-06-01 14:32:20 --> Security Class Initialized
DEBUG - 2017-06-01 14:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:32:20 --> CSRF cookie sent
INFO - 2017-06-01 14:32:20 --> CSRF token verified
INFO - 2017-06-01 14:32:20 --> Input Class Initialized
INFO - 2017-06-01 14:32:20 --> Language Class Initialized
INFO - 2017-06-01 14:32:20 --> Loader Class Initialized
INFO - 2017-06-01 14:32:20 --> Helper loaded: url_helper
INFO - 2017-06-01 14:32:20 --> Helper loaded: file_helper
INFO - 2017-06-01 14:32:20 --> Helper loaded: form_helper
INFO - 2017-06-01 14:32:20 --> Form Validation Class Initialized
INFO - 2017-06-01 14:32:20 --> Image Lib Class Initialized
INFO - 2017-06-01 14:32:20 --> Controller Class Initialized
INFO - 2017-06-01 14:32:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:32:20 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:32:20 --> Final output sent to browser
DEBUG - 2017-06-01 14:32:20 --> Total execution time: 0.2173
INFO - 2017-06-01 14:33:42 --> Config Class Initialized
INFO - 2017-06-01 14:33:42 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:33:42 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:33:42 --> Utf8 Class Initialized
INFO - 2017-06-01 14:33:42 --> URI Class Initialized
INFO - 2017-06-01 14:33:42 --> Router Class Initialized
INFO - 2017-06-01 14:33:42 --> Output Class Initialized
INFO - 2017-06-01 14:33:43 --> Security Class Initialized
DEBUG - 2017-06-01 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:33:43 --> CSRF cookie sent
INFO - 2017-06-01 14:33:43 --> Input Class Initialized
INFO - 2017-06-01 14:33:43 --> Language Class Initialized
INFO - 2017-06-01 14:33:43 --> Loader Class Initialized
INFO - 2017-06-01 14:33:43 --> Helper loaded: url_helper
INFO - 2017-06-01 14:33:43 --> Helper loaded: file_helper
INFO - 2017-06-01 14:33:43 --> Helper loaded: form_helper
INFO - 2017-06-01 14:33:43 --> Form Validation Class Initialized
INFO - 2017-06-01 14:33:43 --> Image Lib Class Initialized
INFO - 2017-06-01 14:33:43 --> Controller Class Initialized
INFO - 2017-06-01 14:33:43 --> Upload Class Initialized
INFO - 2017-06-01 14:33:43 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-01 14:33:43 --> You did not select a file to upload.
INFO - 2017-06-01 14:33:43 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:33:43 --> Final output sent to browser
DEBUG - 2017-06-01 14:33:43 --> Total execution time: 0.2190
INFO - 2017-06-01 14:34:23 --> Config Class Initialized
INFO - 2017-06-01 14:34:23 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:34:23 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:34:23 --> Utf8 Class Initialized
INFO - 2017-06-01 14:34:23 --> URI Class Initialized
INFO - 2017-06-01 14:34:23 --> Router Class Initialized
INFO - 2017-06-01 14:34:23 --> Output Class Initialized
INFO - 2017-06-01 14:34:23 --> Security Class Initialized
DEBUG - 2017-06-01 14:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:34:23 --> CSRF cookie sent
INFO - 2017-06-01 14:34:23 --> CSRF token verified
INFO - 2017-06-01 14:34:23 --> Input Class Initialized
INFO - 2017-06-01 14:34:23 --> Language Class Initialized
INFO - 2017-06-01 14:34:23 --> Loader Class Initialized
INFO - 2017-06-01 14:34:23 --> Helper loaded: url_helper
INFO - 2017-06-01 14:34:23 --> Helper loaded: file_helper
INFO - 2017-06-01 14:34:23 --> Helper loaded: form_helper
INFO - 2017-06-01 14:34:23 --> Form Validation Class Initialized
INFO - 2017-06-01 14:34:23 --> Image Lib Class Initialized
INFO - 2017-06-01 14:34:23 --> Controller Class Initialized
INFO - 2017-06-01 14:34:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:34:23 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:34:23 --> Final output sent to browser
DEBUG - 2017-06-01 14:34:23 --> Total execution time: 0.2569
INFO - 2017-06-01 14:36:21 --> Config Class Initialized
INFO - 2017-06-01 14:36:21 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:36:21 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:36:21 --> Utf8 Class Initialized
INFO - 2017-06-01 14:36:21 --> URI Class Initialized
DEBUG - 2017-06-01 14:36:21 --> No URI present. Default controller set.
INFO - 2017-06-01 14:36:21 --> Router Class Initialized
INFO - 2017-06-01 14:36:21 --> Output Class Initialized
INFO - 2017-06-01 14:36:21 --> Security Class Initialized
DEBUG - 2017-06-01 14:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:36:21 --> CSRF cookie sent
INFO - 2017-06-01 14:36:21 --> Input Class Initialized
INFO - 2017-06-01 14:36:21 --> Language Class Initialized
INFO - 2017-06-01 14:36:21 --> Loader Class Initialized
INFO - 2017-06-01 14:36:21 --> Helper loaded: url_helper
INFO - 2017-06-01 14:36:21 --> Helper loaded: file_helper
INFO - 2017-06-01 14:36:21 --> Helper loaded: form_helper
INFO - 2017-06-01 14:36:21 --> Form Validation Class Initialized
INFO - 2017-06-01 14:36:21 --> Image Lib Class Initialized
INFO - 2017-06-01 14:36:21 --> Controller Class Initialized
INFO - 2017-06-01 14:36:21 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:36:21 --> Final output sent to browser
DEBUG - 2017-06-01 14:36:21 --> Total execution time: 0.2096
INFO - 2017-06-01 14:37:04 --> Config Class Initialized
INFO - 2017-06-01 14:37:04 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:37:04 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:37:04 --> Utf8 Class Initialized
INFO - 2017-06-01 14:37:04 --> URI Class Initialized
INFO - 2017-06-01 14:37:04 --> Router Class Initialized
INFO - 2017-06-01 14:37:04 --> Output Class Initialized
INFO - 2017-06-01 14:37:04 --> Security Class Initialized
DEBUG - 2017-06-01 14:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:37:04 --> CSRF cookie sent
INFO - 2017-06-01 14:37:04 --> CSRF token verified
INFO - 2017-06-01 14:37:04 --> Input Class Initialized
INFO - 2017-06-01 14:37:04 --> Language Class Initialized
INFO - 2017-06-01 14:37:04 --> Loader Class Initialized
INFO - 2017-06-01 14:37:04 --> Helper loaded: url_helper
INFO - 2017-06-01 14:37:04 --> Helper loaded: file_helper
INFO - 2017-06-01 14:37:04 --> Helper loaded: form_helper
INFO - 2017-06-01 14:37:04 --> Form Validation Class Initialized
INFO - 2017-06-01 14:37:04 --> Image Lib Class Initialized
INFO - 2017-06-01 14:37:04 --> Controller Class Initialized
INFO - 2017-06-01 14:37:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:37:04 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:37:04 --> Final output sent to browser
DEBUG - 2017-06-01 14:37:04 --> Total execution time: 0.2413
INFO - 2017-06-01 14:39:36 --> Config Class Initialized
INFO - 2017-06-01 14:39:36 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:39:36 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:39:36 --> Utf8 Class Initialized
INFO - 2017-06-01 14:39:36 --> URI Class Initialized
INFO - 2017-06-01 14:39:36 --> Router Class Initialized
INFO - 2017-06-01 14:39:36 --> Output Class Initialized
INFO - 2017-06-01 14:39:36 --> Security Class Initialized
DEBUG - 2017-06-01 14:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:39:36 --> CSRF cookie sent
INFO - 2017-06-01 14:39:36 --> Input Class Initialized
INFO - 2017-06-01 14:39:36 --> Language Class Initialized
INFO - 2017-06-01 14:39:36 --> Loader Class Initialized
INFO - 2017-06-01 14:39:36 --> Helper loaded: url_helper
INFO - 2017-06-01 14:39:36 --> Helper loaded: file_helper
INFO - 2017-06-01 14:39:36 --> Helper loaded: form_helper
INFO - 2017-06-01 14:39:36 --> Form Validation Class Initialized
INFO - 2017-06-01 14:39:36 --> Image Lib Class Initialized
INFO - 2017-06-01 14:39:36 --> Controller Class Initialized
INFO - 2017-06-01 14:39:36 --> Upload Class Initialized
INFO - 2017-06-01 14:39:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-06-01 14:39:36 --> You did not select a file to upload.
INFO - 2017-06-01 14:40:12 --> Config Class Initialized
INFO - 2017-06-01 14:40:12 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:40:12 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:40:12 --> Utf8 Class Initialized
INFO - 2017-06-01 14:40:12 --> URI Class Initialized
DEBUG - 2017-06-01 14:40:12 --> No URI present. Default controller set.
INFO - 2017-06-01 14:40:12 --> Router Class Initialized
INFO - 2017-06-01 14:40:12 --> Output Class Initialized
INFO - 2017-06-01 14:40:12 --> Security Class Initialized
DEBUG - 2017-06-01 14:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:40:12 --> CSRF cookie sent
INFO - 2017-06-01 14:40:12 --> Input Class Initialized
INFO - 2017-06-01 14:40:12 --> Language Class Initialized
INFO - 2017-06-01 14:40:12 --> Loader Class Initialized
INFO - 2017-06-01 14:40:12 --> Helper loaded: url_helper
INFO - 2017-06-01 14:40:12 --> Helper loaded: file_helper
INFO - 2017-06-01 14:40:12 --> Helper loaded: form_helper
INFO - 2017-06-01 14:40:12 --> Form Validation Class Initialized
INFO - 2017-06-01 14:40:12 --> Image Lib Class Initialized
INFO - 2017-06-01 14:40:12 --> Controller Class Initialized
INFO - 2017-06-01 14:40:12 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:40:12 --> Final output sent to browser
DEBUG - 2017-06-01 14:40:12 --> Total execution time: 0.2078
INFO - 2017-06-01 14:40:44 --> Config Class Initialized
INFO - 2017-06-01 14:40:44 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:40:44 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:40:44 --> Utf8 Class Initialized
INFO - 2017-06-01 14:40:44 --> URI Class Initialized
INFO - 2017-06-01 14:40:44 --> Router Class Initialized
INFO - 2017-06-01 14:40:44 --> Output Class Initialized
INFO - 2017-06-01 14:40:44 --> Security Class Initialized
DEBUG - 2017-06-01 14:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:40:44 --> CSRF cookie sent
INFO - 2017-06-01 14:40:44 --> CSRF token verified
INFO - 2017-06-01 14:40:44 --> Input Class Initialized
INFO - 2017-06-01 14:40:44 --> Language Class Initialized
INFO - 2017-06-01 14:40:44 --> Loader Class Initialized
INFO - 2017-06-01 14:40:44 --> Helper loaded: url_helper
INFO - 2017-06-01 14:40:44 --> Helper loaded: file_helper
INFO - 2017-06-01 14:40:44 --> Helper loaded: form_helper
INFO - 2017-06-01 14:40:44 --> Form Validation Class Initialized
INFO - 2017-06-01 14:40:44 --> Image Lib Class Initialized
INFO - 2017-06-01 14:40:44 --> Controller Class Initialized
INFO - 2017-06-01 14:40:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:40:44 --> Upload Class Initialized
INFO - 2017-06-01 14:40:44 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:40:44 --> Final output sent to browser
DEBUG - 2017-06-01 14:40:44 --> Total execution time: 0.2397
INFO - 2017-06-01 14:41:15 --> Config Class Initialized
INFO - 2017-06-01 14:41:15 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:41:15 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:41:15 --> Utf8 Class Initialized
INFO - 2017-06-01 14:41:15 --> URI Class Initialized
INFO - 2017-06-01 14:41:15 --> Router Class Initialized
INFO - 2017-06-01 14:41:15 --> Output Class Initialized
INFO - 2017-06-01 14:41:15 --> Security Class Initialized
DEBUG - 2017-06-01 14:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:41:15 --> CSRF cookie sent
INFO - 2017-06-01 14:41:15 --> CSRF token verified
INFO - 2017-06-01 14:41:15 --> Input Class Initialized
INFO - 2017-06-01 14:41:15 --> Language Class Initialized
INFO - 2017-06-01 14:41:15 --> Loader Class Initialized
INFO - 2017-06-01 14:41:15 --> Helper loaded: url_helper
INFO - 2017-06-01 14:41:15 --> Helper loaded: file_helper
INFO - 2017-06-01 14:41:15 --> Helper loaded: form_helper
INFO - 2017-06-01 14:41:15 --> Form Validation Class Initialized
INFO - 2017-06-01 14:41:15 --> Image Lib Class Initialized
INFO - 2017-06-01 14:41:15 --> Controller Class Initialized
INFO - 2017-06-01 14:41:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 14:41:15 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:41:15 --> Final output sent to browser
DEBUG - 2017-06-01 14:41:15 --> Total execution time: 0.2327
INFO - 2017-06-01 14:59:36 --> Config Class Initialized
INFO - 2017-06-01 14:59:36 --> Hooks Class Initialized
DEBUG - 2017-06-01 14:59:36 --> UTF-8 Support Enabled
INFO - 2017-06-01 14:59:36 --> Utf8 Class Initialized
INFO - 2017-06-01 14:59:36 --> URI Class Initialized
INFO - 2017-06-01 14:59:36 --> Router Class Initialized
INFO - 2017-06-01 14:59:36 --> Output Class Initialized
INFO - 2017-06-01 14:59:36 --> Security Class Initialized
DEBUG - 2017-06-01 14:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 14:59:36 --> CSRF cookie sent
INFO - 2017-06-01 14:59:36 --> Input Class Initialized
INFO - 2017-06-01 14:59:36 --> Language Class Initialized
INFO - 2017-06-01 14:59:36 --> Loader Class Initialized
INFO - 2017-06-01 14:59:36 --> Helper loaded: url_helper
INFO - 2017-06-01 14:59:36 --> Helper loaded: file_helper
INFO - 2017-06-01 14:59:36 --> Helper loaded: form_helper
INFO - 2017-06-01 14:59:36 --> Form Validation Class Initialized
INFO - 2017-06-01 14:59:36 --> Image Lib Class Initialized
INFO - 2017-06-01 14:59:36 --> Controller Class Initialized
INFO - 2017-06-01 14:59:36 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 14:59:36 --> Final output sent to browser
DEBUG - 2017-06-01 14:59:36 --> Total execution time: 0.2389
INFO - 2017-06-01 15:00:17 --> Config Class Initialized
INFO - 2017-06-01 15:00:17 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:00:17 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:00:17 --> Utf8 Class Initialized
INFO - 2017-06-01 15:00:17 --> URI Class Initialized
INFO - 2017-06-01 15:00:17 --> Router Class Initialized
INFO - 2017-06-01 15:00:17 --> Output Class Initialized
INFO - 2017-06-01 15:00:17 --> Security Class Initialized
DEBUG - 2017-06-01 15:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:00:17 --> CSRF cookie sent
INFO - 2017-06-01 15:00:17 --> CSRF token verified
INFO - 2017-06-01 15:00:17 --> Input Class Initialized
INFO - 2017-06-01 15:00:17 --> Language Class Initialized
INFO - 2017-06-01 15:00:17 --> Loader Class Initialized
INFO - 2017-06-01 15:00:17 --> Helper loaded: url_helper
INFO - 2017-06-01 15:00:17 --> Helper loaded: file_helper
INFO - 2017-06-01 15:00:17 --> Helper loaded: form_helper
INFO - 2017-06-01 15:00:17 --> Form Validation Class Initialized
INFO - 2017-06-01 15:00:17 --> Image Lib Class Initialized
INFO - 2017-06-01 15:00:17 --> Controller Class Initialized
INFO - 2017-06-01 15:00:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:00:17 --> Upload Class Initialized
ERROR - 2017-06-01 15:00:18 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\loginfb\application\views\welcome_message.php 15
INFO - 2017-06-01 15:00:18 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:00:18 --> Final output sent to browser
DEBUG - 2017-06-01 15:00:18 --> Total execution time: 0.3447
INFO - 2017-06-01 15:03:47 --> Config Class Initialized
INFO - 2017-06-01 15:03:47 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:03:47 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:03:47 --> Utf8 Class Initialized
INFO - 2017-06-01 15:03:47 --> URI Class Initialized
INFO - 2017-06-01 15:03:47 --> Router Class Initialized
INFO - 2017-06-01 15:03:47 --> Output Class Initialized
INFO - 2017-06-01 15:03:47 --> Security Class Initialized
DEBUG - 2017-06-01 15:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:03:47 --> CSRF cookie sent
INFO - 2017-06-01 15:03:47 --> Input Class Initialized
INFO - 2017-06-01 15:03:47 --> Language Class Initialized
INFO - 2017-06-01 15:03:47 --> Loader Class Initialized
INFO - 2017-06-01 15:03:47 --> Helper loaded: url_helper
INFO - 2017-06-01 15:03:47 --> Helper loaded: file_helper
INFO - 2017-06-01 15:03:47 --> Helper loaded: form_helper
INFO - 2017-06-01 15:03:47 --> Form Validation Class Initialized
INFO - 2017-06-01 15:03:47 --> Image Lib Class Initialized
INFO - 2017-06-01 15:03:47 --> Controller Class Initialized
INFO - 2017-06-01 15:03:47 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:03:47 --> Final output sent to browser
DEBUG - 2017-06-01 15:03:47 --> Total execution time: 0.2158
INFO - 2017-06-01 15:04:16 --> Config Class Initialized
INFO - 2017-06-01 15:04:16 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:04:16 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:04:16 --> Utf8 Class Initialized
INFO - 2017-06-01 15:04:16 --> URI Class Initialized
INFO - 2017-06-01 15:04:16 --> Router Class Initialized
INFO - 2017-06-01 15:04:16 --> Output Class Initialized
INFO - 2017-06-01 15:04:16 --> Security Class Initialized
DEBUG - 2017-06-01 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:04:16 --> CSRF cookie sent
INFO - 2017-06-01 15:04:16 --> CSRF token verified
INFO - 2017-06-01 15:04:16 --> Input Class Initialized
INFO - 2017-06-01 15:04:16 --> Language Class Initialized
INFO - 2017-06-01 15:04:16 --> Loader Class Initialized
INFO - 2017-06-01 15:04:16 --> Helper loaded: url_helper
INFO - 2017-06-01 15:04:16 --> Helper loaded: file_helper
INFO - 2017-06-01 15:04:16 --> Helper loaded: form_helper
INFO - 2017-06-01 15:04:16 --> Form Validation Class Initialized
INFO - 2017-06-01 15:04:16 --> Image Lib Class Initialized
INFO - 2017-06-01 15:04:16 --> Controller Class Initialized
INFO - 2017-06-01 15:04:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:04:16 --> Upload Class Initialized
INFO - 2017-06-01 15:04:16 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:04:16 --> Final output sent to browser
DEBUG - 2017-06-01 15:04:16 --> Total execution time: 0.3649
INFO - 2017-06-01 15:06:50 --> Config Class Initialized
INFO - 2017-06-01 15:06:50 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:06:50 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:06:50 --> Utf8 Class Initialized
INFO - 2017-06-01 15:06:50 --> URI Class Initialized
INFO - 2017-06-01 15:06:50 --> Router Class Initialized
INFO - 2017-06-01 15:06:50 --> Output Class Initialized
INFO - 2017-06-01 15:06:50 --> Security Class Initialized
DEBUG - 2017-06-01 15:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:06:50 --> CSRF cookie sent
INFO - 2017-06-01 15:06:50 --> Input Class Initialized
INFO - 2017-06-01 15:06:50 --> Language Class Initialized
INFO - 2017-06-01 15:06:50 --> Loader Class Initialized
INFO - 2017-06-01 15:06:50 --> Helper loaded: url_helper
INFO - 2017-06-01 15:06:50 --> Helper loaded: file_helper
INFO - 2017-06-01 15:06:50 --> Helper loaded: form_helper
INFO - 2017-06-01 15:06:50 --> Form Validation Class Initialized
INFO - 2017-06-01 15:06:50 --> Image Lib Class Initialized
INFO - 2017-06-01 15:06:50 --> Controller Class Initialized
INFO - 2017-06-01 15:06:50 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:06:50 --> Final output sent to browser
DEBUG - 2017-06-01 15:06:50 --> Total execution time: 0.1996
INFO - 2017-06-01 15:07:31 --> Config Class Initialized
INFO - 2017-06-01 15:07:31 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:07:31 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:07:31 --> Utf8 Class Initialized
INFO - 2017-06-01 15:07:31 --> URI Class Initialized
INFO - 2017-06-01 15:07:31 --> Router Class Initialized
INFO - 2017-06-01 15:07:31 --> Output Class Initialized
INFO - 2017-06-01 15:07:31 --> Security Class Initialized
DEBUG - 2017-06-01 15:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:07:31 --> CSRF cookie sent
INFO - 2017-06-01 15:07:31 --> CSRF token verified
INFO - 2017-06-01 15:07:31 --> Input Class Initialized
INFO - 2017-06-01 15:07:31 --> Language Class Initialized
INFO - 2017-06-01 15:07:31 --> Loader Class Initialized
INFO - 2017-06-01 15:07:31 --> Helper loaded: url_helper
INFO - 2017-06-01 15:07:31 --> Helper loaded: file_helper
INFO - 2017-06-01 15:07:31 --> Helper loaded: form_helper
INFO - 2017-06-01 15:07:31 --> Form Validation Class Initialized
INFO - 2017-06-01 15:07:31 --> Image Lib Class Initialized
INFO - 2017-06-01 15:07:31 --> Controller Class Initialized
INFO - 2017-06-01 15:07:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:07:31 --> Upload Class Initialized
ERROR - 2017-06-01 15:07:31 --> Severity: Notice --> Undefined variable: image_data D:\xampp\htdocs\loginfb\application\controllers\Welcome.php 46
ERROR - 2017-06-01 15:07:31 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/loginfb): failed to open stream: Permission denied D:\xampp\htdocs\loginfb\system\libraries\Image_lib.php 1651
INFO - 2017-06-01 15:07:31 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-06-01 15:07:31 --> The provided image is not valid.
ERROR - 2017-06-01 15:07:31 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-06-01 15:07:31 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:07:31 --> Final output sent to browser
DEBUG - 2017-06-01 15:07:31 --> Total execution time: 0.3100
INFO - 2017-06-01 15:08:38 --> Config Class Initialized
INFO - 2017-06-01 15:08:38 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:08:38 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:08:39 --> Utf8 Class Initialized
INFO - 2017-06-01 15:08:39 --> URI Class Initialized
INFO - 2017-06-01 15:08:39 --> Router Class Initialized
INFO - 2017-06-01 15:08:39 --> Output Class Initialized
INFO - 2017-06-01 15:08:39 --> Security Class Initialized
DEBUG - 2017-06-01 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:08:39 --> CSRF cookie sent
INFO - 2017-06-01 15:08:39 --> Input Class Initialized
INFO - 2017-06-01 15:08:39 --> Language Class Initialized
INFO - 2017-06-01 15:08:39 --> Loader Class Initialized
INFO - 2017-06-01 15:08:39 --> Helper loaded: url_helper
INFO - 2017-06-01 15:08:39 --> Helper loaded: file_helper
INFO - 2017-06-01 15:08:39 --> Helper loaded: form_helper
INFO - 2017-06-01 15:08:39 --> Form Validation Class Initialized
INFO - 2017-06-01 15:08:39 --> Image Lib Class Initialized
INFO - 2017-06-01 15:08:39 --> Controller Class Initialized
INFO - 2017-06-01 15:08:39 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:08:39 --> Final output sent to browser
DEBUG - 2017-06-01 15:08:39 --> Total execution time: 0.2066
INFO - 2017-06-01 15:09:27 --> Config Class Initialized
INFO - 2017-06-01 15:09:27 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:09:27 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:09:27 --> Utf8 Class Initialized
INFO - 2017-06-01 15:09:27 --> URI Class Initialized
INFO - 2017-06-01 15:09:27 --> Router Class Initialized
INFO - 2017-06-01 15:09:27 --> Output Class Initialized
INFO - 2017-06-01 15:09:27 --> Security Class Initialized
DEBUG - 2017-06-01 15:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:09:27 --> CSRF cookie sent
INFO - 2017-06-01 15:09:27 --> CSRF token verified
INFO - 2017-06-01 15:09:27 --> Input Class Initialized
INFO - 2017-06-01 15:09:27 --> Language Class Initialized
INFO - 2017-06-01 15:09:27 --> Loader Class Initialized
INFO - 2017-06-01 15:09:27 --> Helper loaded: url_helper
INFO - 2017-06-01 15:09:27 --> Helper loaded: file_helper
INFO - 2017-06-01 15:09:27 --> Helper loaded: form_helper
INFO - 2017-06-01 15:09:27 --> Form Validation Class Initialized
INFO - 2017-06-01 15:09:27 --> Image Lib Class Initialized
INFO - 2017-06-01 15:09:27 --> Controller Class Initialized
INFO - 2017-06-01 15:09:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:09:27 --> Upload Class Initialized
INFO - 2017-06-01 15:09:27 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:09:27 --> Final output sent to browser
DEBUG - 2017-06-01 15:09:27 --> Total execution time: 0.3792
INFO - 2017-06-01 15:10:26 --> Config Class Initialized
INFO - 2017-06-01 15:10:26 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:10:26 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:10:26 --> Utf8 Class Initialized
INFO - 2017-06-01 15:10:26 --> URI Class Initialized
INFO - 2017-06-01 15:10:26 --> Router Class Initialized
INFO - 2017-06-01 15:10:26 --> Output Class Initialized
INFO - 2017-06-01 15:10:26 --> Security Class Initialized
DEBUG - 2017-06-01 15:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:10:26 --> CSRF cookie sent
INFO - 2017-06-01 15:10:26 --> Input Class Initialized
INFO - 2017-06-01 15:10:26 --> Language Class Initialized
INFO - 2017-06-01 15:10:26 --> Loader Class Initialized
INFO - 2017-06-01 15:10:26 --> Helper loaded: url_helper
INFO - 2017-06-01 15:10:26 --> Helper loaded: file_helper
INFO - 2017-06-01 15:10:26 --> Helper loaded: form_helper
INFO - 2017-06-01 15:10:26 --> Form Validation Class Initialized
INFO - 2017-06-01 15:10:26 --> Image Lib Class Initialized
INFO - 2017-06-01 15:10:26 --> Controller Class Initialized
INFO - 2017-06-01 15:10:26 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:10:26 --> Final output sent to browser
DEBUG - 2017-06-01 15:10:26 --> Total execution time: 0.2109
INFO - 2017-06-01 15:13:21 --> Config Class Initialized
INFO - 2017-06-01 15:13:21 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:13:21 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:13:21 --> Utf8 Class Initialized
INFO - 2017-06-01 15:13:21 --> URI Class Initialized
INFO - 2017-06-01 15:13:21 --> Router Class Initialized
INFO - 2017-06-01 15:13:21 --> Output Class Initialized
INFO - 2017-06-01 15:13:21 --> Security Class Initialized
DEBUG - 2017-06-01 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:13:21 --> CSRF cookie sent
INFO - 2017-06-01 15:13:21 --> CSRF token verified
INFO - 2017-06-01 15:13:21 --> Input Class Initialized
INFO - 2017-06-01 15:13:21 --> Language Class Initialized
INFO - 2017-06-01 15:13:21 --> Loader Class Initialized
INFO - 2017-06-01 15:13:21 --> Helper loaded: url_helper
INFO - 2017-06-01 15:13:21 --> Helper loaded: file_helper
INFO - 2017-06-01 15:13:21 --> Helper loaded: form_helper
INFO - 2017-06-01 15:13:21 --> Form Validation Class Initialized
INFO - 2017-06-01 15:13:21 --> Image Lib Class Initialized
INFO - 2017-06-01 15:13:21 --> Controller Class Initialized
INFO - 2017-06-01 15:13:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:13:21 --> Upload Class Initialized
INFO - 2017-06-01 15:13:21 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:13:21 --> Final output sent to browser
DEBUG - 2017-06-01 15:13:21 --> Total execution time: 0.2455
INFO - 2017-06-01 15:13:46 --> Config Class Initialized
INFO - 2017-06-01 15:13:46 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:13:46 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:13:46 --> Utf8 Class Initialized
INFO - 2017-06-01 15:13:46 --> URI Class Initialized
INFO - 2017-06-01 15:13:46 --> Router Class Initialized
INFO - 2017-06-01 15:13:46 --> Output Class Initialized
INFO - 2017-06-01 15:13:46 --> Security Class Initialized
DEBUG - 2017-06-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:13:46 --> CSRF cookie sent
INFO - 2017-06-01 15:13:46 --> Input Class Initialized
INFO - 2017-06-01 15:13:46 --> Language Class Initialized
INFO - 2017-06-01 15:13:46 --> Loader Class Initialized
INFO - 2017-06-01 15:13:46 --> Helper loaded: url_helper
INFO - 2017-06-01 15:13:46 --> Helper loaded: file_helper
INFO - 2017-06-01 15:13:46 --> Helper loaded: form_helper
INFO - 2017-06-01 15:13:46 --> Form Validation Class Initialized
INFO - 2017-06-01 15:13:46 --> Image Lib Class Initialized
INFO - 2017-06-01 15:13:46 --> Controller Class Initialized
INFO - 2017-06-01 15:13:46 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:13:46 --> Final output sent to browser
DEBUG - 2017-06-01 15:13:46 --> Total execution time: 0.2099
INFO - 2017-06-01 15:14:21 --> Config Class Initialized
INFO - 2017-06-01 15:14:21 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:14:21 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:14:21 --> Utf8 Class Initialized
INFO - 2017-06-01 15:14:21 --> URI Class Initialized
INFO - 2017-06-01 15:14:21 --> Router Class Initialized
INFO - 2017-06-01 15:14:21 --> Output Class Initialized
INFO - 2017-06-01 15:14:21 --> Security Class Initialized
DEBUG - 2017-06-01 15:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:14:21 --> CSRF cookie sent
INFO - 2017-06-01 15:14:21 --> CSRF token verified
INFO - 2017-06-01 15:14:21 --> Input Class Initialized
INFO - 2017-06-01 15:14:21 --> Language Class Initialized
INFO - 2017-06-01 15:14:21 --> Loader Class Initialized
INFO - 2017-06-01 15:14:21 --> Helper loaded: url_helper
INFO - 2017-06-01 15:14:21 --> Helper loaded: file_helper
INFO - 2017-06-01 15:14:21 --> Helper loaded: form_helper
INFO - 2017-06-01 15:14:21 --> Form Validation Class Initialized
INFO - 2017-06-01 15:14:21 --> Image Lib Class Initialized
INFO - 2017-06-01 15:14:21 --> Controller Class Initialized
INFO - 2017-06-01 15:14:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:14:21 --> Upload Class Initialized
INFO - 2017-06-01 15:14:21 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:14:21 --> Final output sent to browser
DEBUG - 2017-06-01 15:14:21 --> Total execution time: 0.2464
INFO - 2017-06-01 15:15:39 --> Config Class Initialized
INFO - 2017-06-01 15:15:39 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:15:39 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:15:39 --> Utf8 Class Initialized
INFO - 2017-06-01 15:15:39 --> URI Class Initialized
INFO - 2017-06-01 15:15:39 --> Router Class Initialized
INFO - 2017-06-01 15:15:39 --> Output Class Initialized
INFO - 2017-06-01 15:15:39 --> Security Class Initialized
DEBUG - 2017-06-01 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:15:39 --> CSRF cookie sent
INFO - 2017-06-01 15:15:39 --> Input Class Initialized
INFO - 2017-06-01 15:15:39 --> Language Class Initialized
INFO - 2017-06-01 15:15:39 --> Loader Class Initialized
INFO - 2017-06-01 15:15:39 --> Helper loaded: url_helper
INFO - 2017-06-01 15:15:39 --> Helper loaded: file_helper
INFO - 2017-06-01 15:15:39 --> Helper loaded: form_helper
INFO - 2017-06-01 15:15:39 --> Form Validation Class Initialized
INFO - 2017-06-01 15:15:39 --> Image Lib Class Initialized
INFO - 2017-06-01 15:15:39 --> Controller Class Initialized
INFO - 2017-06-01 15:15:39 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:15:39 --> Final output sent to browser
DEBUG - 2017-06-01 15:15:39 --> Total execution time: 0.2167
INFO - 2017-06-01 15:16:11 --> Config Class Initialized
INFO - 2017-06-01 15:16:11 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:16:11 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:16:11 --> Utf8 Class Initialized
INFO - 2017-06-01 15:16:11 --> URI Class Initialized
INFO - 2017-06-01 15:16:11 --> Router Class Initialized
INFO - 2017-06-01 15:16:11 --> Output Class Initialized
INFO - 2017-06-01 15:16:12 --> Security Class Initialized
DEBUG - 2017-06-01 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:16:12 --> CSRF cookie sent
INFO - 2017-06-01 15:16:12 --> CSRF token verified
INFO - 2017-06-01 15:16:12 --> Input Class Initialized
INFO - 2017-06-01 15:16:12 --> Language Class Initialized
INFO - 2017-06-01 15:16:12 --> Loader Class Initialized
INFO - 2017-06-01 15:16:12 --> Helper loaded: url_helper
INFO - 2017-06-01 15:16:12 --> Helper loaded: file_helper
INFO - 2017-06-01 15:16:12 --> Helper loaded: form_helper
INFO - 2017-06-01 15:16:12 --> Form Validation Class Initialized
INFO - 2017-06-01 15:16:12 --> Image Lib Class Initialized
INFO - 2017-06-01 15:16:12 --> Controller Class Initialized
INFO - 2017-06-01 15:16:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:16:12 --> Upload Class Initialized
INFO - 2017-06-01 15:16:12 --> Final output sent to browser
DEBUG - 2017-06-01 15:16:12 --> Total execution time: 0.2321
INFO - 2017-06-01 15:16:49 --> Config Class Initialized
INFO - 2017-06-01 15:16:49 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:16:49 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:16:49 --> Utf8 Class Initialized
INFO - 2017-06-01 15:16:49 --> URI Class Initialized
INFO - 2017-06-01 15:16:49 --> Router Class Initialized
INFO - 2017-06-01 15:16:49 --> Output Class Initialized
INFO - 2017-06-01 15:16:50 --> Security Class Initialized
DEBUG - 2017-06-01 15:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:16:50 --> CSRF cookie sent
INFO - 2017-06-01 15:16:50 --> Input Class Initialized
INFO - 2017-06-01 15:16:50 --> Language Class Initialized
INFO - 2017-06-01 15:16:50 --> Loader Class Initialized
INFO - 2017-06-01 15:16:50 --> Helper loaded: url_helper
INFO - 2017-06-01 15:16:50 --> Helper loaded: file_helper
INFO - 2017-06-01 15:16:50 --> Helper loaded: form_helper
INFO - 2017-06-01 15:16:50 --> Form Validation Class Initialized
INFO - 2017-06-01 15:16:50 --> Image Lib Class Initialized
INFO - 2017-06-01 15:16:50 --> Controller Class Initialized
INFO - 2017-06-01 15:16:50 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:16:50 --> Final output sent to browser
DEBUG - 2017-06-01 15:16:50 --> Total execution time: 0.2039
INFO - 2017-06-01 15:17:23 --> Config Class Initialized
INFO - 2017-06-01 15:17:23 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:17:23 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:17:23 --> Utf8 Class Initialized
INFO - 2017-06-01 15:17:23 --> URI Class Initialized
INFO - 2017-06-01 15:17:23 --> Router Class Initialized
INFO - 2017-06-01 15:17:24 --> Output Class Initialized
INFO - 2017-06-01 15:17:24 --> Security Class Initialized
DEBUG - 2017-06-01 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:17:24 --> CSRF cookie sent
INFO - 2017-06-01 15:17:24 --> CSRF token verified
INFO - 2017-06-01 15:17:24 --> Input Class Initialized
INFO - 2017-06-01 15:17:24 --> Language Class Initialized
INFO - 2017-06-01 15:17:24 --> Loader Class Initialized
INFO - 2017-06-01 15:17:24 --> Helper loaded: url_helper
INFO - 2017-06-01 15:17:24 --> Helper loaded: file_helper
INFO - 2017-06-01 15:17:24 --> Helper loaded: form_helper
INFO - 2017-06-01 15:17:24 --> Form Validation Class Initialized
INFO - 2017-06-01 15:17:24 --> Image Lib Class Initialized
INFO - 2017-06-01 15:17:24 --> Controller Class Initialized
INFO - 2017-06-01 15:17:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:17:24 --> Upload Class Initialized
INFO - 2017-06-01 15:17:24 --> Final output sent to browser
DEBUG - 2017-06-01 15:17:24 --> Total execution time: 0.2577
INFO - 2017-06-01 15:26:27 --> Config Class Initialized
INFO - 2017-06-01 15:26:27 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:26:27 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:26:27 --> Utf8 Class Initialized
INFO - 2017-06-01 15:26:27 --> URI Class Initialized
INFO - 2017-06-01 15:26:27 --> Router Class Initialized
INFO - 2017-06-01 15:26:27 --> Output Class Initialized
INFO - 2017-06-01 15:26:27 --> Security Class Initialized
DEBUG - 2017-06-01 15:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:26:27 --> CSRF cookie sent
INFO - 2017-06-01 15:26:27 --> Input Class Initialized
INFO - 2017-06-01 15:26:27 --> Language Class Initialized
INFO - 2017-06-01 15:26:27 --> Loader Class Initialized
INFO - 2017-06-01 15:26:27 --> Helper loaded: url_helper
INFO - 2017-06-01 15:26:27 --> Helper loaded: file_helper
INFO - 2017-06-01 15:26:27 --> Helper loaded: form_helper
INFO - 2017-06-01 15:26:27 --> Form Validation Class Initialized
INFO - 2017-06-01 15:26:27 --> Image Lib Class Initialized
INFO - 2017-06-01 15:26:27 --> Controller Class Initialized
INFO - 2017-06-01 15:26:27 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:26:27 --> Final output sent to browser
DEBUG - 2017-06-01 15:26:27 --> Total execution time: 0.2172
INFO - 2017-06-01 15:27:06 --> Config Class Initialized
INFO - 2017-06-01 15:27:06 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:27:06 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:27:06 --> Utf8 Class Initialized
INFO - 2017-06-01 15:27:06 --> URI Class Initialized
INFO - 2017-06-01 15:27:06 --> Router Class Initialized
INFO - 2017-06-01 15:27:06 --> Output Class Initialized
INFO - 2017-06-01 15:27:06 --> Security Class Initialized
DEBUG - 2017-06-01 15:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:27:06 --> CSRF cookie sent
INFO - 2017-06-01 15:27:06 --> CSRF token verified
INFO - 2017-06-01 15:27:06 --> Input Class Initialized
INFO - 2017-06-01 15:27:06 --> Language Class Initialized
INFO - 2017-06-01 15:27:06 --> Loader Class Initialized
INFO - 2017-06-01 15:27:06 --> Helper loaded: url_helper
INFO - 2017-06-01 15:27:06 --> Helper loaded: file_helper
INFO - 2017-06-01 15:27:06 --> Helper loaded: form_helper
INFO - 2017-06-01 15:27:06 --> Form Validation Class Initialized
INFO - 2017-06-01 15:27:06 --> Image Lib Class Initialized
INFO - 2017-06-01 15:27:06 --> Controller Class Initialized
INFO - 2017-06-01 15:27:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:27:06 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:27:06 --> Final output sent to browser
DEBUG - 2017-06-01 15:27:06 --> Total execution time: 0.4237
INFO - 2017-06-01 15:27:27 --> Config Class Initialized
INFO - 2017-06-01 15:27:27 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:27:27 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:27:27 --> Utf8 Class Initialized
INFO - 2017-06-01 15:27:27 --> URI Class Initialized
INFO - 2017-06-01 15:27:27 --> Router Class Initialized
INFO - 2017-06-01 15:27:27 --> Output Class Initialized
INFO - 2017-06-01 15:27:27 --> Security Class Initialized
DEBUG - 2017-06-01 15:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:27:27 --> CSRF cookie sent
INFO - 2017-06-01 15:27:27 --> CSRF token verified
INFO - 2017-06-01 15:27:27 --> Input Class Initialized
INFO - 2017-06-01 15:27:27 --> Language Class Initialized
INFO - 2017-06-01 15:27:27 --> Loader Class Initialized
INFO - 2017-06-01 15:27:27 --> Helper loaded: url_helper
INFO - 2017-06-01 15:27:27 --> Helper loaded: file_helper
INFO - 2017-06-01 15:27:27 --> Helper loaded: form_helper
INFO - 2017-06-01 15:27:27 --> Form Validation Class Initialized
INFO - 2017-06-01 15:27:27 --> Image Lib Class Initialized
INFO - 2017-06-01 15:27:27 --> Controller Class Initialized
INFO - 2017-06-01 15:27:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:27:27 --> Upload Class Initialized
ERROR - 2017-06-01 15:27:27 --> Severity: Notice --> Undefined variable: image_data D:\xampp\htdocs\loginfb\application\controllers\Welcome.php 48
ERROR - 2017-06-01 15:27:27 --> Severity: Warning --> getimagesize(D:/xampp/htdocs/loginfb): failed to open stream: Permission denied D:\xampp\htdocs\loginfb\system\libraries\Image_lib.php 1651
INFO - 2017-06-01 15:27:27 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2017-06-01 15:27:27 --> The provided image is not valid.
ERROR - 2017-06-01 15:27:27 --> Your server does not support the GD function required to process this type of image.
INFO - 2017-06-01 15:27:28 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:27:28 --> Final output sent to browser
DEBUG - 2017-06-01 15:27:28 --> Total execution time: 0.4792
INFO - 2017-06-01 15:28:54 --> Config Class Initialized
INFO - 2017-06-01 15:28:54 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:28:54 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:28:54 --> Utf8 Class Initialized
INFO - 2017-06-01 15:28:55 --> URI Class Initialized
INFO - 2017-06-01 15:28:55 --> Router Class Initialized
INFO - 2017-06-01 15:28:55 --> Output Class Initialized
INFO - 2017-06-01 15:28:55 --> Security Class Initialized
DEBUG - 2017-06-01 15:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:28:55 --> CSRF cookie sent
INFO - 2017-06-01 15:28:55 --> Input Class Initialized
INFO - 2017-06-01 15:28:55 --> Language Class Initialized
INFO - 2017-06-01 15:28:55 --> Loader Class Initialized
INFO - 2017-06-01 15:28:55 --> Helper loaded: url_helper
INFO - 2017-06-01 15:28:55 --> Helper loaded: file_helper
INFO - 2017-06-01 15:28:55 --> Helper loaded: form_helper
INFO - 2017-06-01 15:28:55 --> Form Validation Class Initialized
INFO - 2017-06-01 15:28:55 --> Image Lib Class Initialized
INFO - 2017-06-01 15:28:55 --> Controller Class Initialized
INFO - 2017-06-01 15:28:55 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:28:55 --> Final output sent to browser
DEBUG - 2017-06-01 15:28:55 --> Total execution time: 2.2422
INFO - 2017-06-01 15:29:35 --> Config Class Initialized
INFO - 2017-06-01 15:29:35 --> Hooks Class Initialized
DEBUG - 2017-06-01 15:29:35 --> UTF-8 Support Enabled
INFO - 2017-06-01 15:29:35 --> Utf8 Class Initialized
INFO - 2017-06-01 15:29:35 --> URI Class Initialized
INFO - 2017-06-01 15:29:35 --> Router Class Initialized
INFO - 2017-06-01 15:29:35 --> Output Class Initialized
INFO - 2017-06-01 15:29:35 --> Security Class Initialized
DEBUG - 2017-06-01 15:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-01 15:29:35 --> CSRF cookie sent
INFO - 2017-06-01 15:29:35 --> CSRF token verified
INFO - 2017-06-01 15:29:35 --> Input Class Initialized
INFO - 2017-06-01 15:29:35 --> Language Class Initialized
INFO - 2017-06-01 15:29:35 --> Loader Class Initialized
INFO - 2017-06-01 15:29:35 --> Helper loaded: url_helper
INFO - 2017-06-01 15:29:36 --> Helper loaded: file_helper
INFO - 2017-06-01 15:29:36 --> Helper loaded: form_helper
INFO - 2017-06-01 15:29:36 --> Form Validation Class Initialized
INFO - 2017-06-01 15:29:36 --> Image Lib Class Initialized
INFO - 2017-06-01 15:29:36 --> Controller Class Initialized
INFO - 2017-06-01 15:29:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-01 15:29:36 --> Upload Class Initialized
INFO - 2017-06-01 15:29:36 --> File loaded: D:\xampp\htdocs\loginfb\application\views\welcome_message.php
INFO - 2017-06-01 15:29:36 --> Final output sent to browser
DEBUG - 2017-06-01 15:29:36 --> Total execution time: 0.3899
