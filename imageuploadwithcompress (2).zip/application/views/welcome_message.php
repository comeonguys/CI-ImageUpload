<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Common validation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <?php echo form_open_multipart('Welcome/register'); ?>
        
        <?php if(isset($imgresult) && $imgresult<>'') { print_r($imgresult); } ?>
        <div class="row">&nbsp;</div>
        <div class="row">
            <div class="col-md-4">&nbsp;</div>
            <div class="col-md-4">
                <h2>Register</h2>
            </div>
            <div class="col-md-4">&nbsp;</div>
        </div>
        <div class="row">&nbsp;</div>
       
         <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="uname">NAME</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="text" value="<?php echo set_value('uname','',TRUE); ?>" class="form-control" name="uname">
            </div>
            <div class="col-md-2"><?php echo form_error('uname'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
        <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="password">PASSWORD</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="password" value="<?php echo set_value('password','',TRUE); ?>" class="form-control" name="password">
            </div>
            <div class="col-md-2"><?php echo form_error('password'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
         <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="confirmpassword">CONFIRM PASSWORD</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="password" value="<?php echo set_value('confirmpassword','',TRUE); ?>" class="form-control" name="confirmpassword">
            </div>
            <div class="col-md-2"><?php echo form_error('confirmpassword'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
       
        
         <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="address">ADDRESS</label>
            </div>
            <div class="col-md-3 form-group">
                <textarea class="form-control" name="address"><?php echo set_value('address','',TRUE); ?></textarea>
            </div>
            <div class="col-md-2"><?php echo form_error('address'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
        
        <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="city">Current City</label>
            </div>
            <div class="col-md-3 form-group">
            <?php
            $data_city = array(''=>'','TN' => 'TN','KL' => 'KL'); 
            echo form_dropdown('city', $data_city, 'Male','class="form-control"');
            ?>
                
            </div>
            <div class="col-md-2"><?php echo form_error('city'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
        <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="zipcode">ZIPCODE</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="text" value="<?php echo set_value('zipcode','',TRUE); ?>" class="form-control" name="zipcode">
            </div>
            <div class="col-md-2"><?php echo form_error('zipcode'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
        
        
          <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="email">E-MAIL</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="text" value="<?php echo set_value('email','',TRUE); ?>" class="form-control" name="email">
            </div>
            <div class="col-md-2"><?php echo form_error('email'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
         <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="sex">Sex</label>
            </div>
            <div class="col-md-3 form-group">
            <?php
                $data_radio1 = array('name' => 'sex','value' => 'Male','checked' => TRUE);
                $data_radio2 = array('name' => 'sex','value' => 'Female');
                echo form_radio($data_radio1).'Male';
                echo form_radio($data_radio2).'Female';
            ?>
            </div>
            <div class="col-md-2"><?php echo form_error('sex'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        
         <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="language">Language Known</label>
            </div>
            <div class="col-md-3 form-group">
                <input type="checkbox" value="<?php echo set_value('language[]','English',TRUE); ?>"  name="language[]"> English
                <input type="checkbox" value="<?php echo set_value('language[]','Tamil',TRUE); ?>"  name="language[]"> Tamil
                <input type="checkbox" value="<?php echo set_value('language[]','otherlang',TRUE); ?>"  name="language[]"> Other
            </div>
            <div class="col-md-2"><?php echo form_error('language[]'); ?></div>
            <div class="col-md-2">&nbsp;</div>
        </div>
   
        <div class="row">
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-2">
                <label for="language">Upload Profile</label>
            </div>
            <div class="col-md-4 form-group">
            <?php
                $file = array('type' => 'file','name' => 'userfile','required' => '','onchange' => 'readURL(this);');
                echo form_input($file);
            ?>
            </div>
           <div class="col-md-2">&nbsp;</div>
        </div>
        
        <div class="row">
            <div class="col-md-4">&nbsp;</div>
            <div class="col-md-6">
                <img id="select" src="<?php echo site_url('assets/img/no-image.png'); ?>" alt="Profile" class="img-thumbnail" style="width:150px"/>
            </div>
            <div class="col-md-2">&nbsp;</div>
        </div>
        <div class="row">&nbsp;</div>
        <div class="row">
            <div class="col-md-6">&nbsp;</div>
            <div class="col-md-4">
                <input type="submit" id="resize_button" value="<?php echo set_value('register','Register',TRUE); ?>" name="register" class="btn btn-primary "/>
            </div>
            <div class="col-md-2">&nbsp;</div>
                 
        </div>
        
        <?php echo form_close(); ?>
    </div>

</body>
</html>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
// Show select image using file input.
function readURL(input) {
$('#default_img').show();
if (input.files && input.files[0]) {
var reader = new FileReader();

reader.onload = function(e) {
$('#select')
.attr('src', e.target.result)
.width(150)
.height(150);

};

reader.readAsDataURL(input.files[0]);
}
}

</script>
